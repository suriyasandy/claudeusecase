# Accounting Control AI Platform — Standalone Streamlit App

## Quick Start

```bash
# 1. Create virtual environment
python -m venv venv

# Windows
venv\Scripts\activate

# Mac/Linux
source venv/bin/activate

# 2. Install dependencies
pip install -r requirements.txt

# 3. Run the app
streamlit run app.py --server.port 8501
```

Then open: http://localhost:8501

## What's Fixed vs Previous Version

| Issue | Fix |
|-------|-----|
| `TypeError: unsupported operand type(s) for \|: 'type' and 'NoneType'` | Removed all `X \| Y` union type hints — replaced with `Optional[X]` (Python 3.9 compatible) |
| `10^16` on chart axes | `format_short()` now handles K/M/B/T/P scales |
| ABS GBP overflow (>2^53) | Detected and flagged as violations, set to NaN |
| Filter re-renders app on every change | **Apply Filters** button — changes only take effect on click |
| XLSX/CSV slow on re-upload | Auto-converted to Parquet on first load, cached thereafter |
| DuckDB re-registration on every render | DuckDB reads directly from Parquet file via `CREATE VIEW` — registered once |

## Performance Architecture

```
Upload XLSX/CSV
      ↓
Convert to Parquet (zstd compressed)
      ↓
DuckDB: CREATE VIEW tbl AS read_parquet('file.parquet')
      ↓
All tabs: dq("SELECT ... FROM tbl WHERE ...") — zero pandas copy
      ↓
Results rendered in Plotly / AgGrid / st.dataframe
```

## Tabs

| Tab | Contents |
|-----|----------|
| 🧹 Data Quality | Completeness, type violations, outliers, Phase 2 flags |
| 📅 Ageing Validation | Computed vs pre-populated Age Days & Bucket with discrepancy flagging |
| 📈 Break Counts | Break count trends by period, team, rec, asset class |
| 💷 Amount Analysis | ABS GBP trends by period, team, rec |
| 🔍 Jira Factor Analysis | Jira Reference / System to be Fixed driver analysis |
| 🚀 Phase 2 Preview | SSI clustering, BERTopic readiness, root cause population rate |

## Apply Filters Button

Filters in the sidebar do NOT apply immediately.
Only when you click **✅ Apply Filters** do the charts update.
Click **🔄 Reset Filters** to restore all defaults.

## Python Version

Requires Python 3.9+. Tested on Python 3.9, 3.10, 3.11, 3.12.

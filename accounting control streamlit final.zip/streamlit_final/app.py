"""
Accounting Control AI Platform — Phase 1 + Phase 2 Preview
══════════════════════════════════════════════════════════════════════════════
FIXES APPLIED:
  ✅ Python 3.9 compatible — removed all X | Y union type hints (| NoneType error)
  ✅ XLSX/CSV → auto-converted to Parquet on first upload, Parquet used thereafter
  ✅ Apply Filters button — no re-render on filter change (session_state pattern)
  ✅ DuckDB: persistent connection, registered once, zero re-registration on rerender
  ✅ DuckDB: reads directly from Parquet file (fastest possible — no pandas copy)
  ✅ format_short() handles K / M / B / T / P — fixes 10^16 axis labels
  ✅ ABS GBP > 2^53 detected and flagged (JS integer overflow)
  ✅ No Flask, no core/ imports — fully standalone single file
  ✅ from __future__ import annotations at top for forward-ref safety
  ✅ All type hints use Optional[] or removed entirely for 3.9 compat
"""

from __future__ import annotations

import gc
import hashlib
import math
import os
import re
import tempfile
import time
from io import BytesIO
from pathlib import Path
from typing import Optional, Tuple, List, Dict, Any

import duckdb
import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st

try:
    from st_aggrid import AgGrid, GridOptionsBuilder, JsCode
    HAS_AGGRID = True
except ImportError:
    HAS_AGGRID = False

# ── Page config — MUST be first Streamlit call ──────────────────────────────
st.set_page_config(
    page_title="Accounting Control AI Platform",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── Constants ─────────────────────────────────────────────────────────────────
COLORS = [
    "#01696F", "#0C4E54", "#20808D", "#4F98A3", "#A84B2F",
    "#1B474D", "#BCE2E7", "#944454", "#FFC553", "#5C2D91",
]
PRIMARY      = "#01696F"
DARK         = "#28251D"
MUTED        = "#7A7974"
BG_LIGHT     = "#F7F7F5"
WARN         = "#A84B2F"
BUCKET_ORDER = ["0-15", "16-30", "31-60", "61-90", "91-180", "181-365", "365+", "Unknown"]
MAX_JS_INT   = 2 ** 53   # 9,007,199,254,740,992

# Cache dir for Parquet files
_CACHE_DIR = Path(tempfile.gettempdir()) / "acai_parquet_cache"
_CACHE_DIR.mkdir(exist_ok=True)

# ── CSS ───────────────────────────────────────────────────────────────────────
st.markdown(f"""
<style>
  .main .block-container {{padding-top:1rem;padding-bottom:1rem;}}
  h1 {{color:{DARK};font-size:1.6rem !important;}}
  h2 {{color:{DARK};font-size:1.25rem !important;}}
  h3 {{color:{DARK};font-size:1.05rem !important;}}
  .stTabs [data-baseweb="tab-list"] {{gap:8px;}}
  .stTabs [data-baseweb="tab"] {{
      background-color:{BG_LIGHT};border-radius:6px 6px 0 0;
      padding:8px 16px;font-weight:600;color:{DARK};}}
  .stTabs [aria-selected="true"] {{
      background-color:{PRIMARY} !important;color:white !important;}}
  .kpi  {{background:white;border-left:4px solid {PRIMARY};
          padding:12px 16px;border-radius:4px;
          box-shadow:0 1px 3px rgba(0,0,0,.08);margin-bottom:6px;}}
  .kpi-w{{background:white;border-left:4px solid {WARN};
          padding:12px 16px;border-radius:4px;
          box-shadow:0 1px 3px rgba(0,0,0,.08);margin-bottom:6px;}}
  .kpi-label{{color:{MUTED};font-size:.72rem;text-transform:uppercase;
              letter-spacing:.5px;margin:0 0 2px 0;}}
  .kpi-value{{color:{DARK};font-size:1.4rem;font-weight:700;margin:0;}}
  .kpi-delta-p{{color:#A84B2F;font-size:.8rem;}}
  .kpi-delta-n{{color:#01696F;font-size:.8rem;}}
  .b-info  {{background:#E6F4F1;border-left:4px solid {PRIMARY};
             padding:10px 16px;border-radius:4px;margin-bottom:.5rem;
             font-size:.88rem;color:{DARK};}}
  .b-warn  {{background:#FDECEA;border-left:4px solid {WARN};
             padding:10px 16px;border-radius:4px;margin-bottom:.5rem;
             font-size:.88rem;color:{DARK};font-weight:600;}}
  .b-amber {{background:#FFF8E1;border-left:4px solid #FFC553;
             padding:10px 16px;border-radius:4px;margin-bottom:.5rem;
             font-size:.88rem;color:{DARK};}}
  .b-jira  {{background:#E8F4FD;border-left:4px solid #20808D;
             padding:10px 16px;border-radius:4px;margin-bottom:.5rem;
             font-size:.88rem;color:{DARK};}}
  .b-phase2{{background:#F3E8FF;border-left:4px solid #5C2D91;
             padding:10px 16px;border-radius:4px;margin-bottom:.5rem;
             font-size:.88rem;color:{DARK};}}
  div[data-testid="stButton"] button {{
      background-color:{PRIMARY};color:white;border:none;
      padding:8px 24px;border-radius:6px;font-weight:600;
      width:100%;margin-top:8px;}}
  div[data-testid="stButton"] button:hover {{background-color:{DARK};}}
</style>
""", unsafe_allow_html=True)


# ══════════════════════════════════════════════════════════════════════════════
#  UTILITIES
# ══════════════════════════════════════════════════════════════════════════════

def fmts(n, prefix="£") -> str:
    """format_short — K/M/B/T/P — fixes 10^16 axis issue. Python 3.9 safe."""
    if n is None:
        return "N/A"
    try:
        v = float(n)
        if math.isnan(v) or math.isinf(v):
            return "N/A"
    except (TypeError, ValueError):
        return "N/A"
    sign = "-" if v < 0 else ""
    v = abs(v)
    if v == 0:
        return f"{prefix}0"
    if v >= 1e15:
        return f"{sign}{prefix}{v/1e15:.2f}P"
    if v >= 1e12:
        return f"{sign}{prefix}{v/1e12:.2f}T"
    if v >= 1e9:
        return f"{sign}{prefix}{v/1e9:.1f}B"
    if v >= 1e6:
        return f"{sign}{prefix}{v/1e6:.1f}M"
    if v >= 1e3:
        return f"{sign}{prefix}{v/1e3:.1f}K"
    return f"{sign}{prefix}{v:,.2f}"


def fmtn(n, dec=0) -> str:
    if n is None:
        return "N/A"
    try:
        if math.isnan(float(n)):
            return "N/A"
    except (TypeError, ValueError):
        return "N/A"
    return f"{int(n):,}" if dec == 0 else f"{float(n):,.{dec}f}"


def mom_pct(cur, prev) -> Optional[float]:
    if prev is None or prev == 0:
        return None
    return round(((cur - prev) / abs(prev)) * 100, 1)


def kpi(label, value, delta=None, invert=False, warn=False):
    dh = ""
    if delta:
        neg = (str(delta).startswith("-") and not invert) or \
              (not str(delta).startswith("-") and invert)
        css = "kpi-delta-n" if neg else "kpi-delta-p"
        dh  = f'<p class="{css}">{delta}</p>'
    cls = "kpi-w" if warn else "kpi"
    st.markdown(
        f'<div class="{cls}"><p class="kpi-label">{label}</p>'
        f'<p class="kpi-value">{value}</p>{dh}</div>',
        unsafe_allow_html=True)


def banner(cls, html):
    st.markdown(f'<div class="{cls}">{html}</div>', unsafe_allow_html=True)


def chl(fig, title="", xt="", yt="", h=400):
    fig.update_layout(
        title=dict(text=title, font=dict(size=14, color=DARK)),
        xaxis_title=xt, yaxis_title=yt, height=h,
        margin=dict(l=40, r=20, t=50, b=40),
        font=dict(family="Inter, sans-serif", size=11, color=DARK),
        plot_bgcolor="white", paper_bgcolor="white",
        legend=dict(font=dict(size=10)),
    )
    fig.update_xaxes(showgrid=True, gridwidth=1, gridcolor="#ECECEC")
    fig.update_yaxes(showgrid=True, gridwidth=1, gridcolor="#ECECEC")
    return fig


def roll(fig, x, y, w=3, name="Rolling Avg", color=None):
    if len(list(x)) < w:
        return fig
    s = pd.Series(list(y))
    r = s.rolling(w, min_periods=1).mean().round(1)
    fig.add_trace(go.Scatter(
        x=list(x), y=r.tolist(), name=f"{name} ({w}p)",
        mode="lines", line=dict(color=color or COLORS[7], width=2, dash="dot"),
    ))
    return fig


def show_df(df: pd.DataFrame, height=380, key=None, match_cols=None):
    """Show DataFrame — AgGrid if available, else st.dataframe. Safe for large ints."""
    # Sanitise: cast any column with >2^53 values to string
    df_safe = df.copy()
    for col in df_safe.columns:
        if df_safe[col].dtype in (np.int64, np.uint64, np.float64):
            try:
                if (df_safe[col].abs() > MAX_JS_INT).any():
                    df_safe[col] = df_safe[col].apply(
                        lambda x: fmts(x) if pd.notna(x) else "N/A"
                    )
            except Exception:
                pass

    if HAS_AGGRID and len(df_safe):
        gb = GridOptionsBuilder.from_dataframe(df_safe)
        gb.configure_pagination(paginationAutoPageSize=False, paginationPageSize=25)
        gb.configure_default_column(filterable=True, sortable=True, resizable=True,
                                    wrapText=False)
        if match_cols:
            cs = JsCode("""function(p){
                if(p.value===false||p.value==='False')
                    return{'backgroundColor':'#FDECEA','color':'#A84B2F','fontWeight':'bold'};
                if(p.value===true||p.value==='True')
                    return{'backgroundColor':'#E8F5E9','color':'#01696F'};
                return{};}""")
            for c in match_cols:
                if c in df_safe.columns:
                    gb.configure_column(c, cellStyle=cs)
        AgGrid(df_safe, gridOptions=gb.build(), height=height,
               theme="streamlit", key=key, allow_unsafe_jscode=True)
    else:
        st.dataframe(df_safe, height=height, use_container_width=True)


# ══════════════════════════════════════════════════════════════════════════════
#  DUCKDB — PERSISTENT CONNECTION  (registered ONCE, queried many times)
# ══════════════════════════════════════════════════════════════════════════════

@st.cache_resource
def _duck() -> duckdb.DuckDBPyConnection:
    """Single persistent DuckDB in-memory connection. Created once per session."""
    con = duckdb.connect(database=":memory:")
    # Performance settings
    con.execute("PRAGMA threads=4")
    con.execute("PRAGMA memory_limit='2GB'")
    return con


def _register_parquet(parquet_path: str):
    """Register the Parquet file as a DuckDB view — zero-copy, fastest possible."""
    _duck().execute(
        f"CREATE OR REPLACE VIEW tbl AS SELECT * FROM read_parquet('{parquet_path}')"
    )


def dq(sql: str) -> pd.DataFrame:
    """Execute SQL against the registered 'tbl' view. No re-registration needed."""
    return _duck().execute(sql).df()


def dq1(sql: str):
    """Execute SQL, return first row as named tuple / dict."""
    return _duck().execute(sql).fetchone()


# ══════════════════════════════════════════════════════════════════════════════
#  PARQUET PIPELINE  (XLSX/CSV → Parquet → DuckDB view)
# ══════════════════════════════════════════════════════════════════════════════

def _file_hash(b: bytes) -> str:
    return hashlib.sha256(b[:4 * 1024 * 1024] + str(len(b)).encode()).hexdigest()


def _parquet_path(fhash: str) -> str:
    return str(_CACHE_DIR / f"{fhash}.parquet")


# Period / amount / age vectorised helpers ────────────────────────────────────

def _period_to_dt_vec(s: pd.Series) -> pd.Series:
    n = pd.to_numeric(s, errors="coerce")
    yr = (n // 100).astype("Int64")
    mo = (n  % 100).astype("Int64")
    ok = mo.between(1, 12) & yr.notna()
    nm = (mo + 1).where(ok)
    ny = yr.where(ok).copy()
    dec = mo == 12
    nm  = nm.where(~dec, 1)
    ny  = ny.where(~dec, yr + 1)
    res = pd.Series(pd.NaT, index=s.index, dtype="datetime64[ns]")
    vi  = ok[ok].index
    if len(vi):
        ds = ny.loc[vi].astype(str) + "-" + nm.loc[vi].astype(str).str.zfill(2) + "-01"
        res.loc[vi] = pd.to_datetime(ds, errors="coerce") - pd.Timedelta(days=1)
    return res


def _parse_amount(s: pd.Series) -> pd.Series:
    na = s.isna()
    t  = s.astype(str).str.strip()
    t  = t.str.replace(r"[£$€¥,]", "", regex=True)
    t  = t.str.replace(r"(?i)^(GBP|USD|EUR|JPY|CHF|AUD|CAD)\s*", "", regex=True)
    t  = t.str.replace(r"^\((.+)\)$", r"-\1", regex=True)
    r  = pd.to_numeric(t, errors="coerce").astype("float64")
    r[na] = np.nan
    # Flag JS overflow values as NaN
    overflow = r.abs() > MAX_JS_INT
    if overflow.sum():
        st.session_state["_overflow"] = st.session_state.get("_overflow", 0) + int(overflow.sum())
        r[overflow] = np.nan
    return r


def _parse_age(s: pd.Series) -> pd.Series:
    t = s.astype(str).str.strip()
    r = pd.to_numeric(t.str.extract(r"^[~]?(-?\d+)", expand=False), errors="coerce")
    r[s.isna() | t.isin(["", "N/A", "n/a", "-", "nan", "None"])] = np.nan
    return r


def _bucket(age: pd.Series) -> pd.Categorical:
    a  = age.values
    c  = [pd.isna(age), a <= 15, a <= 30, a <= 60, a <= 90, a <= 180, a <= 365]
    ch = ["Unknown", "0-15", "16-30", "31-60", "61-90", "91-180", "181-365"]
    return pd.Categorical(np.select(c, ch, default="365+"),
                          categories=BUCKET_ORDER, ordered=True)


def _drop_blank_trailing(df: pd.DataFrame, n=4) -> Tuple[pd.DataFrame, List[str]]:
    drop = []
    for col in df.columns[-n:]:
        null_p = df[col].isna().mean()
        try:
            blank_p = df[col].astype(str).str.strip().isin(
                ["", "nan", "None", "NaN"]).mean()
        except Exception:
            blank_p = 0.0
        if max(null_p, blank_p) >= 0.95:
            drop.append(col)
    return df.drop(columns=drop), drop


# Column mapping ──────────────────────────────────────────────────────────────

EXPECTED = [
    "Period", "Asset Class", "Team", "Rec Name (as per Rec Cube)", "Entity",
    "Type of break", "Account Group", "Products Reconciled", "TRADE REF",
    "If Duplicate Trade, provide the CC, etc details", "TRADE CCY",
    "BREAK AMOUNT CCY", "BREAK AMOUNT GBP", "Date", "Age Days", "Bucket",
    "True/Systemic Breaks", "Journals Posted", "Comments", "ABS GBP",
    "Root Cause identified", "B/S Cert",
    "Jira Reference", "Jira Desc", "System to be Fixed",
    "ISSUE CATEGORY", "ISSUE CATEGORY2", "JIRA PRIORITY", "EPIC", "For Del",
]


def _fuzzy(cols, target) -> Optional[str]:
    tl = target.lower().strip()
    for c in cols:
        if c.lower().strip() == tl:
            return c
    for c in cols:
        if tl in c.lower() or c.lower() in tl:
            return c
    return None


def _col_map(cols) -> Dict[str, str]:
    result = {}
    for e in EXPECTED:
        m = _fuzzy(cols, e)
        if m:
            result[e] = m
    return result


# SSI / timing / CA keyword flags ─────────────────────────────────────────────

_SSI_KW  = ["ssi", "settlement instruction", "standing instruction",
             "account number", "sort code", "bic", "swift", "nostro"]
_CA_KW   = ["dividend", "split", "ex-date", "corporate action",
             "rights issue", "merger", "spin-off"]
_TIM_KW  = ["timing", "t+1", "t+2", "t+3", "fail", "pending", "settlement timing"]


def _kw_flag(df, col_map, keys, kws) -> pd.Series:
    pat  = "|".join(kws)
    mask = pd.Series(False, index=df.index)
    for k in keys:
        col = col_map.get(k)
        if col and col in df.columns:
            mask |= df[col].astype(str).str.lower().str.contains(pat, regex=True, na=False)
    return mask


# Main pipeline ───────────────────────────────────────────────────────────────

@st.cache_data(show_spinner="⚡ Converting & processing data…")
def _build_parquet(file_bytes: bytes, filename: str) -> Tuple[str, Dict, List, pd.DataFrame, List, int]:
    """
    Full pipeline: raw bytes → cleaned DataFrame → Parquet file.
    Returns (parquet_path, col_map, filter_options_keys, violations_df,
             dropped_cols, filtered_for_del).
    Cached by file content hash.
    """
    st.session_state["_overflow"] = 0

    # 1. Load raw
    buf  = BytesIO(file_bytes)
    name = filename.lower()
    if name.endswith(".parquet"):
        df = pd.read_parquet(buf)
    elif name.endswith(".csv"):
        df = pd.read_csv(buf, low_memory=False)
    else:
        # XLSX / XLS — try calamine first
        try:
            import python_calamine  # noqa
            df = pd.read_excel(buf, engine="calamine")
        except ImportError:
            buf.seek(0)
            df = pd.read_excel(buf, engine="openpyxl")

    # 2. Drop blank trailing columns
    df, dropped_cols = _drop_blank_trailing(df, n=4)

    # 3. Column map
    cm = _col_map(df.columns.tolist())

    # 4. For Del filter (CORRECTION #5)
    filtered_for_del = 0
    fd_col = cm.get("For Del")
    if fd_col and fd_col in df.columns:
        del_mask = df[fd_col].astype(str).str.strip().str.lower().isin(
            {"true", "yes", "y", "1", "x", "delete", "del"})
        filtered_for_del = int(del_mask.sum())
        df = df[~del_mask].copy()

    # 5. Type coercion
    violations = []
    for key in ("BREAK AMOUNT CCY", "BREAK AMOUNT GBP", "ABS GBP"):
        actual = cm.get(key)
        if actual and actual in df.columns:
            orig = df[actual].copy()
            df[actual] = _parse_amount(df[actual])
            bad = orig.notna() & df[actual].isna()
            if bad.sum():
                violations.append({
                    "Column": actual, "Expected Type": "float64",
                    "Violation Count": int(bad.sum()),
                    "Sample Values": ", ".join(orig[bad].head(3).astype(str)),
                })

    age_actual = cm.get("Age Days")
    if age_actual and age_actual in df.columns:
        orig = df[age_actual].copy()
        df[age_actual] = _parse_age(df[age_actual])
        bad = orig.notna() & orig.astype(str).str.strip().ne("") & df[age_actual].isna()
        if bad.sum():
            violations.append({
                "Column": age_actual, "Expected Type": "numeric",
                "Violation Count": int(bad.sum()),
                "Sample Values": ", ".join(orig[bad].head(3).astype(str)),
            })

    date_actual = cm.get("Date")
    if date_actual and date_actual in df.columns:
        df[date_actual] = pd.to_datetime(df[date_actual], errors="coerce")

    # 6. Period helpers
    per_actual = cm.get("Period")
    if per_actual and per_actual in df.columns:
        df["_Period_date"]  = _period_to_dt_vec(df[per_actual])
        df["_Period_label"] = (df["_Period_date"].dt.strftime("%Y-%m")
                               .fillna(df[per_actual].astype(str)))

    # 7. Ageing
    if date_actual and date_actual in df.columns and "_Period_date" in df.columns:
        df["_Computed_Age_Days"] = (df["_Period_date"] - df[date_actual]).dt.days
        df["_Computed_Bucket"]   = _bucket(df["_Computed_Age_Days"])
        if age_actual and age_actual in df.columns:
            df["_Age_Match"] = np.isclose(
                df[age_actual].fillna(-999),
                df["_Computed_Age_Days"].fillna(-998), atol=1)
        bkt_actual = cm.get("Bucket")
        if bkt_actual and bkt_actual in df.columns:
            df["_Bucket_Match"] = (
                df[bkt_actual].astype(str).str.strip()
                == df["_Computed_Bucket"].astype(str).str.strip())

    # 8. Phase 2 flags
    df["_is_timing"] = _kw_flag(df, cm, ["Type of break"], _TIM_KW)
    if "_Computed_Age_Days" in df.columns:
        df["_is_timing"] |= df["_Computed_Age_Days"].fillna(999) <= 3
    bkt_c = cm.get("Bucket")
    if bkt_c and bkt_c in df.columns:
        df["_is_timing"] |= df[bkt_c].astype(str).str.strip() == "0-15"
    df["_has_ssi"] = _kw_flag(df, cm,
                               ["Comments", "Jira Desc", "System to be Fixed"], _SSI_KW)
    df["_has_ca"]  = _kw_flag(df, cm, ["Comments", "Jira Desc"], _CA_KW)
    df["_False_Positive"] = False

    # 9. Categorical → string for Parquet compat
    for col in df.select_dtypes(["category"]).columns:
        df[col] = df[col].astype(str).replace("nan", pd.NA)

    # 10. Save as Parquet (zstd compressed, very fast to read back)
    fhash = _file_hash(file_bytes)
    ppath = _parquet_path(fhash)
    df.to_parquet(ppath, engine="pyarrow", compression="zstd", index=False)

    # 11. Filter options (for sidebar)
    filter_options = {}
    for key in ("Period", "Team", "Rec Name (as per Rec Cube)", "Entity",
                "Asset Class", "Type of break", "True/Systemic Breaks"):
        actual = cm.get(key)
        if actual and actual in df.columns:
            filter_options[key] = sorted(df[actual].dropna().unique().tolist())

    vdf = (pd.DataFrame(violations) if violations
           else pd.DataFrame(columns=["Column", "Expected Type",
                                      "Violation Count", "Sample Values"]))

    # Force GC before returning
    del df
    gc.collect()

    return ppath, cm, filter_options, vdf, dropped_cols, filtered_for_del


# ══════════════════════════════════════════════════════════════════════════════
#  FILTER STATE  (Apply button — no re-render on change)
# ══════════════════════════════════════════════════════════════════════════════

def _init_filter_state(filter_options: Dict[str, List]) -> None:
    """Initialise session state for filter selections (run once after upload)."""
    if "filters_applied" not in st.session_state:
        st.session_state["filters_applied"] = {}
    if "filters_pending" not in st.session_state:
        st.session_state["filters_pending"] = {
            k: list(v) for k, v in filter_options.items()
        }
        st.session_state["filters_applied"] = dict(
            st.session_state["filters_pending"])


def _sidebar_filters(filter_options: Dict, col_map: Dict,
                     abs_col: Optional[str]) -> str:
    """
    Render sidebar filter controls. Returns the WHERE clause string.
    Filters are NOT applied until the user clicks Apply Filters.
    """
    st.sidebar.markdown("---")
    st.sidebar.markdown("### 🔍 Filters")

    pending = st.session_state.get("filters_pending",
                                   {k: list(v) for k, v in filter_options.items()})

    for key, label, wkey in [
        ("Period",                      "Period",        "fp_period"),
        ("Team",                        "Team",          "fp_team"),
        ("Rec Name (as per Rec Cube)",  "Rec Name",      "fp_rec"),
        ("Entity",                      "Entity",        "fp_entity"),
        ("Asset Class",                 "Asset Class",   "fp_ac"),
        ("Type of break",               "Type of Break", "fp_tob"),
        ("True/Systemic Breaks",        "True/Systemic", "fp_ts"),
    ]:
        opts = filter_options.get(key, [])
        if not opts:
            continue
        sel = st.sidebar.multiselect(
            label, opts,
            default=pending.get(key, opts),
            key=wkey,
        )
        pending[key] = sel

    abs_thresh = st.sidebar.number_input(
        "Min ABS GBP (£)", min_value=0.0, value=0.0,
        step=1000.0, format="%.0f", key="fp_abs")
    pending["_abs_thresh"] = abs_thresh

    excl_fp = st.sidebar.checkbox("Exclude False Positives", False, key="fp_excl")
    pending["_excl_fp"] = excl_fp

    st.session_state["filters_pending"] = pending

    if st.sidebar.button("✅ Apply Filters", key="apply_filters_btn"):
        st.session_state["filters_applied"] = dict(pending)
        st.rerun()

    if st.sidebar.button("🔄 Reset Filters", key="reset_filters_btn"):
        st.session_state["filters_applied"] = {
            k: list(v) for k, v in filter_options.items()
        }
        st.session_state["filters_applied"]["_abs_thresh"] = 0.0
        st.session_state["filters_applied"]["_excl_fp"]    = False
        st.session_state["filters_pending"] = dict(
            st.session_state["filters_applied"])
        st.rerun()

    # Build WHERE from APPLIED (not pending) selections
    applied = st.session_state.get("filters_applied", {})
    parts   = []
    for key, label, _ in [
        ("Period",                      "Period",   ""),
        ("Team",                        "Team",     ""),
        ("Rec Name (as per Rec Cube)",  "RecName",  ""),
        ("Entity",                      "Entity",   ""),
        ("Asset Class",                 "AC",       ""),
        ("Type of break",               "TOB",      ""),
        ("True/Systemic Breaks",        "TS",       ""),
    ]:
        sel  = applied.get(key)
        opts = filter_options.get(key, [])
        actual = col_map.get(key)
        if sel is not None and opts and actual and len(sel) < len(opts):
            esc     = [str(v).replace("'", "''") for v in sel]
            in_list = ", ".join(f"'{v}'" for v in esc)
            parts.append(f'"{actual}" IN ({in_list})')

    thresh = applied.get("_abs_thresh", 0)
    if thresh and thresh > 0 and abs_col:
        parts.append(f'ABS(TRY_CAST("{abs_col}" AS DOUBLE)) >= {thresh}')

    if applied.get("_excl_fp"):
        parts.append('"_False_Positive" = false')

    where = "WHERE " + " AND ".join(parts) if parts else ""
    return where


# Safe amount expression for DuckDB SQL
def _amt(col: str) -> str:
    return f'TRY_CAST("{col}" AS DOUBLE)'


# ══════════════════════════════════════════════════════════════════════════════
#  TAB 1 — DATA QUALITY
# ══════════════════════════════════════════════════════════════════════════════

def tab_data_quality(cm, vdf, dropped_cols, filtered_for_del, where):
    st.markdown("## Data Quality & Ingestion Scorecard")

    overflow = st.session_state.get("_overflow", 0)
    if overflow:
        banner("b-warn",
               f"⚠️ <b>Amount Overflow:</b> {fmtn(overflow)} ABS GBP values exceeded "
               f"2^53 (JS integer max). Set to NaN. Check if amounts are stored in pence.")
    vcount = int(vdf["Violation Count"].sum()) if len(vdf) else 0
    if vcount:
        banner("b-warn",
               f"⚠️ {fmtn(vcount)} type violations across {len(vdf)} column(s).")
    if dropped_cols:
        banner("b-info",
               f"🗑️ Auto-removed {len(dropped_cols)} blank trailing column(s): "
               f"{', '.join(dropped_cols)}")
    if filtered_for_del:
        banner("b-info",
               f"✅ For Del filter removed {fmtn(filtered_for_del)} records before processing.")

    stats = dq(f"SELECT COUNT(*) AS n, COUNT(*)/COUNT(*) AS dummy FROM tbl {where}")
    n_rows = int(dq(f"SELECT COUNT(*) AS n FROM tbl {where}").iloc[0]["n"])

    # Completeness via DuckDB — much faster than df.notna() on 600K rows
    all_cols = dq("SELECT * FROM tbl LIMIT 0").columns.tolist()
    visible  = [c for c in all_cols if not c.startswith("_")]
    exprs    = ", ".join(
        f'ROUND(100.0*COUNT("{c}")/COUNT(*),1) AS "{c}"' for c in visible)
    comp_row = dq(f"SELECT {exprs} FROM tbl {where}")
    overall_comp = round(float(comp_row.values.mean()), 1)

    c1, c2, c3, c4, c5 = st.columns(5)
    with c1: kpi("Total Records",   fmtn(n_rows))
    with c2: kpi("Columns",         str(len(visible)))
    with c3: kpi("Completeness",    f"{overall_comp}%")
    with c4: kpi("Type Violations", fmtn(vcount), warn=vcount > 0, invert=True)
    with c5: kpi("For Del Removed", fmtn(filtered_for_del))

    st.markdown("---")
    cl, cr = st.columns(2)

    with cl:
        st.markdown("### Column Completeness")
        comp_df = comp_row.T.reset_index()
        comp_df.columns = ["Column", "Completeness %"]
        comp_df = comp_df.sort_values("Completeness %", ascending=True)
        fig = px.bar(comp_df, x="Completeness %", y="Column",
                     orientation="h", color_discrete_sequence=[PRIMARY])
        fig = chl(fig, "Per-Column Completeness (%)", "Completeness %",
                  h=max(320, len(comp_df) * 16))
        fig.update_layout(yaxis=dict(tickfont=dict(size=9)))
        st.plotly_chart(fig, use_container_width=True)

    with cr:
        st.markdown("### Type Violation Details")
        if vcount:
            show_df(vdf, height=200, key="tv")
        else:
            st.success("✅ No type violations detected.")

        st.markdown("### Outlier Detection (IQR)")
        out_rows = []
        for key in ("BREAK AMOUNT CCY", "BREAK AMOUNT GBP", "ABS GBP", "Age Days"):
            actual = cm.get(key)
            if not actual:
                continue
            try:
                row = dq(f"""
                    SELECT QUANTILE_CONT({_amt(actual)}, 0.25) AS q1,
                           QUANTILE_CONT({_amt(actual)}, 0.75) AS q3,
                           COUNT(*) AS n
                    FROM tbl {where}
                    WHERE {_amt(actual)} IS NOT NULL
                """).iloc[0]
                q1, q3, n = float(row["q1"] or 0), float(row["q3"] or 0), int(row["n"])
                if n < 20 or q3 == q1:
                    continue
                iqr = q3 - q1
                lo, hi = q1 - 1.5 * iqr, q3 + 1.5 * iqr
                cnt = int(dq(f"""
                    SELECT COUNT(*) AS c FROM tbl {where}
                    WHERE {_amt(actual)} < {lo} OR {_amt(actual)} > {hi}
                """).iloc[0]["c"])
                if cnt:
                    out_rows.append({
                        "Column":       actual,
                        "Outlier Count": cnt,
                        "Outlier %":    round(cnt / n * 100, 2),
                        "IQR Lower":    fmts(lo),
                        "IQR Upper":    fmts(hi),
                    })
            except Exception:
                pass
        if out_rows:
            show_df(pd.DataFrame(out_rows), height=180, key="ol")
        else:
            st.info("No significant outliers detected.")

    st.markdown("### Numeric Summary Statistics")
    num_cols = [c for c in visible if c not in ("_Period_label",)]
    try:
        num_exprs = ", ".join(
            f"AVG({_amt(c)}) AS avg_{i}, "
            f"MIN({_amt(c)}) AS min_{i}, "
            f"MAX({_amt(c)}) AS max_{i}, "
            f"STDDEV({_amt(c)}) AS std_{i}"
            for i, c in enumerate(
                [c for c in num_cols
                 if dq(f"SELECT typeof(\"{c}\") AS t FROM tbl LIMIT 1").iloc[0]["t"]
                 in ("DOUBLE", "INTEGER", "BIGINT", "FLOAT", "HUGEINT")][:10]
            )
        )
    except Exception:
        num_exprs = None

    # Simpler: use pandas describe on a small sample
    sample = dq(f"SELECT * FROM tbl {where} LIMIT 50000")
    num_s  = sample.select_dtypes(include=[np.number])
    num_s  = num_s[[c for c in num_s.columns if not c.startswith("_")]]
    if len(num_s.columns):
        desc = num_s.describe().T.round(2).reset_index().rename(columns={"index": "Column"})
        for col in desc.columns:
            if col != "Column":
                desc[col] = desc[col].apply(
                    lambda x: fmts(x) if isinstance(x, float) and abs(x) > 1e9 else x
                )
        show_df(desc, height=260, key="ns")

    st.markdown("### Phase 2 Readiness Flags")
    flag_row = dq(f"""
        SELECT COUNT(*) FILTER (WHERE "_is_timing") AS tim,
               COUNT(*) FILTER (WHERE "_has_ssi")   AS ssi,
               COUNT(*) FILTER (WHERE "_has_ca")    AS ca,
               COUNT(*)                             AS total
        FROM tbl {where}
    """).iloc[0]
    n_tot = int(flag_row["total"]) or 1
    fd = [
        {"Flag": "Timing Candidate (#1)",
         "Count": int(flag_row["tim"]),
         "Pct": f"{round(int(flag_row['tim'])/n_tot*100,1)}%",
         "Phase 2 Action": "Auto-classify as Timing — no LLM needed"},
        {"Flag": "SSI Signal (#2)",
         "Count": int(flag_row["ssi"]),
         "Pct": f"{round(int(flag_row['ssi'])/n_tot*100,1)}%",
         "Phase 2 Action": "SSI Clustering — one SSI fix closes 15-50 breaks"},
        {"Flag": "CA Signal (#6)",
         "Count": int(flag_row["ca"]),
         "Pct": f"{round(int(flag_row['ca'])/n_tot*100,1)}%",
         "Phase 2 Action": "Corporate Action root cause classification"},
    ]
    st.dataframe(pd.DataFrame(fd), use_container_width=True)
    pareto = round((int(flag_row["tim"]) + int(flag_row["ssi"])) / n_tot * 100, 1)
    banner("b-info",
           f"💡 <b>Pareto Coverage:</b> {pareto}% of breaks pre-classified for "
           f"Timing + SSI auto-resolution in Phase 2 — without LLM cost.")

    st.markdown("---")
    dl1, dl2 = st.columns(2)
    with dl1:
        # Download filtered CSV
        dl_df = dq(f"SELECT * FROM tbl {where} LIMIT 200000")
        st.download_button("📥 Download Cleaned CSV",
                           dl_df.to_csv(index=False).encode("utf-8"),
                           file_name="cleaned_data.csv", mime="text/csv")
    with dl2:
        # Download as Parquet for fast future uploads
        buf = BytesIO()
        dl_df.to_parquet(buf, index=False, compression="zstd")
        st.download_button("⚡ Download as Parquet (fast future uploads)",
                           buf.getvalue(),
                           file_name="cleaned_data.parquet",
                           mime="application/octet-stream")


# ══════════════════════════════════════════════════════════════════════════════
#  TAB 2 — AGEING VALIDATION
# ══════════════════════════════════════════════════════════════════════════════

def tab_ageing(cm, where):
    st.markdown("## Ageing Validation")

    age_col = cm.get("Age Days")
    bkt_col = cm.get("Bucket")
    team_col = cm.get("Team")
    rec_col  = cm.get("Rec Name (as per Rec Cube)")

    cols = dq("SELECT * FROM tbl LIMIT 0").columns.tolist()
    has_ageing = all(c in cols for c in
                     ["_Computed_Age_Days", "_Computed_Bucket",
                      "_Age_Match", "_Bucket_Match"])
    if not has_ageing:
        banner("b-warn", "⚠️ Period and Date columns required for ageing validation.")
        return

    krow = dq(f"""
        SELECT
            COUNT(*) FILTER (WHERE _Computed_Age_Days IS NOT NULL
                AND "{age_col}" IS NOT NULL) AS total_valid,
            COUNT(*) FILTER (WHERE _Age_Match=false
                AND _Computed_Age_Days IS NOT NULL) AS age_mis,
            COUNT(*) FILTER (WHERE _Bucket_Match=false
                AND _Computed_Age_Days IS NOT NULL) AS bkt_mis
        FROM tbl {where}
    """).iloc[0]

    n   = int(krow["total_valid"])
    am  = int(krow["age_mis"])
    bm  = int(krow["bkt_mis"])
    ap  = round(am / n * 100, 1) if n else 0
    bp  = round(bm / n * 100, 1) if n else 0
    acc = round(100 - max(ap, bp), 1)

    c1, c2, c3, c4 = st.columns(4)
    with c1: kpi("Records Validated",    fmtn(n))
    with c2: kpi("Age Discrepancies",    f"{fmtn(am)} ({ap}%)", warn=ap > 5, invert=True)
    with c3: kpi("Bucket Discrepancies", f"{fmtn(bm)} ({bp}%)", warn=bp > 5, invert=True)
    with c4: kpi("Accuracy Rate",        f"{acc}%")

    st.markdown("---")
    st.markdown("### Discrepancy Records — Flag False Positives")
    banner("b-amber",
           "💡 <b>False Positive Flagging:</b> Tick the checkbox to mark records as "
           "known exceptions. Use sidebar 'Exclude False Positives' to apply globally.")

    sel_cols = ", ".join(
        f'"{cm[k]}"' for k in
        ["Period", "Team", "Rec Name (as per Rec Cube)", "Entity", "Date", "TRADE REF"]
        if k in cm and cm[k] in cols
    )
    w_disc = where.replace("WHERE", "WHERE (") + " AND" if where else "WHERE ("
    disc = dq(f"""
        SELECT {sel_cols},
               "{age_col}" AS "Age Days (Source)",
               _Computed_Age_Days AS "Age Days (Computed)",
               "{bkt_col}"        AS "Bucket (Source)",
               _Computed_Bucket   AS "Bucket (Computed)",
               _Age_Match         AS "Age Match",
               _Bucket_Match      AS "Bucket Match",
               _False_Positive    AS "False Positive"
        FROM tbl
        {where} {"AND" if where else "WHERE"}
        (_Age_Match=false OR _Bucket_Match=false)
        AND _Computed_Age_Days IS NOT NULL
        ORDER BY _Computed_Age_Days DESC LIMIT 500
    """)

    if len(disc):
        fp_ed = st.data_editor(
            disc,
            column_config={
                "False Positive": st.column_config.CheckboxColumn("False Positive?"),
                "Age Match":      st.column_config.CheckboxColumn("Age Match"),
                "Bucket Match":   st.column_config.CheckboxColumn("Bucket Match"),
            },
            use_container_width=True, height=400,
            num_rows="fixed", key="fp_editor",
        )
        fp_n = int(fp_ed["False Positive"].sum())
        fc1, fc2, fc3 = st.columns(3)
        with fc1: kpi("Total Discrepancies",    fmtn(len(disc)))
        with fc2: kpi("Flagged False Positive", fmtn(fp_n))
        with fc3: kpi("Net Outstanding",        fmtn(len(disc) - fp_n),
                      warn=(len(disc) - fp_n > 0))
    else:
        st.success("✅ No discrepancies found!")
        disc = pd.DataFrame()

    # Charts
    st.markdown("---")
    cl, cr = st.columns(2)
    with cl:
        hist = dq(f"""
            SELECT "{age_col}" AS prepop, _Computed_Age_Days AS computed
            FROM tbl {where}
            WHERE _Computed_Age_Days IS NOT NULL AND "{age_col}" IS NOT NULL
        """)
        fig = go.Figure()
        fig.add_trace(go.Histogram(x=hist["prepop"], name="Pre-populated",
                                   opacity=0.6, marker_color=COLORS[0], nbinsx=50))
        fig.add_trace(go.Histogram(x=hist["computed"], name="Computed",
                                   opacity=0.6, marker_color=COLORS[4], nbinsx=50))
        fig.update_layout(barmode="overlay")
        fig = chl(fig, "Age Days: Computed vs Pre-populated", "Age Days", "Count")
        st.plotly_chart(fig, use_container_width=True)

    with cr:
        bkt_cmp = dq(f"""
            SELECT _Computed_Bucket AS bucket, COUNT(*) AS computed FROM tbl {where}
            WHERE _Computed_Age_Days IS NOT NULL GROUP BY _Computed_Bucket
        """).merge(
            dq(f'SELECT "{bkt_col}" AS bucket, COUNT(*) AS prepop '
               f'FROM tbl {where} GROUP BY "{bkt_col}"'),
            on="bucket", how="outer").fillna(0)
        bkt_cmp["bucket"] = pd.Categorical(bkt_cmp["bucket"],
                                            categories=BUCKET_ORDER, ordered=True)
        bkt_cmp = bkt_cmp.sort_values("bucket")
        fig = go.Figure()
        fig.add_trace(go.Bar(x=bkt_cmp["bucket"], y=bkt_cmp["prepop"],
                             name="Pre-populated", marker_color=COLORS[0]))
        fig.add_trace(go.Bar(x=bkt_cmp["bucket"], y=bkt_cmp["computed"],
                             name="Computed", marker_color=COLORS[4]))
        fig.update_layout(barmode="group")
        fig = chl(fig, "Bucket Distribution Comparison", "Bucket", "Count")
        st.plotly_chart(fig, use_container_width=True)

    if team_col and team_col in cols:
        st.markdown("### Discrepancy Rate by Team")
        td = dq(f"""
            SELECT "{team_col}" AS team, COUNT(*) AS total,
                   COUNT(*) FILTER (WHERE _Age_Match=false)    AS am,
                   COUNT(*) FILTER (WHERE _Bucket_Match=false) AS bm
            FROM tbl {where} WHERE _Computed_Age_Days IS NOT NULL
            GROUP BY "{team_col}" ORDER BY total DESC
        """)
        td["Age Disc %"]    = (td["am"] / td["total"] * 100).round(1)
        td["Bucket Disc %"] = (td["bm"] / td["total"] * 100).round(1)
        fig = go.Figure()
        fig.add_trace(go.Bar(x=td["team"], y=td["Age Disc %"],
                             name="Age Disc %", marker_color=COLORS[0]))
        fig.add_trace(go.Bar(x=td["team"], y=td["Bucket Disc %"],
                             name="Bucket Disc %", marker_color=COLORS[4]))
        fig.update_layout(barmode="group")
        fig = chl(fig, "Discrepancy Rate by Team (%)", "Team", "Disc %")
        st.plotly_chart(fig, use_container_width=True)

    # Ageing trend
    if "_Period_label" in cols:
        st.markdown("---")
        st.markdown("## Break Ageing Trends")
        period_order = sorted(
            dq("SELECT DISTINCT _Period_label FROM tbl WHERE _Period_label IS NOT NULL")
            ["_Period_label"].tolist()
        )
        ct1, ct2 = st.columns(2)
        with ct1:
            tr = dq(f"""
                SELECT _Period_label AS p,
                       AVG(_Computed_Age_Days) AS mean_age,
                       MEDIAN(_Computed_Age_Days) AS med_age
                FROM tbl {where} WHERE _Computed_Age_Days IS NOT NULL
                GROUP BY _Period_label ORDER BY _Period_label
            """)
            fig = go.Figure()
            fig.add_trace(go.Bar(x=tr["p"], y=tr["mean_age"], name="Mean",
                                 marker_color=COLORS[0], opacity=0.7))
            fig.add_trace(go.Scatter(x=tr["p"], y=tr["med_age"], name="Median",
                                     line=dict(color=COLORS[4], width=2),
                                     mode="lines+markers"))
            fig = roll(fig, tr["p"], tr["mean_age"])
            fig = chl(fig, "Average Age Days Trend", "Period", "Days")
            st.plotly_chart(fig, use_container_width=True)

        with ct2:
            bt = dq(f"""
                SELECT _Period_label AS p, _Computed_Bucket AS bkt, COUNT(*) AS cnt
                FROM tbl {where} WHERE _Computed_Age_Days IS NOT NULL
                GROUP BY _Period_label, _Computed_Bucket
            """)
            bt["bkt"] = pd.Categorical(bt["bkt"], categories=BUCKET_ORDER, ordered=True)
            fig = px.bar(bt, x="p", y="cnt", color="bkt",
                         color_discrete_sequence=COLORS, barmode="stack",
                         category_orders={"p": period_order, "bkt": BUCKET_ORDER})
            fig = chl(fig, "Bucket Distribution Over Time", "Period", "Count")
            st.plotly_chart(fig, use_container_width=True)

        ct3, ct4 = st.columns(2)
        with ct3:
            risk = dq(f"""
                SELECT _Period_label AS p, COUNT(*) AS total,
                       COUNT(*) FILTER (WHERE _Computed_Age_Days>90)  AS o90,
                       COUNT(*) FILTER (WHERE _Computed_Age_Days>365) AS o365
                FROM tbl {where} WHERE _Computed_Age_Days IS NOT NULL
                GROUP BY _Period_label ORDER BY _Period_label
            """)
            risk[">90%"]  = (risk["o90"]  / risk["total"] * 100).round(1)
            risk[">365%"] = (risk["o365"] / risk["total"] * 100).round(1)
            fig = go.Figure()
            fig.add_trace(go.Scatter(x=risk["p"], y=risk[">90%"],  name="> 90 Days",
                                     line=dict(color=COLORS[4], width=2),
                                     fill="tozeroy", fillcolor="rgba(168,75,47,.15)"))
            fig.add_trace(go.Scatter(x=risk["p"], y=risk[">365%"], name="> 365 Days",
                                     line=dict(color=COLORS[7], width=2),
                                     fill="tozeroy", fillcolor="rgba(148,68,84,.15)"))
            fig = chl(fig, "High-Risk Ageing Proportion", "Period", "% of Breaks")
            st.plotly_chart(fig, use_container_width=True)

        with ct4:
            p90 = dq(f"""
                SELECT _Period_label AS p,
                       QUANTILE_CONT(_Computed_Age_Days, 0.9) AS p90
                FROM tbl {where} WHERE _Computed_Age_Days IS NOT NULL
                GROUP BY _Period_label ORDER BY _Period_label
            """)
            fig = go.Figure()
            fig.add_trace(go.Scatter(x=p90["p"], y=p90["p90"].round(0),
                                     mode="lines+markers+text",
                                     text=p90["p90"].round(0).astype(int).astype(str),
                                     textposition="top center",
                                     line=dict(color=COLORS[4], width=2.5),
                                     name="P90 Age Days"))
            fig = roll(fig, p90["p"], p90["p90"])
            fig = chl(fig, "90th Percentile Age Days Trend", "Period", "Days")
            st.plotly_chart(fig, use_container_width=True)

    if len(disc):
        st.download_button("📥 Download Discrepancy Report",
                           disc.to_csv(index=False).encode("utf-8"),
                           file_name="ageing_discrepancy.csv", mime="text/csv")


# ══════════════════════════════════════════════════════════════════════════════
#  TAB 3 — BREAK COUNTS
# ══════════════════════════════════════════════════════════════════════════════

def tab_break_counts(cm, where):
    st.markdown("## Trend Analysis: Break Counts")

    cols = dq("SELECT * FROM tbl LIMIT 0").columns.tolist()
    period_col = cm.get("Period")
    team_col   = cm.get("Team")
    rec_col    = cm.get("Rec Name (as per Rec Cube)")
    ac_col     = cm.get("Asset Class")
    ts_col     = cm.get("True/Systemic Breaks")
    bkt_col    = cm.get("Bucket")

    if not period_col or "_Period_label" not in cols:
        banner("b-warn", "⚠️ Period column not found."); return

    period_order = sorted(
        dq("SELECT DISTINCT _Period_label FROM tbl WHERE _Period_label IS NOT NULL")
        ["_Period_label"].tolist())
    latest = period_order[-1] if period_order else "0"
    prev   = period_order[-2] if len(period_order) >= 2 else "0"

    krow = dq(f"""
        SELECT COUNT(*) AS total,
               COUNT(*) FILTER (WHERE _Period_label='{latest}') AS lat,
               COUNT(*) FILTER (WHERE _Period_label='{prev}')   AS prv
        FROM tbl {where}
    """).iloc[0]
    m = mom_pct(int(krow["lat"]), int(krow["prv"]))

    c1, c2, c3, c4 = st.columns(4)
    with c1: kpi("Total Breaks",  fmtn(krow["total"]))
    with c2: kpi("Latest Period", fmtn(krow["lat"]),
                 f"{'+'if m and m>0 else ''}{m}% MoM" if m else None,
                 invert=True, warn=(m is not None and m > 15))
    with c3: kpi("Avg/Period",
                 fmtn(round(int(krow["total"]) / max(len(period_order), 1))))
    with c4: kpi("Periods", str(len(period_order)))

    st.markdown("---")
    ca, cb = st.columns(2)
    with ca:
        p_df = dq(f"""
            SELECT _Period_label AS p, COUNT(*) AS cnt
            FROM tbl {where} GROUP BY _Period_label ORDER BY _Period_label
        """)
        fig = go.Figure()
        fig.add_trace(go.Bar(x=p_df["p"], y=p_df["cnt"], name="Count",
                             marker_color=COLORS[0], opacity=0.7))
        fig.add_trace(go.Scatter(x=p_df["p"], y=p_df["cnt"], name="Actual",
                                 line=dict(color=COLORS[4], width=2),
                                 mode="lines+markers"))
        fig = roll(fig, p_df["p"], p_df["cnt"])
        fig = chl(fig, "Break Count Trend by Period", "Period", "Count")
        st.plotly_chart(fig, use_container_width=True)

    with cb:
        if team_col and team_col in cols:
            t_df = dq(f"""
                SELECT "{team_col}" AS team, _Period_label AS p, COUNT(*) AS cnt
                FROM tbl {where} GROUP BY "{team_col}", _Period_label ORDER BY _Period_label
            """)
            fig = px.bar(t_df, x="p", y="cnt", color="team",
                         color_discrete_sequence=COLORS, barmode="group")
            fig = chl(fig, "Break Count by Team", "Period", "Count")
            st.plotly_chart(fig, use_container_width=True)

    cc, cd = st.columns(2)
    with cc:
        if rec_col and rec_col in cols:
            top10 = dq(f"""
                SELECT "{rec_col}" AS r FROM tbl {where}
                GROUP BY "{rec_col}" ORDER BY COUNT(*) DESC LIMIT 10
            """)["r"].tolist()
            in_list = ", ".join(f"'{str(r).replace(chr(39),chr(39)*2)}'" for r in top10)
            r_df = dq(f"""
                SELECT "{rec_col}" AS rec, _Period_label AS p, COUNT(*) AS cnt
                FROM tbl {where} {"AND" if where else "WHERE"} "{rec_col}" IN ({in_list})
                GROUP BY "{rec_col}", _Period_label ORDER BY _Period_label
            """)
            fig = px.line(r_df, x="p", y="cnt", color="rec",
                          color_discrete_sequence=COLORS, markers=True)
            fig = chl(fig, "Top 10 Rec Names — Count Over Periods", "Period", "Count")
            st.plotly_chart(fig, use_container_width=True)

    with cd:
        if ts_col and ts_col in cols:
            ts_df = dq(f"""
                SELECT "{ts_col}" AS ts, _Period_label AS p, COUNT(*) AS cnt
                FROM tbl {where} GROUP BY "{ts_col}", _Period_label ORDER BY _Period_label
            """)
            fig = px.bar(ts_df, x="p", y="cnt", color="ts",
                         color_discrete_sequence=COLORS, barmode="stack")
            fig = chl(fig, "True vs Systemic Breaks", "Period", "Count")
            st.plotly_chart(fig, use_container_width=True)

    ce, cf = st.columns(2)
    with ce:
        if ac_col and ac_col in cols:
            ac_df = dq(f"""
                SELECT "{ac_col}" AS ac, _Period_label AS p, COUNT(*) AS cnt
                FROM tbl {where} GROUP BY "{ac_col}", _Period_label ORDER BY _Period_label
            """)
            fig = px.bar(ac_df, x="p", y="cnt", color="ac",
                         color_discrete_sequence=COLORS, barmode="stack")
            fig = chl(fig, "Break Count by Asset Class", "Period", "Count")
            st.plotly_chart(fig, use_container_width=True)

    with cf:
        if bkt_col and bkt_col in cols:
            bk_df = dq(f"""
                SELECT "{bkt_col}" AS bkt, _Period_label AS p, COUNT(*) AS cnt
                FROM tbl {where} GROUP BY "{bkt_col}", _Period_label ORDER BY _Period_label
            """)
            bk_df["bkt"] = pd.Categorical(bk_df["bkt"],
                                           categories=BUCKET_ORDER, ordered=True)
            fig = px.bar(bk_df, x="p", y="cnt", color="bkt",
                         color_discrete_sequence=COLORS, barmode="stack",
                         category_orders={"bkt": BUCKET_ORDER})
            fig = chl(fig, "Break Bucket Distribution", "Period", "Count")
            st.plotly_chart(fig, use_container_width=True)


# ══════════════════════════════════════════════════════════════════════════════
#  TAB 4 — AMOUNT ANALYSIS
# ══════════════════════════════════════════════════════════════════════════════

def tab_amounts(cm, where):
    st.markdown("## Trend Analysis: Break Amounts")

    cols   = dq("SELECT * FROM tbl LIMIT 0").columns.tolist()
    abs_c  = cm.get("ABS GBP")
    gbp_c  = cm.get("BREAK AMOUNT GBP")
    amt_c  = abs_c if abs_c and abs_c in cols else gbp_c
    team_c = cm.get("Team")
    ts_c   = cm.get("True/Systemic Breaks")
    rec_c  = cm.get("Rec Name (as per Rec Cube)")

    if not amt_c or amt_c not in cols:
        banner("b-warn", "⚠️ ABS GBP / BREAK AMOUNT GBP column not found."); return
    if "_Period_label" not in cols:
        banner("b-warn", "⚠️ Period label not available."); return

    period_order = sorted(
        dq("SELECT DISTINCT _Period_label FROM tbl WHERE _Period_label IS NOT NULL")
        ["_Period_label"].tolist())
    latest = period_order[-1] if period_order else "0"
    prev   = period_order[-2] if len(period_order) >= 2 else "0"

    ae = _amt(amt_c)  # safe TRY_CAST expression
    krow = dq(f"""
        SELECT SUM(ABS({ae})) AS total, AVG(ABS({ae})) AS avg,
               MAX(ABS({ae})) AS max_v,
               SUM(ABS({ae})) FILTER (WHERE _Period_label='{latest}') AS lat,
               SUM(ABS({ae})) FILTER (WHERE _Period_label='{prev}')   AS prv
        FROM tbl {where}
    """).iloc[0]
    m = mom_pct(float(krow["lat"] or 0), float(krow["prv"] or 0))

    c1, c2, c3, c4 = st.columns(4)
    with c1: kpi("Total ABS GBP",    fmts(krow["total"]))
    with c2: kpi("Latest Period",    fmts(krow["lat"]),
                 f"{'+'if m and m>0 else ''}{m}% MoM" if m else None,
                 invert=True, warn=(m is not None and m > 15))
    with c3: kpi("Avg Break Amount", fmts(krow["avg"]))
    with c4: kpi("Max Single Break", fmts(krow["max_v"]))

    st.markdown("---")
    ca, cb = st.columns(2)
    with ca:
        p_df = dq(f"""
            SELECT _Period_label AS p, SUM(ABS({ae})) AS total
            FROM tbl {where} GROUP BY _Period_label ORDER BY _Period_label
        """)
        p_df["lbl"] = p_df["total"].apply(fmts)
        fig = go.Figure()
        fig.add_trace(go.Bar(x=p_df["p"], y=p_df["total"], name="Total ABS GBP",
                             marker_color=COLORS[0], opacity=0.7,
                             text=p_df["lbl"], textposition="outside"))
        fig.add_trace(go.Scatter(x=p_df["p"], y=p_df["total"], name="Actual",
                                 mode="lines+markers",
                                 line=dict(color=COLORS[4], width=2)))
        fig = roll(fig, p_df["p"], p_df["total"])
        max_y = float(p_df["total"].max() or 0)
        if max_y > 1e12:
            fig.update_yaxes(tickformat=".2s")
        fig = chl(fig, "Total ABS GBP by Period", "Period", "GBP (£)")
        st.plotly_chart(fig, use_container_width=True)

    with cb:
        if team_c and team_c in cols:
            t_df = dq(f"""
                SELECT "{team_c}" AS team, _Period_label AS p, SUM(ABS({ae})) AS total
                FROM tbl {where} GROUP BY "{team_c}", _Period_label ORDER BY _Period_label
            """)
            fig = px.bar(t_df, x="p", y="total", color="team",
                         color_discrete_sequence=COLORS, barmode="group")
            fig = chl(fig, "ABS GBP by Team", "Period", "GBP (£)")
            st.plotly_chart(fig, use_container_width=True)

    cc, cd = st.columns(2)
    with cc:
        if ts_c and ts_c in cols:
            ts_df = dq(f"""
                SELECT "{ts_c}" AS ts, _Period_label AS p, SUM(ABS({ae})) AS total
                FROM tbl {where} GROUP BY "{ts_c}", _Period_label ORDER BY _Period_label
            """)
            fig = px.bar(ts_df, x="p", y="total", color="ts",
                         color_discrete_sequence=COLORS, barmode="stack")
            fig = chl(fig, "ABS GBP: True vs Systemic", "Period", "GBP (£)")
            st.plotly_chart(fig, use_container_width=True)

    with cd:
        if rec_c and rec_c in cols:
            r_df = dq(f"""
                SELECT "{rec_c}" AS rec, SUM(ABS({ae})) AS total
                FROM tbl {where} GROUP BY "{rec_c}" ORDER BY total DESC LIMIT 10
            """).sort_values("total", ascending=True)
            r_df["lbl"] = r_df["total"].apply(fmts)
            fig = px.bar(r_df, x="total", y="rec", orientation="h",
                         color_discrete_sequence=[COLORS[0]])
            fig.update_traces(text=r_df["lbl"], textposition="outside")
            fig = chl(fig, "Top 10 Rec Names by ABS GBP", "GBP (£)", "",
                      h=max(300, len(r_df) * 32))
            st.plotly_chart(fig, use_container_width=True)


# ══════════════════════════════════════════════════════════════════════════════
#  TAB 5 — JIRA FACTOR ANALYSIS
# ══════════════════════════════════════════════════════════════════════════════

def tab_jira(cm, where):
    st.markdown("## Jira Factor Analysis")
    banner("b-jira",
           "🔍 <b>Factor Analysis:</b> Identify which Jira tickets, issue descriptions, "
           "and systems are driving the highest break volumes and worst ageing. "
           "Switch dimensions using the selector below.")

    cols = dq("SELECT * FROM tbl LIMIT 0").columns.tolist()
    abs_c = cm.get("ABS GBP") or cm.get("BREAK AMOUNT GBP")

    all_dims = {}
    for label, key in [
        ("Jira Reference",     "Jira Reference"),
        ("Jira Description",   "Jira Desc"),
        ("System to be Fixed", "System to be Fixed"),
        ("Issue Category",     "ISSUE CATEGORY"),
        ("Issue Category 2",   "ISSUE CATEGORY2"),
        ("Team",               "Team"),
        ("Rec Name",           "Rec Name (as per Rec Cube)"),
        ("Asset Class",        "Asset Class"),
        ("Entity",             "Entity"),
        ("True/Systemic",      "True/Systemic Breaks"),
    ]:
        col = cm.get(key)
        if col and col in cols:
            all_dims[label] = col

    if not all_dims:
        st.info("No dimension columns found."); return

    # Coverage KPIs for Jira-specific cols
    jira_specific = [k for k in ("Jira Reference", "Jira Description",
                                  "System to be Fixed", "Issue Category",
                                  "Issue Category 2") if k in all_dims]
    if jira_specific:
        st.markdown("### Jira Column Coverage")
        cov_cols = st.columns(min(len(jira_specific), 5))
        for i, label in enumerate(jira_specific):
            col = all_dims[label]
            row = dq(f"""
                SELECT COUNT(*) AS total,
                       COUNT(*) FILTER (WHERE "{col}" IS NOT NULL
                           AND TRIM(CAST("{col}" AS VARCHAR))
                           NOT IN ('','nan','None','N/A')) AS pop
                FROM tbl {where}
            """).iloc[0]
            pct = round(int(row["pop"]) / max(int(row["total"]), 1) * 100, 1)
            with cov_cols[i % len(cov_cols)]:
                kpi(f"{label} Coverage", f"{pct}%",
                    f"{fmtn(row['pop'])} / {fmtn(row['total'])} rows",
                    warn=(pct < 50))

    st.markdown("---")
    sel_dim = st.selectbox("Select Factor Dimension",
                            list(all_dims.keys()), key="jira_dim")
    dim_col = all_dims[sel_dim]
    not_null = f'"{dim_col}" IS NOT NULL AND TRIM(CAST("{dim_col}" AS VARCHAR)) NOT IN (\'\',\'nan\',\'None\',\'N/A\')'
    w2 = where + (f' AND {not_null}' if where else f' WHERE {not_null}')

    period_order = sorted(
        dq("SELECT DISTINCT _Period_label FROM tbl WHERE _Period_label IS NOT NULL")
        ["_Period_label"].tolist())
    latest = period_order[-1] if period_order else "0"
    prev   = period_order[-2] if len(period_order) >= 2 else "0"

    # Summary table
    st.markdown(f"### {sel_dim} — Factor Summary")
    age_sel  = "AVG(_Computed_Age_Days) AS avg_age, MAX(_Computed_Age_Days) AS max_age," \
               if "_Computed_Age_Days" in cols else ""
    amt_sel  = f"SUM(ABS({_amt(abs_c)})) AS total_gbp," if abs_c and abs_c in cols else ""
    o90_sel  = "COUNT(*) FILTER (WHERE _Computed_Age_Days>90)  AS over90d," \
               if "_Computed_Age_Days" in cols else ""
    o365_sel = "COUNT(*) FILTER (WHERE _Computed_Age_Days>365) AS over365d" \
               if "_Computed_Age_Days" in cols else "0 AS over365d"

    summary = dq(f"""
        SELECT "{dim_col}" AS factor, COUNT(*) AS break_count,
               {age_sel} {amt_sel} {o90_sel} {o365_sel}
        FROM tbl {w2}
        GROUP BY "{dim_col}" ORDER BY break_count DESC
    """)
    rename = {"factor": sel_dim, "break_count": "Break Count",
              "avg_age": "Avg Age Days", "max_age": "Max Age Days",
              "total_gbp": "Total ABS GBP",
              "over90d": "Count > 90d", "over365d": "Count > 365d"}
    summary = summary.rename(columns={k: v for k, v in rename.items()
                                       if k in summary.columns})
    if "Total ABS GBP" in summary.columns:
        summary["Total ABS GBP"] = summary["Total ABS GBP"].apply(fmts)
    if "Avg Age Days" in summary.columns:
        summary["Avg Age Days"] = summary["Avg Age Days"].round(1)
    show_df(summary, height=340, key="jira_sum")

    st.markdown("---")
    r1, r2 = st.columns(2)
    with r1:
        top_cnt = dq(f"""
            SELECT "{dim_col}" AS f, COUNT(*) AS cnt FROM tbl {w2}
            GROUP BY "{dim_col}" ORDER BY cnt DESC LIMIT 10
        """).sort_values("cnt", ascending=True)
        fig = px.bar(top_cnt, x="cnt", y="f", orientation="h",
                     color_discrete_sequence=[PRIMARY])
        fig = chl(fig, f"Top 10 {sel_dim} by Break Count",
                  "Break Count", "", h=max(300, len(top_cnt)*32))
        st.plotly_chart(fig, use_container_width=True)

    with r2:
        if "_Computed_Age_Days" in cols:
            top_age = dq(f"""
                SELECT "{dim_col}" AS f, AVG(_Computed_Age_Days) AS avg_age
                FROM tbl {w2} AND _Computed_Age_Days IS NOT NULL
                GROUP BY "{dim_col}" ORDER BY avg_age DESC LIMIT 10
            """).sort_values("avg_age", ascending=True)
            fig = px.bar(top_age, x="avg_age", y="f", orientation="h",
                         color_discrete_sequence=[COLORS[4]])
            fig = chl(fig, f"Top 10 {sel_dim} by Avg Age Days",
                      "Avg Age Days", "", h=max(300, len(top_age)*32))
            st.plotly_chart(fig, use_container_width=True)

    if abs_c and abs_c in cols:
        r3, r4 = st.columns(2)
        with r3:
            top_amt = dq(f"""
                SELECT "{dim_col}" AS f, SUM(ABS({_amt(abs_c)})) AS total
                FROM tbl {w2} GROUP BY "{dim_col}" ORDER BY total DESC LIMIT 10
            """).sort_values("total", ascending=True)
            top_amt["lbl"] = top_amt["total"].apply(fmts)
            fig = px.bar(top_amt, x="total", y="f", orientation="h",
                         color_discrete_sequence=[COLORS[2]])
            fig.update_traces(text=top_amt["lbl"], textposition="outside")
            fig = chl(fig, f"Top 10 {sel_dim} by ABS GBP",
                      "GBP (£)", "", h=max(300, len(top_amt)*32))
            st.plotly_chart(fig, use_container_width=True)

        with r4:
            if "_Computed_Age_Days" in cols:
                risk = dq(f"""
                    SELECT "{dim_col}" AS f, COUNT(*) AS total,
                           COUNT(*) FILTER (WHERE _Computed_Age_Days>90) AS o90
                    FROM tbl {w2} AND _Computed_Age_Days IS NOT NULL
                    GROUP BY "{dim_col}" ORDER BY o90 DESC LIMIT 10
                """)
                risk[">90 Day %"] = (risk["o90"] / risk["total"] * 100).round(1)
                risk = risk.sort_values(">90 Day %", ascending=True)
                fig = px.bar(risk, x=">90 Day %", y="f", orientation="h",
                             color_discrete_sequence=[WARN])
                fig = chl(fig, f"Top 10 {sel_dim} — % Breaks > 90 Days",
                          "% > 90 Days", "", h=max(300, len(risk)*32))
                st.plotly_chart(fig, use_container_width=True)

    # Period trend top 5
    if period_order:
        st.markdown(f"### {sel_dim} — Period Trend (Top 5)")
        top5 = dq(f"""
            SELECT "{dim_col}" AS f FROM tbl {w2}
            GROUP BY "{dim_col}" ORDER BY COUNT(*) DESC LIMIT 5
        """)["f"].tolist()
        t5_in = ", ".join(f"'{str(v).replace(chr(39),chr(39)*2)}'" for v in top5)
        tr_df = dq(f"""
            SELECT "{dim_col}" AS f, _Period_label AS p, COUNT(*) AS cnt
            FROM tbl {where} {"AND" if where else "WHERE"}
            "{dim_col}" IN ({t5_in})
            GROUP BY "{dim_col}", _Period_label ORDER BY _Period_label
        """)
        fig = px.line(tr_df, x="p", y="cnt", color="f",
                      color_discrete_sequence=COLORS, markers=True)
        fig = chl(fig, f"Top 5 {sel_dim} — Count Trend", "Period", "Count")
        st.plotly_chart(fig, use_container_width=True)

    # MoM change
    if len(period_order) >= 2:
        st.markdown(f"### MoM Change: {prev} → {latest}")
        mdf = dq(f"""
            SELECT "{dim_col}" AS f,
                   COUNT(*) FILTER (WHERE _Period_label='{latest}') AS lat,
                   COUNT(*) FILTER (WHERE _Period_label='{prev}')   AS prv
            FROM tbl {w2} GROUP BY "{dim_col}"
        """)
        mdf["Δ"]   = mdf["lat"] - mdf["prv"]
        mdf["Δ %"] = ((mdf["lat"] - mdf["prv"]) /
                       mdf["prv"].replace(0, np.nan) * 100).round(1)
        mdf = mdf.sort_values("Δ")
        bc  = [COLORS[0] if v >= 0 else COLORS[4] for v in mdf["Δ"]]
        fig = go.Figure(go.Bar(
            x=mdf["Δ"], y=mdf["f"], orientation="h", marker_color=bc,
            text=mdf["Δ"].apply(lambda x: f"+{x:,}" if x >= 0 else f"{x:,}"),
            textposition="outside",
        ))
        fig.add_vline(x=0, line_dash="dash", line_color=MUTED, line_width=1)
        fig = chl(fig, f"MoM Count Change by {sel_dim}",
                  "Change in Break Count", "", h=max(360, len(mdf)*26))
        st.plotly_chart(fig, use_container_width=True)

    st.download_button(
        f"📥 Download {sel_dim} Summary (CSV)",
        summary.to_csv(index=False).encode("utf-8"),
        file_name=f"jira_factor_{sel_dim.replace(' ','_').lower()}.csv",
        mime="text/csv")


# ══════════════════════════════════════════════════════════════════════════════
#  TAB 6 — PHASE 2 PREVIEW
# ══════════════════════════════════════════════════════════════════════════════

def tab_phase2(cm, where):
    st.markdown("## Phase 2 Intelligence Preview")
    banner("b-phase2",
           "🚀 <b>Phase 2 Readiness:</b> Pre-computed signals from Phase 1 flags. "
           "No LLM calls here — these feed the Phase 2 rule engine, SSI clustering, "
           "and BERTopic taxonomy discovery.")

    cols = dq("SELECT * FROM tbl LIMIT 0").columns.tolist()
    rec_c    = cm.get("Rec Name (as per Rec Cube)")
    entity_c = cm.get("Entity")
    ccy_c    = cm.get("TRADE CCY")
    abs_c    = cm.get("ABS GBP") or cm.get("BREAK AMOUNT GBP")
    iss_c    = cm.get("ISSUE CATEGORY")
    rc_c     = cm.get("Root Cause identified")
    cmt_c    = cm.get("Comments")

    # Pareto flags
    frow = dq(f"""
        SELECT COUNT(*) FILTER (WHERE "_is_timing") AS tim,
               COUNT(*) FILTER (WHERE "_has_ssi")   AS ssi,
               COUNT(*) FILTER (WHERE "_has_ca")    AS ca,
               COUNT(*)                             AS total
        FROM tbl {where}
    """).iloc[0]
    n_tot = int(frow["total"]) or 1

    c1, c2, c3, c4 = st.columns(4)
    with c1: kpi("Timing Candidates (#1)", f"{round(int(frow['tim'])/n_tot*100,1)}%",
                 fmtn(frow["tim"]) + " breaks")
    with c2: kpi("SSI Signals (#2)",       f"{round(int(frow['ssi'])/n_tot*100,1)}%",
                 fmtn(frow["ssi"]) + " breaks")
    with c3: kpi("CA Signals (#6)",        f"{round(int(frow['ca'])/n_tot*100,1)}%",
                 fmtn(frow["ca"]) + " breaks")
    with c4:
        par = round((int(frow["tim"]) + int(frow["ssi"])) / n_tot * 100, 1)
        kpi("Pareto Coverage", f"{par}%", "Timing + SSI")

    par_data = pd.DataFrame({
        "Category":    ["Timing (#1)", "SSI (#2)", "CA (#6)", "Needs LLM"],
        "Break Count": [
            int(frow["tim"]), int(frow["ssi"]), int(frow["ca"]),
            max(0, n_tot - int(frow["tim"]) - int(frow["ssi"]) - int(frow["ca"])),
        ],
    })
    fig = px.pie(par_data, values="Break Count", names="Category",
                 color_discrete_sequence=[PRIMARY, COLORS[4], COLORS[8], MUTED],
                 hole=0.45)
    fig = chl(fig, "Phase 2 Pareto Coverage", h=320)
    st.plotly_chart(fig, use_container_width=True)

    # SSI Clustering
    st.markdown("---")
    st.markdown("### SSI Clustering Preview")
    st.markdown("Groups SSI-flagged breaks by Entity + TRADE CCY + Rec Name. "
                "Each cluster = ONE SSI record to fix → closes all related breaks simultaneously.")

    grp_cols = [c for c in [rec_c, entity_c, ccy_c] if c and c in cols]
    if grp_cols and int(frow["ssi"]) > 0:
        gcols_sql = ", ".join(f'"{c}"' for c in grp_cols)
        w_ssi = where + (' AND "_has_ssi"=true' if where else ' WHERE "_has_ssi"=true')
        clusters = dq(f"""
            SELECT {gcols_sql}, COUNT(*) AS breaks_in_cluster
            FROM tbl {w_ssi}
            GROUP BY {gcols_sql}
            HAVING COUNT(*) >= 3
            ORDER BY breaks_in_cluster DESC LIMIT 20
        """)
        if len(clusters):
            clusters["Action"] = "Raise 1 JIRA → closes all breaks in cluster"
            show_df(clusters, height=300, key="ssi_cl")
            total_fx = int(clusters["breaks_in_cluster"].sum())
            banner("b-info",
                   f"💡 <b>High Value:</b> Fixing <b>{len(clusters)} SSI records</b> "
                   f"closes <b>{fmtn(total_fx)} breaks</b> "
                   f"({round(total_fx/n_tot*100,1)}% of filtered breaks).")
        else:
            st.info("No SSI clusters of ≥3 breaks found with current filters.")
    else:
        st.info("Rec Name, Entity, or TRADE CCY columns not found for clustering.")

    # ISSUE CATEGORY taxonomy
    st.markdown("---")
    st.markdown("### Issue Category Taxonomy (Phase 2 Validation Input)")
    if iss_c and iss_c in cols:
        cat_df = dq(f"""
            SELECT "{iss_c}" AS issue_cat, COUNT(*) AS cnt,
                   ROUND(100.0*COUNT(*)/SUM(COUNT(*)) OVER(),1) AS pct
            FROM tbl {where}
            WHERE "{iss_c}" IS NOT NULL
              AND TRIM(CAST("{iss_c}" AS VARCHAR)) NOT IN ('','nan','None','N/A')
            GROUP BY "{iss_c}" ORDER BY cnt DESC LIMIT 20
        """)
        if len(cat_df):
            fig = px.bar(cat_df.sort_values("cnt", ascending=True),
                         x="cnt", y="issue_cat", orientation="h",
                         color_discrete_sequence=[COLORS[9]])
            fig = chl(fig, "Issue Category Distribution (Top 20)",
                      "Break Count", "", h=max(300, len(cat_df)*28))
            st.plotly_chart(fig, use_container_width=True)
            cat_df["pct"] = cat_df["pct"].apply(lambda x: f"{x}%")
            show_df(cat_df, height=260, key="iss_cat")
    else:
        st.info("ISSUE CATEGORY column not found.")

    # Root cause population rate
    st.markdown("---")
    st.markdown("### Root Cause Population Rate")
    if rc_c and rc_c in cols:
        pop = dq(f"""
            SELECT COUNT(*) FILTER (WHERE "{rc_c}" IS NOT NULL
                AND TRIM(CAST("{rc_c}" AS VARCHAR))
                NOT IN ('','nan','None','N/A')) AS pop,
                   COUNT(*) AS total
            FROM tbl {where}
        """).iloc[0]
        pct = round(int(pop["pop"]) / max(int(pop["total"]), 1) * 100, 1)
        kpi("Root Cause Identified", f"{pct}%",
            f"{fmtn(pop['pop'])} / {fmtn(pop['total'])} records",
            warn=(pct < 10))
        if pct == 0:
            banner("b-warn",
                   "⚠️ <b>Root Cause is 0% populated.</b> "
                   "Phase 2 will use LLM/RAG to populate this from Comments + JIRA DESC. "
                   "SSI Clustering (above) is the fastest path to partial population "
                   "without waiting for LLM governance approval.")

    # BERTopic sample export
    st.markdown("---")
    st.markdown("### BERTopic Sample Preparation (Phase 2A Input)")
    if cmt_c and cmt_c in cols:
        cmt_n = int(dq(f"""
            SELECT COUNT(*) AS n FROM tbl {where}
            WHERE "{cmt_c}" IS NOT NULL
              AND TRIM(CAST("{cmt_c}" AS VARCHAR)) NOT IN ('','nan','None')
        """).iloc[0]["n"])
        sample_n = min(10_000, cmt_n)
        c1, c2 = st.columns(2)
        with c1: kpi("Non-Null Comments",  fmtn(cmt_n))
        with c2: kpi("BERTopic Sample",    fmtn(sample_n), "Ready for Phase 2A")
        if st.button("⬇️ Prepare & Download 10K BERTopic Sample", key="bt_btn"):
            samp = dq(f"""
                SELECT "{cmt_c}" AS comment FROM tbl {where}
                WHERE "{cmt_c}" IS NOT NULL
                  AND TRIM(CAST("{cmt_c}" AS VARCHAR)) NOT IN ('','nan','None')
                USING SAMPLE {sample_n} ROWS
            """)
            st.download_button("📥 Save BERTopic Sample CSV",
                               samp.to_csv(index=False).encode("utf-8"),
                               file_name="bertopic_sample_10k.csv", mime="text/csv")
    else:
        st.info("Comments column not found.")


# ══════════════════════════════════════════════════════════════════════════════
#  MAIN
# ══════════════════════════════════════════════════════════════════════════════

def main():
    st.markdown(f"""
    <div style="background:{PRIMARY};padding:12px 24px;
                border-radius:6px;margin-bottom:20px">
      <h1 style="color:white;margin:0;font-size:1.5rem">
        📊 Accounting Control AI Platform
        <span style="font-size:.85rem;color:#BCE2E7;font-weight:400">
        · Phase 1 + Phase 2 Preview</span>
      </h1>
    </div>
    """, unsafe_allow_html=True)

    # ── Sidebar ────────────────────────────────────────────────────────────
    st.sidebar.markdown(f"""
    <div style="text-align:center;padding:8px 0">
      <h3 style="color:{PRIMARY};margin:0">Accounting Control AI</h3>
      <p style="color:{MUTED};font-size:.8rem;margin:0">Phase 1 · DuckDB · Parquet</p>
    </div>
    """, unsafe_allow_html=True)
    st.sidebar.markdown("---")
    st.sidebar.markdown("### 📁 Data Upload")

    uploaded = st.sidebar.file_uploader(
        "Upload CSV / Excel / Parquet",
        type=["csv", "xlsx", "xls", "xlsm", "parquet"],
        key="uploader",
    )

    if not uploaded:
        st.markdown("""
### 👋 Welcome

Upload your **MI Report** (CSV, Excel, or Parquet) in the sidebar to begin.

| Format | First Load | Subsequent Loads |
|--------|-----------|-----------------|
| `.parquet` | ⚡ ~0.5s | ⚡ Instant (cached) |
| `.csv`     | 🟢 ~2s   | ⚡ Instant (cached) |
| `.xlsx`    | 🟡 ~5-8s | ⚡ Instant (cached) |

> **Note:** XLSX and CSV files are automatically converted to Parquet on first load.
> Download the Parquet version from Tab 1 for instant future uploads.

**6 Tabs available:**
- 🧹 Data Quality — completeness, violations, outliers, Phase 2 flags
- 📅 Ageing Validation — computed vs pre-populated Age Days & Bucket
- 📈 Break Counts — period trend analysis
- 💷 Amount Analysis — ABS GBP trend analysis
- 🔍 Jira Factor Analysis — Jira Ref / System to be Fixed driver analysis
- 🚀 Phase 2 Preview — SSI clustering, BERTopic readiness, root cause stats

**Key improvements:**
- ✅ Filters apply only on button click — no re-render on filter change
- ✅ XLSX/CSV auto-converted to Parquet (10x faster on reruns)
- ✅ DuckDB reads directly from Parquet (zero-copy, max performance)
- ✅ format_short() handles K/M/B/T/P — no more 10^16 on chart axes
- ✅ Python 3.9 compatible — fixed `X | None` type hint error
        """)
        return

    # ── Load & process ─────────────────────────────────────────────────────
    file_bytes = uploaded.read()
    filename   = uploaded.name

    # Reset overflow counter on new file
    if st.session_state.get("_last_file") != filename:
        st.session_state["_overflow"]       = 0
        st.session_state["_last_file"]      = filename
        st.session_state["filters_applied"] = {}
        st.session_state["filters_pending"] = {}

    try:
        ppath, cm, filter_options, vdf, dropped_cols, filtered_for_del = \
            _build_parquet(file_bytes, filename)
    except Exception as e:
        st.error(f"❌ Error processing file: {e}")
        st.stop()

    # Register Parquet with DuckDB — one-time, zero-copy
    _register_parquet(ppath)

    # Count total rows fast
    total_rows = int(dq("SELECT COUNT(*) AS n FROM tbl").iloc[0]["n"])

    # ── Sidebar info ───────────────────────────────────────────────────────
    st.sidebar.markdown(f"""
    **File:** `{filename}`
    **Rows:** {total_rows:,} · **Cols:** {len(cm)}
    """)
    if dropped_cols:
        st.sidebar.caption(f"🗑️ Removed {len(dropped_cols)} blank cols")
    if filtered_for_del:
        st.sidebar.caption(f"✅ For Del: {filtered_for_del:,} removed")
    vcount = int(vdf["Violation Count"].sum()) if len(vdf) else 0
    if vcount:
        st.sidebar.markdown(
            f'<span style="color:{WARN};font-weight:600">⚠️ {vcount} violations</span>',
            unsafe_allow_html=True)
    overflow = st.session_state.get("_overflow", 0)
    if overflow:
        st.sidebar.markdown(
            f'<span style="color:{WARN};font-weight:600">⚠️ {overflow} amount overflows</span>',
            unsafe_allow_html=True)

    # ── Init filter state (once per file) ─────────────────────────────────
    _init_filter_state(filter_options)

    # ── Render sidebar filters + get WHERE clause ──────────────────────────
    abs_col = cm.get("ABS GBP") or cm.get("BREAK AMOUNT GBP")
    where   = _sidebar_filters(filter_options, cm, abs_col)

    # Filtered row count (shown in sidebar after Apply)
    try:
        filt_n = int(dq(f"SELECT COUNT(*) AS n FROM tbl {where}").iloc[0]["n"])
    except Exception:
        filt_n = total_rows
        where  = ""

    st.sidebar.markdown(f"**Filtered:** {filt_n:,} / {total_rows:,} rows")
    if where:
        st.sidebar.caption("🔴 Filters active — click Apply to update")

    # ── Tabs ───────────────────────────────────────────────────────────────
    t1, t2, t3, t4, t5, t6 = st.tabs([
        "🧹 Data Quality",
        "📅 Ageing Validation",
        "📈 Break Counts",
        "💷 Amount Analysis",
        "🔍 Jira Factor Analysis",
        "🚀 Phase 2 Preview",
    ])

    with t1: tab_data_quality(cm, vdf, dropped_cols, filtered_for_del, where)
    with t2: tab_ageing(cm, where)
    with t3: tab_break_counts(cm, where)
    with t4: tab_amounts(cm, where)
    with t5: tab_jira(cm, where)
    with t6: tab_phase2(cm, where)


if __name__ == "__main__":
    main()

"""
Accounting Control AI Platform — Phase 1 + Phase 2 Preview
═══════════════════════════════════════════════════════════
FIXES vs previous version:
  1. format_short() now handles K / M / B / T / P — no more 10^16 on chart axes
  2. Large-value detector: flags ABS GBP > 2^53 (JS integer overflow) as data quality issues
  3. parse_amount_vec() hardened: explicit float64 cast + overflow guard
  4. AgGrid amount columns cast to str before render to avoid JS Number overflow
  5. Surrogate key display: SRG_ prefix shown cleanly in TRADE REF column
  6. DuckDB amounts cast with TRY_CAST to float64 in all SQL queries

NEW vs previous version:
  • Tab 5: Jira Factor Analysis (Jira Ref / Jira Desc / System to be Fixed)
  • Tab 6: Phase 2 Intelligence Preview (SSI clustering preview, timing flag stats,
           BERTopic readiness, root cause taxonomy candidates from ISSUE CATEGORY)
  • 3-column rolling avg toggle on all trend charts
  • Amount overflow detection banner in Data Quality tab
  • Cross-dim heatmap: Jira Reference × System to be Fixed
"""

import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
from io import BytesIO
import duckdb
import hashlib
import math
import re

try:
    from st_aggrid import AgGrid, GridOptionsBuilder, JsCode
    HAS_AGGRID = True
except ImportError:
    HAS_AGGRID = False

# ── Page config ───────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="Accounting Control AI Platform",
    page_icon="📊", layout="wide",
    initial_sidebar_state="expanded",
)

COLORS       = ["#01696F","#0C4E54","#20808D","#4F98A3","#A84B2F",
                "#1B474D","#BCE2E7","#944454","#FFC553","#5C2D91"]
PRIMARY      = "#01696F"
DARK         = "#28251D"
MUTED        = "#7A7974"
BG_LIGHT     = "#F7F7F5"
WARN         = "#A84B2F"
BUCKET_ORDER = ["0-15","16-30","31-60","61-90","91-180","181-365","365+","Unknown"]

# JS integer limit — values above this cause AgGrid/Plotly axis overflow
MAX_JS_INT = 2 ** 53  # 9,007,199,254,740,992

st.markdown(f"""
<style>
  .main .block-container {{padding-top:1rem;padding-bottom:1rem;}}
  h1 {{color:{DARK};font-size:1.6rem !important;}}
  h2 {{color:{DARK};font-size:1.25rem !important;}}
  h3 {{color:{DARK};font-size:1.05rem !important;}}
  .stTabs [data-baseweb="tab-list"] {{gap:8px;}}
  .stTabs [data-baseweb="tab"] {{
      background-color:{BG_LIGHT};border-radius:6px 6px 0 0;
      padding:8px 16px;font-weight:600;color:{DARK};}}
  .stTabs [aria-selected="true"] {{
      background-color:{PRIMARY} !important;color:white !important;}}
  .kpi-card {{background:white;border-left:4px solid {PRIMARY};
      padding:12px 16px;border-radius:4px;box-shadow:0 1px 3px rgba(0,0,0,.08);}}
  .kpi-warn {{background:white;border-left:4px solid {WARN};
      padding:12px 16px;border-radius:4px;box-shadow:0 1px 3px rgba(0,0,0,.08);}}
  .kpi-label {{color:{MUTED};font-size:.75rem;text-transform:uppercase;
      letter-spacing:.5px;margin-bottom:2px;}}
  .kpi-value {{color:{DARK};font-size:1.4rem;font-weight:700;margin:0;}}
  .kpi-delta-pos {{color:#A84B2F;font-size:.8rem;}}
  .kpi-delta-neg {{color:#01696F;font-size:.8rem;}}
  .banner-warn   {{background:#FDECEA;border-left:4px solid {WARN};
      padding:10px 16px;border-radius:4px;margin-bottom:.5rem;font-size:.88rem;color:{DARK};}}
  .banner-info   {{background:#E6F4F1;border-left:4px solid {PRIMARY};
      padding:10px 16px;border-radius:4px;margin-bottom:.5rem;font-size:.88rem;color:{DARK};}}
  .banner-jira   {{background:#E8F4FD;border-left:4px solid #20808D;
      padding:10px 16px;border-radius:4px;margin-bottom:.5rem;font-size:.88rem;color:{DARK};}}
  .banner-phase2 {{background:#F3E8FF;border-left:4px solid #5C2D91;
      padding:10px 16px;border-radius:4px;margin-bottom:.5rem;font-size:.88rem;color:{DARK};}}
</style>
""", unsafe_allow_html=True)


# ── Formatters ─────────────────────────────────────────────────────────────────

def format_short(n, prefix="£") -> str:
    """
    FIX #1: Handle all scales including Trillion and Peta.
    K=thousand, M=million, B=billion, T=trillion, P=peta (10^15).
    This prevents 10^16 appearing on chart axes.
    """
    if n is None:
        return "N/A"
    try:
        v = float(n)
        if math.isnan(v) or math.isinf(v):
            return "N/A"
    except (TypeError, ValueError):
        return "N/A"

    sign = "-" if v < 0 else ""
    v = abs(v)

    if v == 0:
        return f"{prefix}0"
    if v >= 1_000_000_000_000_000:   # ≥ 1 Peta (10^15)
        return f"{sign}{prefix}{v/1e15:.2f}P"
    if v >= 1_000_000_000_000:        # ≥ 1 Trillion (10^12)
        return f"{sign}{prefix}{v/1e12:.2f}T"
    if v >= 1_000_000_000:            # ≥ 1 Billion
        return f"{sign}{prefix}{v/1e9:.1f}B"
    if v >= 1_000_000:                # ≥ 1 Million
        return f"{sign}{prefix}{v/1e6:.1f}M"
    if v >= 1_000:                    # ≥ 1 Thousand
        return f"{sign}{prefix}{v/1e3:.1f}K"
    return f"{sign}{prefix}{v:,.2f}"


def format_number(n, decimal=0) -> str:
    if n is None or (isinstance(n, float) and math.isnan(n)):
        return "N/A"
    return f"{int(n):,}" if decimal == 0 else f"{float(n):,.{decimal}f}"


def safe_mom_pct(current, previous):
    if previous is None or previous == 0:
        return None
    return round(((current - previous) / abs(previous)) * 100, 1)


def kpi_card(label, value, delta=None, invert=False, warn=False):
    delta_html = ""
    if delta:
        if invert:
            css = "kpi-delta-pos" if str(delta).startswith("-") else "kpi-delta-neg"
        else:
            css = "kpi-delta-neg" if str(delta).startswith("-") else "kpi-delta-pos"
        delta_html = f'<p class="{css}">{delta}</p>'
    card_cls = "kpi-warn" if warn else "kpi-card"
    st.markdown(f"""
    <div class="{card_cls}">
        <p class="kpi-label">{label}</p>
        <p class="kpi-value">{value}</p>
        {delta_html}
    </div>""", unsafe_allow_html=True)


def chart_layout(fig, title="", xt="", yt="", height=400):
    fig.update_layout(
        title=dict(text=title, font=dict(size=14, color=DARK)),
        xaxis_title=xt, yaxis_title=yt, height=height,
        margin=dict(l=40, r=20, t=50, b=40),
        font=dict(family="Inter, sans-serif", size=11, color=DARK),
        plot_bgcolor="white", paper_bgcolor="white",
        legend=dict(font=dict(size=10)),
    )
    fig.update_xaxes(showgrid=True, gridwidth=1, gridcolor="#ECECEC")
    fig.update_yaxes(showgrid=True, gridwidth=1, gridcolor="#ECECEC")
    return fig


def add_rolling_avg(fig, x, y, window=3, name="Rolling Avg", color=None):
    if len(x) < window:
        return fig
    s = pd.Series(list(y))
    rolled = s.rolling(window, min_periods=1).mean().round(1)
    fig.add_trace(go.Scatter(
        x=list(x), y=rolled.tolist(),
        name=f"{name} ({window}p)", mode="lines",
        line=dict(color=color or COLORS[7], width=2, dash="dot"),
    ))
    return fig


# ── AgGrid helper ─────────────────────────────────────────────────────────────

def render_aggrid(df: pd.DataFrame, height=400, key=None, match_cols=None):
    """
    FIX #4: Cast amount columns to string before passing to AgGrid
    to prevent JS integer overflow on values > 2^53.
    """
    df_display = df.copy()

    # Cast any int64 column that might overflow JS Number to string
    for col in df_display.columns:
        if df_display[col].dtype in (np.int64, np.uint64):
            if (df_display[col].abs() > MAX_JS_INT).any():
                df_display[col] = df_display[col].apply(
                    lambda x: format_short(x) if pd.notna(x) else "N/A"
                )
        elif df_display[col].dtype == np.float64:
            if (df_display[col].abs() > MAX_JS_INT).any():
                df_display[col] = df_display[col].apply(
                    lambda x: format_short(x) if pd.notna(x) else "N/A"
                )

    if HAS_AGGRID and len(df_display) > 0:
        gb = GridOptionsBuilder.from_dataframe(df_display)
        gb.configure_pagination(paginationAutoPageSize=False, paginationPageSize=20)
        gb.configure_default_column(filterable=True, sortable=True, resizable=True)
        if match_cols:
            cs = JsCode("""function(p){
                if(p.value===false||p.value==='False'||p.value===0)
                    return{'backgroundColor':'#FDECEA','color':'#A84B2F','fontWeight':'bold'};
                if(p.value===true||p.value==='True'||p.value===1)
                    return{'backgroundColor':'#E8F5E9','color':'#01696F'};
                return{};}""")
            for c in match_cols:
                if c in df_display.columns:
                    gb.configure_column(c, cellStyle=cs)
        AgGrid(df_display, gridOptions=gb.build(), height=height,
               theme="streamlit", key=key, allow_unsafe_jscode=True)
    else:
        st.dataframe(df_display, height=height, use_container_width=True)


# ── DuckDB ────────────────────────────────────────────────────────────────────

@st.cache_resource
def get_duck() -> duckdb.DuckDBPyConnection:
    return duckdb.connect()


def dq(sql: str, df: pd.DataFrame = None) -> pd.DataFrame:
    """
    FIX #6: All amount columns use TRY_CAST(... AS DOUBLE) in SQL
    to avoid integer overflow in DuckDB aggregations.
    """
    con = get_duck()
    if df is not None:
        con.register("tbl", df)
    return con.execute(sql).df()


def safe_amount_expr(col: str) -> str:
    """Wrap an amount column expression to safely cast to DOUBLE."""
    return f'TRY_CAST("{col}" AS DOUBLE)'


# ── Vectorised helpers ────────────────────────────────────────────────────────

def period_to_datetime_vec(series: pd.Series) -> pd.Series:
    s = pd.to_numeric(series, errors="coerce")
    year  = (s // 100).astype("Int64")
    month = (s  % 100).astype("Int64")
    valid = month.between(1, 12) & year.notna()
    nm = (month + 1).where(valid)
    ny =  year.where(valid).copy()
    dec = month == 12
    nm  = nm.where(~dec, 1)
    ny  = ny.where(~dec, year + 1)
    result = pd.Series(pd.NaT, index=series.index, dtype="datetime64[ns]")
    vi = valid[valid].index
    if len(vi):
        ds = ny.loc[vi].astype(str) + "-" + nm.loc[vi].astype(str).str.zfill(2) + "-01"
        result.loc[vi] = pd.to_datetime(ds, errors="coerce") - pd.Timedelta(days=1)
    return result


def parse_amount_vec(series: pd.Series) -> pd.Series:
    """
    FIX #3: Hardened amount parser.
    Handles: £, $, €, GBP/USD/EUR prefix, commas, parenthesised negatives.
    Returns float64. Values > 10^15 (implausible real break amounts)
    are flagged as NaN and counted as violations.
    """
    original_na = series.isna()
    s = series.astype(str).str.strip()
    s = s.str.replace(r'[£$€¥,]', '', regex=True)
    s = s.str.replace(r'(?i)^(GBP|USD|EUR|JPY|CHF|AUD|CAD)\s*', '', regex=True)
    s = s.str.replace(r'^\((.+)\)$', r'-\1', regex=True)  # (15000) → -15000
    s = s.str.strip()

    result = pd.to_numeric(s, errors="coerce").astype("float64")
    result[original_na] = np.nan

    # FIX: detect JS-overflow values (> 2^53) — treat as parsing violation
    overflow_mask = result.abs() > MAX_JS_INT
    if overflow_mask.sum() > 0:
        # Store flagged count in session state for the Data Quality banner
        st.session_state["_amount_overflow_count"] = (
            st.session_state.get("_amount_overflow_count", 0) + int(overflow_mask.sum())
        )
        result[overflow_mask] = np.nan

    return result


def parse_age_days_vec(series: pd.Series) -> pd.Series:
    s = series.astype(str).str.strip()
    r = pd.to_numeric(s.str.extract(r'^[~]?(-?\d+)', expand=False), errors="coerce")
    r[series.isna() | s.isin(['', 'N/A', 'n/a', '-', 'nan', 'None'])] = np.nan
    return r


def age_to_bucket_vec(age_series: pd.Series) -> pd.Categorical:
    a = age_series.values
    cond = [pd.isna(age_series), a <= 15, a <= 30, a <= 60,
            a <= 90, a <= 180, a <= 365]
    ch   = ["Unknown","0-15","16-30","31-60","61-90","91-180","181-365"]
    return pd.Categorical(np.select(cond, ch, default="365+"),
                          categories=BUCKET_ORDER, ordered=True)


def detect_outliers_iqr(series: pd.Series, name: str) -> pd.DataFrame:
    clean = series.dropna()
    if len(clean) < 10:
        return pd.DataFrame()
    q1, q3 = clean.quantile(0.25), clean.quantile(0.75)
    iqr = q3 - q1
    lo, hi = q1 - 1.5 * iqr, q3 + 1.5 * iqr
    out = clean[(clean < lo) | (clean > hi)]
    if len(out) == 0:
        return pd.DataFrame()
    return pd.DataFrame({
        "Column":       [name],
        "Outlier Count":[len(out)],
        "Outlier %":    [round(len(out)/len(clean)*100, 2)],
        "IQR Lower":    [format_short(lo)],
        "IQR Upper":    [format_short(hi)],
        "Min Outlier":  [format_short(out.min())],
        "Max Outlier":  [format_short(out.max())],
    })


# ── Column constants & mapping ────────────────────────────────────────────────

EXPECTED_COLUMNS = [
    "Period","Asset Class","Team","Rec Name (as per Rec Cube)","Entity",
    "Type of break","Account Group","Products Reconciled","TRADE REF",
    "If Duplicate Trade, provide the CC, etc details","TRADE CCY",
    "BREAK AMOUNT CCY","BREAK AMOUNT GBP","Date","Age Days","Bucket",
    "True/Systemic Breaks","Journals Posted","Comments","ABS GBP",
    "Root Cause identified","B/S Cert",
    "Jira Reference","Jira Desc","System to be Fixed",
    "ISSUE CATEGORY","ISSUE CATEGORY2","JIRA PRIORITY","EPIC","For Del",
]


def fuzzy_match(cols, target):
    tl = target.lower().strip()
    for c in cols:
        if c.lower().strip() == tl:
            return c
    for c in cols:
        if tl in c.lower() or c.lower() in tl:
            return c
    return None


def build_col_map(cols):
    return {e: m for e in EXPECTED_COLUMNS if (m := fuzzy_match(cols, e))}


def drop_blank_trailing(df: pd.DataFrame, n: int = 4):
    to_drop = []
    for col in df.columns[-n:]:
        null_pct = df[col].isna().mean()
        try:
            blank_pct = df[col].astype(str).str.strip().isin(
                ['', 'nan', 'None', 'NaN']).mean()
        except Exception:
            blank_pct = 0.0
        if max(null_pct, blank_pct) >= 0.95:
            to_drop.append(col)
    return df.drop(columns=to_drop), to_drop


# ── File loading + pipeline ───────────────────────────────────────────────────

@st.cache_data(show_spinner="Reading file…")
def load_raw(file_bytes: bytes, filename: str) -> pd.DataFrame:
    buf  = BytesIO(file_bytes)
    name = filename.lower()
    if name.endswith(".parquet"):
        return pd.read_parquet(buf)
    if name.endswith(".csv"):
        return pd.read_csv(buf, low_memory=False)
    try:
        import python_calamine  # noqa
        return pd.read_excel(buf, engine="calamine")
    except ImportError:
        buf.seek(0)
        return pd.read_excel(buf, engine="openpyxl")


@st.cache_data(show_spinner="Cleaning & processing data…")
def clean_dataframe(file_bytes: bytes, filename: str):
    # Reset overflow counter for this file
    st.session_state["_amount_overflow_count"] = 0

    df = load_raw(file_bytes, filename)
    df, dropped_cols = drop_blank_trailing(df, n=4)

    col_map    = build_col_map(df.columns.tolist())
    violations = []

    # Amount columns
    for key in ("BREAK AMOUNT CCY", "BREAK AMOUNT GBP", "ABS GBP"):
        actual = col_map.get(key)
        if actual and actual in df.columns:
            orig      = df[actual].copy()
            df[actual] = parse_amount_vec(df[actual])
            bad = orig.notna() & df[actual].isna()
            if bad.sum():
                violations.append({
                    "Column":          actual,
                    "Expected Type":   "float64",
                    "Violation Count": int(bad.sum()),
                    "Sample Values":   ", ".join(orig[bad].head(3).astype(str)),
                })

    # Age Days
    actual = col_map.get("Age Days")
    if actual and actual in df.columns:
        orig       = df[actual].copy()
        df[actual] = parse_age_days_vec(df[actual])
        bad = orig.notna() & orig.astype(str).str.strip().ne('') & df[actual].isna()
        if bad.sum():
            violations.append({
                "Column":          actual,
                "Expected Type":   "numeric",
                "Violation Count": int(bad.sum()),
                "Sample Values":   ", ".join(orig[bad].head(3).astype(str)),
            })

    # Date
    actual = col_map.get("Date")
    if actual and actual in df.columns:
        df[actual] = pd.to_datetime(df[actual], errors="coerce")

    # Period helpers
    actual = col_map.get("Period")
    if actual and actual in df.columns:
        df["_Period_date"]  = period_to_datetime_vec(df[actual])
        df["_Period_label"] = (df["_Period_date"].dt.strftime("%Y-%m")
                               .fillna(df[actual].astype(str)))

    # Ageing computation
    date_actual = col_map.get("Date")
    if date_actual and date_actual in df.columns and "_Period_date" in df.columns:
        df["_Computed_Age_Days"] = (df["_Period_date"] - df[date_actual]).dt.days
        df["_Computed_Bucket"]   = age_to_bucket_vec(df["_Computed_Age_Days"])
        age_actual = col_map.get("Age Days")
        if age_actual and age_actual in df.columns:
            df["_Age_Match"] = np.isclose(
                df[age_actual].fillna(-999),
                df["_Computed_Age_Days"].fillna(-998), atol=1)
        bkt_actual = col_map.get("Bucket")
        if bkt_actual and bkt_actual in df.columns:
            df["_Bucket_Match"] = (
                df[bkt_actual].astype(str).str.strip()
                == df["_Computed_Bucket"].astype(str).str.strip())

    # Phase 2 pre-flags
    df["_is_timing"] = _flag_timing(df, col_map)
    df["_has_ssi"]   = _flag_ssi(df, col_map)
    df["_has_ca"]    = _flag_ca(df, col_map)
    df["_False_Positive"] = False

    # For Del filter
    for_del = col_map.get("For Del")
    filtered_for_del = 0
    if for_del and for_del in df.columns:
        del_mask = df[for_del].astype(str).str.strip().str.lower().isin(
            {"true","yes","y","1","x","delete","del"})
        filtered_for_del = int(del_mask.sum())
        df = df[~del_mask].copy()

    filter_options = {}
    for key in ("Period","Team","Rec Name (as per Rec Cube)","Entity",
                "Asset Class","Type of break","True/Systemic Breaks"):
        actual = col_map.get(key)
        if actual and actual in df.columns:
            filter_options[key] = sorted(df[actual].dropna().unique().tolist())

    vdf = (pd.DataFrame(violations) if violations
           else pd.DataFrame(columns=["Column","Expected Type","Violation Count","Sample Values"]))

    return df, col_map, filter_options, vdf, dropped_cols, filtered_for_del


# Phase 2 flags (pre-computation)
_SSI_KW  = ["ssi","settlement instruction","standing instruction","account number",
             "sort code","bic","swift","nostro","iban"]
_CA_KW   = ["dividend","split","ex-date","corporate action","rights issue","merger"]
_TIM_KW  = ["timing","settlement timing","t+1","t+2","t+3","fail","pending"]


def _kw_mask(df, col_map, keys, keywords):
    mask = pd.Series(False, index=df.index)
    pattern = "|".join(keywords)
    for k in keys:
        col = col_map.get(k)
        if col and col in df.columns:
            mask |= df[col].astype(str).str.lower().str.contains(pattern, regex=True, na=False)
    return mask


def _flag_timing(df, col_map):
    mask = pd.Series(False, index=df.index)
    if "_Computed_Age_Days" in df.columns:
        mask |= df["_Computed_Age_Days"].fillna(999) <= 3
    bkt = col_map.get("Bucket")
    if bkt and bkt in df.columns:
        mask |= df[bkt].astype(str).str.strip() == "0-15"
    mask |= _kw_mask(df, col_map, ["Type of break"], _TIM_KW)
    return mask


def _flag_ssi(df, col_map):
    return _kw_mask(df, col_map, ["Comments","Jira Desc","System to be Fixed"], _SSI_KW)


def _flag_ca(df, col_map):
    return _kw_mask(df, col_map, ["Comments","Jira Desc","Thematic"], _CA_KW)


# ── Sidebar filters ───────────────────────────────────────────────────────────

def apply_filters(df: pd.DataFrame, col_map: dict, filter_options: dict) -> pd.DataFrame:
    st.sidebar.markdown("---")
    st.sidebar.markdown("### 🔍 Global Filters")

    where_parts = []

    for key, label, wkey in [
        ("Period",                     "Period",        "f_period"),
        ("Team",                       "Team",          "f_team"),
        ("Rec Name (as per Rec Cube)", "Rec Name",      "f_rec"),
        ("Entity",                     "Entity",        "f_entity"),
        ("Asset Class",                "Asset Class",   "f_ac"),
        ("Type of break",              "Type of Break", "f_tob"),
        ("True/Systemic Breaks",       "True/Systemic", "f_ts"),
    ]:
        opts = filter_options.get(key, [])
        if not opts:
            continue
        sel = st.sidebar.multiselect(label, opts, default=opts, key=wkey)
        if sel and len(sel) < len(opts):
            col = col_map[key]
            esc = [str(v).replace("'", "''") for v in sel]
            where_parts.append(
                f'"{col}" IN ({", ".join(f"chr(39)||{repr(v)}||chr(39)" for v in esc)})'
            )
            # Use IN with explicit quoting
            in_list = ", ".join(f"'{v}'" for v in esc)
            where_parts[-1] = f'"{col}" IN ({in_list})'

    abs_col = col_map.get("ABS GBP") or col_map.get("BREAK AMOUNT GBP")
    if abs_col and abs_col in df.columns:
        max_v = float(df[abs_col].abs().max() or 1_000_000)
        thresh = st.sidebar.number_input(
            "Min ABS GBP (£)", min_value=0.0,
            max_value=float(min(max_v, 1e9)),
            value=0.0, step=1000.0, format="%.0f", key="f_thresh")
        if thresh > 0:
            where_parts.append(f'ABS({safe_amount_expr(abs_col)}) >= {thresh}')

    if st.sidebar.checkbox("Exclude False Positives", False, key="f_fp"):
        where_parts.append("_False_Positive = false")

    if not where_parts:
        return df

    sql = f"SELECT * FROM tbl WHERE {' AND '.join(where_parts)}"
    try:
        return dq(sql, df)
    except Exception:
        return df


# ═══════════════════════════════════════════════════════════════════════════════
# TAB 1: DATA QUALITY
# ═══════════════════════════════════════════════════════════════════════════════

def tab_data_quality(df, col_map, violations_df, file_bytes, filename,
                     dropped_cols, filtered_for_del):
    st.markdown("## Data Quality & Ingestion Scorecard")

    overflow_count = st.session_state.get("_amount_overflow_count", 0)
    if overflow_count > 0:
        st.markdown(
            f'<div class="banner-warn">⚠️ <b>Amount Overflow Detected:</b> '
            f'{format_number(overflow_count)} ABS GBP values exceeded the maximum '
            f'safe integer (2^53 = ~9 quadrillion). These were set to NaN and counted as '
            f'violations. This typically means the Excel file stores amounts in minor '
            f'currency units (pence) or has a formula error. Check the raw data.</div>',
            unsafe_allow_html=True)

    vcount = int(violations_df["Violation Count"].sum()) if len(violations_df) else 0
    if vcount > 0:
        st.markdown(
            f'<div class="banner-warn">⚠️ {format_number(vcount)} type violations '
            f'across {len(violations_df)} column(s).</div>',
            unsafe_allow_html=True)
    if dropped_cols:
        st.markdown(
            f'<div class="banner-info">🗑️ Auto-removed {len(dropped_cols)} blank trailing '
            f'column(s): {", ".join(dropped_cols)}</div>', unsafe_allow_html=True)
    if filtered_for_del:
        st.markdown(
            f'<div class="banner-info">✅ For Del filter removed '
            f'{format_number(filtered_for_del)} records before processing.</div>',
            unsafe_allow_html=True)

    n_rows = len(df)
    n_cols = len(df.columns)
    cells  = n_rows * n_cols
    comp   = round(df.notna().sum().sum() / cells * 100, 1) if cells else 0

    timing_pct = round(df["_is_timing"].mean() * 100, 1) if "_is_timing" in df.columns else 0
    ssi_pct    = round(df["_has_ssi"].mean() * 100, 1)   if "_has_ssi"   in df.columns else 0

    c1, c2, c3, c4, c5 = st.columns(5)
    with c1: kpi_card("Total Records",    format_number(n_rows))
    with c2: kpi_card("Completeness",     f"{comp}%")
    with c3: kpi_card("Type Violations",  format_number(vcount),
                      warn=(vcount > 0), invert=True)
    with c4: kpi_card("For Del Filtered", format_number(filtered_for_del))
    with c5: kpi_card("Pareto Coverage",
                      f"{round(timing_pct+ssi_pct,1)}%",
                      f"Timing {timing_pct}% + SSI {ssi_pct}%")

    st.markdown("---")
    cl, cr = st.columns(2)

    with cl:
        st.markdown("### Column Completeness")
        exprs = ", ".join(
            f'ROUND(100.0*COUNT("{c}")/COUNT(*),1) AS "{c}"'
            for c in df.columns if not c.startswith("_")
        )
        if exprs:
            comp_df = dq(f"SELECT {exprs} FROM tbl", df).T.reset_index()
            comp_df.columns = ["Column", "Completeness %"]
            comp_df = comp_df.sort_values("Completeness %", ascending=True)
            fig = px.bar(comp_df, x="Completeness %", y="Column",
                         orientation="h", color_discrete_sequence=[PRIMARY])
            fig = chart_layout(fig, "Per-Column Completeness (%)", "Completeness %",
                               height=max(320, len(comp_df) * 16))
            fig.update_layout(yaxis=dict(tickfont=dict(size=9)))
            st.plotly_chart(fig, use_container_width=True)

    with cr:
        st.markdown("### Type Violation Details")
        if len(violations_df):
            render_aggrid(violations_df, height=200, key="tv")
        else:
            st.success("✅ No type violations detected.")

        st.markdown("### Outlier Detection (IQR)")
        out_frames = []
        for key in ("BREAK AMOUNT CCY","BREAK AMOUNT GBP","ABS GBP","Age Days"):
            actual = col_map.get(key)
            if actual and actual in df.columns and df[actual].dtype == np.float64:
                o = detect_outliers_iqr(df[actual], actual)
                if len(o):
                    out_frames.append(o)
        if out_frames:
            render_aggrid(pd.concat(out_frames, ignore_index=True), height=200, key="ol")
        else:
            st.info("No significant outliers detected.")

    st.markdown("### Numeric Summary Statistics")
    num_cols = df.select_dtypes(include=[np.number]).columns
    num_cols = [c for c in num_cols if not c.startswith("_")]
    if num_cols:
        desc = df[num_cols].describe().T.round(2).reset_index().rename(columns={"index":"Column"})
        # Format large values in summary
        for col in desc.columns:
            if col != "Column":
                desc[col] = desc[col].apply(
                    lambda x: format_short(x) if abs(x) > 1e9 else round(x, 2)
                    if isinstance(x, float) else x
                )
        render_aggrid(desc, height=280, key="ns")

    st.markdown("### Phase 2 Readiness Flags")
    if "_is_timing" in df.columns:
        n = len(df)
        flag_rows = [
            {"Flag": "Timing Candidate (#1)",
             "Count": int(df["_is_timing"].sum()),
             "Pct": f"{timing_pct}%",
             "Phase 2 Action": "Auto-classify as Timing — no LLM needed"},
            {"Flag": "SSI Signal (#2)",
             "Count": int(df["_has_ssi"].sum()),
             "Pct": f"{ssi_pct}%",
             "Phase 2 Action": "SSI Clustering engine — one fix closes 15-50 breaks"},
            {"Flag": "CA Signal (#6)",
             "Count": int(df["_has_ca"].sum()),
             "Pct": f"{round(df['_has_ca'].mean()*100,1)}%",
             "Phase 2 Action": "Corporate Action root cause classification"},
        ]
        st.dataframe(pd.DataFrame(flag_rows), use_container_width=True)

    st.markdown("---")
    dl1, dl2 = st.columns(2)
    with dl1:
        st.download_button("📥 Download Cleaned CSV",
                           df.to_csv(index=False).encode("utf-8"),
                           file_name="cleaned_data.csv", mime="text/csv")
    with dl2:
        buf = BytesIO()
        df.to_parquet(buf, index=False, compression="zstd")
        st.download_button("⚡ Download Cleaned Parquet (fast future uploads)",
                           buf.getvalue(), file_name="cleaned_data.parquet",
                           mime="application/octet-stream")


# ═══════════════════════════════════════════════════════════════════════════════
# TAB 2: AGEING VALIDATION
# ═══════════════════════════════════════════════════════════════════════════════

def tab_ageing_validation(df: pd.DataFrame, col_map: dict):
    st.markdown("## Ageing Validation")

    age_col    = col_map.get("Age Days")
    bucket_col = col_map.get("Bucket")
    team_col   = col_map.get("Team")
    rec_col    = col_map.get("Rec Name (as per Rec Cube)")

    required = ["_Computed_Age_Days","_Computed_Bucket","_Age_Match","_Bucket_Match"]
    if not all(c in df.columns for c in required):
        st.warning("Period and Date columns required for ageing validation.")
        return

    kpi = dq(f"""
        SELECT
            COUNT(*) FILTER (WHERE _Computed_Age_Days IS NOT NULL
                AND "{age_col}" IS NOT NULL) AS total_valid,
            COUNT(*) FILTER (WHERE _Age_Match=false
                AND _Computed_Age_Days IS NOT NULL) AS age_mis,
            COUNT(*) FILTER (WHERE _Bucket_Match=false
                AND _Computed_Age_Days IS NOT NULL) AS bucket_mis
        FROM tbl
    """, df).iloc[0]

    n   = int(kpi["total_valid"])
    am  = int(kpi["age_mis"])
    bm  = int(kpi["bucket_mis"])
    ap  = round(am / n * 100, 1) if n else 0
    bp  = round(bm / n * 100, 1) if n else 0
    acc = round(100 - max(ap, bp), 1)

    c1,c2,c3,c4 = st.columns(4)
    with c1: kpi_card("Records Validated",    format_number(n))
    with c2: kpi_card("Age Discrepancies",    f"{format_number(am)} ({ap}%)",
                      warn=(ap > 5), invert=True)
    with c3: kpi_card("Bucket Discrepancies", f"{format_number(bm)} ({bp}%)",
                      warn=(bp > 5), invert=True)
    with c4: kpi_card("Accuracy Rate",        f"{acc}%")

    st.markdown("---")
    st.markdown("### Discrepancy Records — Flag False Positives")
    st.markdown(
        '<div class="banner-info">💡 <b>False Positive Flagging:</b> Tick the False Positive '
        'checkbox to mark records as known exceptions. Use the sidebar toggle to exclude them '
        'from all tabs globally.</div>', unsafe_allow_html=True)

    sel_sql = ", ".join(
        f'"{col_map[k]}"' for k in
        ["Period","Team","Rec Name (as per Rec Cube)","Entity","Date","TRADE REF"]
        if k in col_map and col_map[k] in df.columns
    )
    disc = dq(f"""
        SELECT {sel_sql},
               "{age_col}" AS "Age Days (Source)",
               _Computed_Age_Days AS "Age Days (Computed)",
               "{bucket_col}" AS "Bucket (Source)",
               _Computed_Bucket   AS "Bucket (Computed)",
               _Age_Match    AS "Age Match",
               _Bucket_Match AS "Bucket Match",
               _False_Positive AS "False Positive"
        FROM tbl
        WHERE (_Age_Match=false OR _Bucket_Match=false)
          AND _Computed_Age_Days IS NOT NULL
        ORDER BY _Computed_Age_Days DESC LIMIT 500
    """, df)

    if len(disc):
        fp_ed = st.data_editor(disc,
            column_config={
                "False Positive": st.column_config.CheckboxColumn("False Positive?"),
                "Age Match":      st.column_config.CheckboxColumn("Age Match"),
                "Bucket Match":   st.column_config.CheckboxColumn("Bucket Match"),
            },
            use_container_width=True, height=400, num_rows="fixed", key="fp_editor")
        fp_cnt = int(fp_ed["False Positive"].sum())
        fc1, fc2, fc3 = st.columns(3)
        with fc1: kpi_card("Total Discrepancies",    format_number(len(disc)))
        with fc2: kpi_card("Flagged False Positive", format_number(fp_cnt))
        with fc3: kpi_card("Net Outstanding",
                           format_number(len(disc) - fp_cnt),
                           warn=(len(disc) - fp_cnt > 0))
    else:
        st.success("✅ No discrepancies found!")
        disc = pd.DataFrame()

    # Charts
    st.markdown("---")
    cl, cr = st.columns(2)
    with cl:
        hist = dq(f"""
            SELECT "{age_col}" AS prepop, _Computed_Age_Days AS computed
            FROM tbl WHERE _Computed_Age_Days IS NOT NULL AND "{age_col}" IS NOT NULL
        """, df)
        fig = go.Figure()
        fig.add_trace(go.Histogram(x=hist["prepop"], name="Pre-populated",
                                   opacity=0.6, marker_color=COLORS[0], nbinsx=50))
        fig.add_trace(go.Histogram(x=hist["computed"], name="Computed",
                                   opacity=0.6, marker_color=COLORS[4], nbinsx=50))
        fig.update_layout(barmode="overlay")
        fig = chart_layout(fig,"Age Days: Computed vs Pre-populated","Age Days","Count")
        st.plotly_chart(fig, use_container_width=True)

    with cr:
        bkt = dq("""
            SELECT _Computed_Bucket AS bucket, COUNT(*) AS computed FROM tbl
            WHERE _Computed_Age_Days IS NOT NULL GROUP BY _Computed_Bucket
        """, df)
        pre = dq(f"""
            SELECT "{bucket_col}" AS bucket, COUNT(*) AS prepop FROM tbl GROUP BY "{bucket_col}"
        """, df)
        merged = bkt.merge(pre, on="bucket", how="outer").fillna(0)
        merged["bucket"] = pd.Categorical(merged["bucket"], categories=BUCKET_ORDER, ordered=True)
        merged = merged.sort_values("bucket")
        fig = go.Figure()
        fig.add_trace(go.Bar(x=merged["bucket"], y=merged["prepop"],
                             name="Pre-populated", marker_color=COLORS[0]))
        fig.add_trace(go.Bar(x=merged["bucket"], y=merged["computed"],
                             name="Computed", marker_color=COLORS[4]))
        fig.update_layout(barmode="group")
        fig = chart_layout(fig,"Bucket Distribution: Computed vs Pre-populated","Bucket","Count")
        st.plotly_chart(fig, use_container_width=True)

    # Trend section
    st.markdown("---")
    st.markdown("## Trend Analysis: Break Ageing")
    if "_Period_label" not in df.columns:
        st.info("Period column not available.")
        return

    period_order = sorted(df["_Period_label"].dropna().unique().tolist())
    show_rolling = st.checkbox("Show rolling average on trend charts", True, key="age_rolling")

    ct1, ct2 = st.columns(2)
    with ct1:
        tr = dq("""
            SELECT _Period_label AS period,
                   AVG(_Computed_Age_Days) AS mean_age,
                   MEDIAN(_Computed_Age_Days) AS median_age
            FROM tbl WHERE _Computed_Age_Days IS NOT NULL
            GROUP BY _Period_label ORDER BY _Period_label
        """, df)
        fig = go.Figure()
        fig.add_trace(go.Bar(x=tr["period"], y=tr["mean_age"],
                             name="Mean Age Days", marker_color=COLORS[0], opacity=0.7))
        fig.add_trace(go.Scatter(x=tr["period"], y=tr["median_age"], name="Median",
                                 line=dict(color=COLORS[4], width=2), mode="lines+markers"))
        if show_rolling:
            fig = add_rolling_avg(fig, tr["period"], tr["mean_age"])
        fig = chart_layout(fig,"Average Age Days Trend","Period","Days")
        st.plotly_chart(fig, use_container_width=True)

    with ct2:
        bt = dq("""
            SELECT _Period_label AS period, _Computed_Bucket AS bucket, COUNT(*) AS cnt
            FROM tbl WHERE _Computed_Age_Days IS NOT NULL
            GROUP BY _Period_label, _Computed_Bucket ORDER BY _Period_label
        """, df)
        bt["bucket"] = pd.Categorical(bt["bucket"], categories=BUCKET_ORDER, ordered=True)
        fig = px.bar(bt, x="period", y="cnt", color="bucket",
                     color_discrete_sequence=COLORS, barmode="stack",
                     category_orders={"period":period_order,"bucket":BUCKET_ORDER})
        fig = chart_layout(fig,"Ageing Bucket Distribution Over Time","Period","Count")
        st.plotly_chart(fig, use_container_width=True)

    if len(disc) > 0:
        st.download_button("📥 Download Discrepancy Report",
                           disc.to_csv(index=False).encode("utf-8"),
                           file_name="ageing_discrepancy.csv", mime="text/csv")


# ═══════════════════════════════════════════════════════════════════════════════
# TAB 3: BREAK COUNTS
# ═══════════════════════════════════════════════════════════════════════════════

def tab_break_counts(df: pd.DataFrame, col_map: dict):
    st.markdown("## Trend Analysis: Break Counts")

    period_col = col_map.get("Period")
    team_col   = col_map.get("Team")
    rec_col    = col_map.get("Rec Name (as per Rec Cube)")
    ac_col     = col_map.get("Asset Class")
    ts_col     = col_map.get("True/Systemic Breaks")
    bucket_col = col_map.get("Bucket")

    if not period_col or period_col not in df.columns:
        st.warning("Period column not found.")
        return
    if "_Period_label" not in df.columns:
        return

    period_order = sorted(df["_Period_label"].dropna().unique().tolist())
    latest = period_order[-1] if period_order else "0"
    prev   = period_order[-2] if len(period_order) >= 2 else "0"
    show_rolling = st.checkbox("Show rolling average", True, key="cnt_rolling")

    kpi = dq(f"""
        SELECT COUNT(*) AS total,
               COUNT(*) FILTER (WHERE _Period_label='{latest}') AS lat,
               COUNT(*) FILTER (WHERE _Period_label='{prev}')   AS prv
        FROM tbl
    """, df).iloc[0]

    mom = safe_mom_pct(int(kpi["lat"]), int(kpi["prv"]))
    c1,c2,c3,c4 = st.columns(4)
    with c1: kpi_card("Total Breaks",   format_number(kpi["total"]))
    with c2: kpi_card("Latest Period",  format_number(kpi["lat"]),
                      f"{'+'if mom and mom>0 else ''}{mom}% MoM" if mom else None,
                      invert=True, warn=(mom is not None and mom > 15))
    with c3: kpi_card("Avg/Period",
                      format_number(round(kpi["total"]/max(len(period_order),1))))
    with c4: kpi_card("Periods",        str(len(period_order)))

    st.markdown("---")
    ca, cb = st.columns(2)
    with ca:
        p_df = dq("""
            SELECT _Period_label AS period, COUNT(*) AS cnt
            FROM tbl GROUP BY _Period_label ORDER BY _Period_label
        """, df)
        fig = go.Figure()
        fig.add_trace(go.Bar(x=p_df["period"], y=p_df["cnt"],
                             name="Count", marker_color=COLORS[0], opacity=0.7))
        fig.add_trace(go.Scatter(x=p_df["period"], y=p_df["cnt"],
                                 name="Actual", mode="lines+markers",
                                 line=dict(color=COLORS[4], width=2)))
        if show_rolling:
            fig = add_rolling_avg(fig, p_df["period"], p_df["cnt"])
        fig = chart_layout(fig,"Break Count Trend by Period","Period","Count")
        st.plotly_chart(fig, use_container_width=True)

    with cb:
        if team_col and team_col in df.columns:
            t_df = dq(f"""
                SELECT "{team_col}" AS team, _Period_label AS period, COUNT(*) AS cnt
                FROM tbl GROUP BY "{team_col}", _Period_label ORDER BY _Period_label
            """, df)
            fig = px.bar(t_df, x="period", y="cnt", color="team",
                         color_discrete_sequence=COLORS, barmode="group")
            fig = chart_layout(fig,"Break Count by Team","Period","Count")
            st.plotly_chart(fig, use_container_width=True)

    cc, cd = st.columns(2)
    with cc:
        if rec_col and rec_col in df.columns:
            top10 = dq(f"""
                SELECT "{rec_col}" AS rec FROM tbl
                GROUP BY "{rec_col}" ORDER BY COUNT(*) DESC LIMIT 10
            """, df)["rec"].tolist()
            in_list = ", ".join(f"'{str(r).replace(chr(39),chr(39)*2)}'" for r in top10)
            r_df = dq(f"""
                SELECT "{rec_col}" AS rec, _Period_label AS period, COUNT(*) AS cnt
                FROM tbl WHERE "{rec_col}" IN ({in_list})
                GROUP BY "{rec_col}", _Period_label ORDER BY _Period_label
            """, df)
            fig = px.line(r_df, x="period", y="cnt", color="rec",
                          color_discrete_sequence=COLORS, markers=True)
            fig = chart_layout(fig,"Top 10 Rec Names — Break Count Over Periods","Period","Count")
            st.plotly_chart(fig, use_container_width=True)

    with cd:
        if ts_col and ts_col in df.columns:
            ts_df = dq(f"""
                SELECT "{ts_col}" AS ts, _Period_label AS period, COUNT(*) AS cnt
                FROM tbl GROUP BY "{ts_col}", _Period_label ORDER BY _Period_label
            """, df)
            fig = px.bar(ts_df, x="period", y="cnt", color="ts",
                         color_discrete_sequence=COLORS, barmode="stack")
            fig = chart_layout(fig,"True vs Systemic Breaks Over Periods","Period","Count")
            st.plotly_chart(fig, use_container_width=True)


# ═══════════════════════════════════════════════════════════════════════════════
# TAB 4: AMOUNT ANALYSIS
# ═══════════════════════════════════════════════════════════════════════════════

def tab_amount_analysis(df: pd.DataFrame, col_map: dict):
    st.markdown("## Trend Analysis: Break Amounts")

    period_col = col_map.get("Period")
    abs_col    = col_map.get("ABS GBP")
    gbp_col    = col_map.get("BREAK AMOUNT GBP")
    team_col   = col_map.get("Team")
    rec_col    = col_map.get("Rec Name (as per Rec Cube)")

    if not period_col or period_col not in df.columns:
        st.warning("Period column not found.")
        return
    amount_col = abs_col if abs_col and abs_col in df.columns else gbp_col
    if not amount_col or amount_col not in df.columns:
        st.warning("No ABS GBP column found.")
        return
    if "_Period_label" not in df.columns:
        return

    period_order = sorted(df["_Period_label"].dropna().unique().tolist())
    latest = period_order[-1] if period_order else "0"
    prev   = period_order[-2] if len(period_order) >= 2 else "0"
    show_rolling = st.checkbox("Show rolling average", True, key="amt_rolling")

    # FIX #6: safe TRY_CAST in all amount SQL
    amt_expr = safe_amount_expr(amount_col)
    kpi = dq(f"""
        SELECT
            SUM(ABS({amt_expr}))                                         AS total,
            AVG(ABS({amt_expr}))                                         AS avg,
            MAX(ABS({amt_expr}))                                         AS max_v,
            SUM(ABS({amt_expr})) FILTER (WHERE _Period_label='{latest}') AS lat,
            SUM(ABS({amt_expr})) FILTER (WHERE _Period_label='{prev}')   AS prv
        FROM tbl
    """, df).iloc[0]

    mom = safe_mom_pct(float(kpi["lat"] or 0), float(kpi["prv"] or 0))
    c1,c2,c3,c4 = st.columns(4)
    with c1: kpi_card("Total ABS GBP",    format_short(kpi["total"]))
    with c2: kpi_card("Latest Period",    format_short(kpi["lat"]),
                      f"{'+'if mom and mom>0 else ''}{mom}% MoM" if mom else None,
                      invert=True, warn=(mom is not None and mom > 15))
    with c3: kpi_card("Avg Break Amount", format_short(kpi["avg"]))
    with c4: kpi_card("Max Single Break", format_short(kpi["max_v"]))

    st.markdown("---")
    ca, cb = st.columns(2)
    with ca:
        p_df = dq(f"""
            SELECT _Period_label AS period,
                   SUM(ABS({amt_expr})) AS total
            FROM tbl GROUP BY _Period_label ORDER BY _Period_label
        """, df)
        p_df["label"] = p_df["total"].apply(format_short)
        fig = go.Figure()
        fig.add_trace(go.Bar(x=p_df["period"], y=p_df["total"],
                             name="Total ABS GBP", marker_color=COLORS[0], opacity=0.7,
                             text=p_df["label"], textposition="outside"))
        fig.add_trace(go.Scatter(x=p_df["period"], y=p_df["total"],
                                 name="Actual", mode="lines+markers",
                                 line=dict(color=COLORS[4], width=2)))
        if show_rolling:
            fig = add_rolling_avg(fig, p_df["period"], p_df["total"])
        fig = chart_layout(fig,"Total ABS GBP by Period","Period","GBP (£)")
        # FIX #1: format Y-axis ticks using short format
        max_y = float(p_df["total"].max())
        if max_y > 1e12:
            fig.update_yaxes(tickformat=".2s")
        st.plotly_chart(fig, use_container_width=True)

    with cb:
        if team_col and team_col in df.columns:
            t_df = dq(f"""
                SELECT "{team_col}" AS team, _Period_label AS period,
                       SUM(ABS({amt_expr})) AS total
                FROM tbl GROUP BY "{team_col}", _Period_label ORDER BY _Period_label
            """, df)
            fig = px.bar(t_df, x="period", y="total", color="team",
                         color_discrete_sequence=COLORS, barmode="group")
            fig = chart_layout(fig,"ABS GBP by Team","Period","GBP (£)")
            st.plotly_chart(fig, use_container_width=True)

    if rec_col and rec_col in df.columns:
        st.markdown("### Top 10 Rec Names by ABS GBP")
        r_df = dq(f"""
            SELECT "{rec_col}" AS rec, SUM(ABS({amt_expr})) AS total
            FROM tbl GROUP BY "{rec_col}" ORDER BY total DESC LIMIT 10
        """, df).sort_values("total", ascending=True)
        r_df["label"] = r_df["total"].apply(format_short)
        fig = px.bar(r_df, x="total", y="rec", orientation="h",
                     color_discrete_sequence=[COLORS[0]])
        fig.update_traces(text=r_df["label"], textposition="outside")
        fig = chart_layout(fig,"Top 10 Rec Names by ABS GBP","GBP (£)","",
                           height=max(300,len(r_df)*32))
        st.plotly_chart(fig, use_container_width=True)


# ═══════════════════════════════════════════════════════════════════════════════
# TAB 5: JIRA FACTOR ANALYSIS
# ═══════════════════════════════════════════════════════════════════════════════

def tab_jira_factor_analysis(df: pd.DataFrame, col_map: dict):
    st.markdown("## Jira Factor Analysis")
    st.markdown(
        '<div class="banner-jira">🔍 <b>Factor Analysis:</b> Identify which Jira tickets, '
        'issue descriptions, and systems are driving the highest break volumes and worst ageing. '
        'The dimension selector below lets you switch between all available factors.</div>',
        unsafe_allow_html=True)

    jira_ref_col  = col_map.get("Jira Reference")
    jira_desc_col = col_map.get("Jira Desc")
    system_col    = col_map.get("System to be Fixed")
    abs_col       = col_map.get("ABS GBP") or col_map.get("BREAK AMOUNT GBP")
    team_col      = col_map.get("Team")
    rec_col       = col_map.get("Rec Name (as per Rec Cube)")
    iss_cat_col   = col_map.get("ISSUE CATEGORY")
    iss_cat2_col  = col_map.get("ISSUE CATEGORY2")
    period_col    = col_map.get("Period")

    # Available factor dimensions (Jira-specific + standard)
    all_dims = {}
    for label, col in [
        ("Jira Reference",     jira_ref_col),
        ("Jira Description",   jira_desc_col),
        ("System to be Fixed", system_col),
        ("Issue Category",     iss_cat_col),
        ("Issue Category 2",   iss_cat2_col),
        ("Team",               team_col),
        ("Rec Name",           rec_col),
        ("Asset Class",        col_map.get("Asset Class")),
        ("Entity",             col_map.get("Entity")),
        ("True/Systemic",      col_map.get("True/Systemic Breaks")),
    ]:
        if col and col in df.columns:
            all_dims[label] = col

    if not all_dims:
        st.info("No Jira or dimension columns found in this dataset.")
        return

    # Jira coverage KPIs
    jira_factor_cols = {k: v for k, v in all_dims.items()
                        if k in ("Jira Reference","Jira Description","System to be Fixed",
                                 "Issue Category","Issue Category 2")}
    if jira_factor_cols:
        st.markdown("### Jira Column Coverage")
        cols_ui = st.columns(min(len(jira_factor_cols), 5))
        for i, (label, col) in enumerate(jira_factor_cols.items()):
            filled = dq(f"""
                SELECT COUNT(*) AS total,
                       COUNT(*) FILTER (WHERE "{col}" IS NOT NULL
                           AND TRIM(CAST("{col}" AS VARCHAR)) NOT IN ('','nan','None','N/A'))
                       AS populated
                FROM tbl
            """, df).iloc[0]
            pct = round(int(filled["populated"]) / max(int(filled["total"]), 1) * 100, 1)
            with cols_ui[i % len(cols_ui)]:
                kpi_card(f"{label} Coverage", f"{pct}%",
                         f"{format_number(filled['populated'])} / {format_number(filled['total'])} rows",
                         warn=(pct < 50))

    st.markdown("---")
    sel_dim = st.selectbox("Select Factor Dimension", list(all_dims.keys()), key="jira_dim")
    dim_col = all_dims[sel_dim]

    period_order = (sorted(df["_Period_label"].dropna().unique().tolist())
                    if "_Period_label" in df.columns else [])
    latest = period_order[-1] if period_order else "0"
    prev   = period_order[-2] if len(period_order) >= 2 else "0"

    # Safe amount expression
    amt_clause  = f', SUM(ABS({safe_amount_expr(abs_col)})) AS total_abs_gbp' if abs_col and abs_col in df.columns else ""
    age_clauses = (", AVG(_Computed_Age_Days) AS avg_age, MAX(_Computed_Age_Days) AS max_age"
                   ", COUNT(*) FILTER (WHERE _Computed_Age_Days>90) AS over_90d"
                   ", COUNT(*) FILTER (WHERE _Computed_Age_Days>365) AS over_365d"
                   if "_Computed_Age_Days" in df.columns else "")

    not_null_filter = f"""
        WHERE "{dim_col}" IS NOT NULL
          AND TRIM(CAST("{dim_col}" AS VARCHAR)) NOT IN ('','nan','None','N/A')
    """

    st.markdown(f"### {sel_dim} — Factor Summary")
    summary = dq(f"""
        SELECT "{dim_col}" AS factor,
               COUNT(*) AS break_count
               {age_clauses}
               {amt_clause}
        FROM tbl {not_null_filter}
        GROUP BY "{dim_col}" ORDER BY break_count DESC
    """, df)

    rename_map = {"factor": sel_dim, "break_count": "Break Count",
                  "avg_age": "Avg Age Days", "max_age": "Max Age Days",
                  "total_abs_gbp": "Total ABS GBP",
                  "over_90d": "Count > 90d", "over_365d": "Count > 365d"}
    summary = summary.rename(columns={k: v for k, v in rename_map.items() if k in summary.columns})
    if "Total ABS GBP" in summary.columns:
        summary["Total ABS GBP"] = summary["Total ABS GBP"].apply(format_short)
    if "Avg Age Days" in summary.columns:
        summary["Avg Age Days"] = summary["Avg Age Days"].round(1)

    render_aggrid(summary, height=360, key="jira_sum")

    st.markdown("---")
    r1a, r1b = st.columns(2)

    with r1a:
        top_cnt = dq(f"""
            SELECT "{dim_col}" AS factor, COUNT(*) AS cnt
            FROM tbl {not_null_filter}
            GROUP BY "{dim_col}" ORDER BY cnt DESC LIMIT 10
        """, df).sort_values("cnt", ascending=True)
        fig = px.bar(top_cnt, x="cnt", y="factor", orientation="h",
                     color_discrete_sequence=[PRIMARY])
        fig = chart_layout(fig, f"Top 10 {sel_dim} by Break Count",
                           "Break Count", "", height=max(300, len(top_cnt)*32))
        st.plotly_chart(fig, use_container_width=True)

    with r1b:
        if "_Computed_Age_Days" in df.columns:
            top_age = dq(f"""
                SELECT "{dim_col}" AS factor, AVG(_Computed_Age_Days) AS avg_age
                FROM tbl {not_null_filter} AND _Computed_Age_Days IS NOT NULL
                GROUP BY "{dim_col}" ORDER BY avg_age DESC LIMIT 10
            """, df).sort_values("avg_age", ascending=True)
            fig = px.bar(top_age, x="avg_age", y="factor", orientation="h",
                         color_discrete_sequence=[COLORS[4]])
            fig = chart_layout(fig, f"Top 10 {sel_dim} by Avg Age Days",
                               "Avg Age Days", "", height=max(300, len(top_age)*32))
            st.plotly_chart(fig, use_container_width=True)

    if abs_col and abs_col in df.columns:
        r2a, r2b = st.columns(2)
        with r2a:
            top_amt = dq(f"""
                SELECT "{dim_col}" AS factor,
                       SUM(ABS({safe_amount_expr(abs_col)})) AS total
                FROM tbl {not_null_filter}
                GROUP BY "{dim_col}" ORDER BY total DESC LIMIT 10
            """, df).sort_values("total", ascending=True)
            top_amt["label"] = top_amt["total"].apply(format_short)
            fig = px.bar(top_amt, x="total", y="factor", orientation="h",
                         color_discrete_sequence=[COLORS[2]])
            fig.update_traces(text=top_amt["label"], textposition="outside")
            fig = chart_layout(fig, f"Top 10 {sel_dim} by ABS GBP",
                               "GBP (£)", "", height=max(300, len(top_amt)*32))
            st.plotly_chart(fig, use_container_width=True)

        with r2b:
            if "_Computed_Age_Days" in df.columns:
                risk = dq(f"""
                    SELECT "{dim_col}" AS factor,
                           COUNT(*) AS total,
                           COUNT(*) FILTER (WHERE _Computed_Age_Days>90) AS over90
                    FROM tbl {not_null_filter} AND _Computed_Age_Days IS NOT NULL
                    GROUP BY "{dim_col}" ORDER BY over90 DESC LIMIT 10
                """, df)
                risk[">90 Day %"] = (risk["over90"] / risk["total"] * 100).round(1)
                risk = risk.sort_values(">90 Day %", ascending=True)
                fig = px.bar(risk, x=">90 Day %", y="factor", orientation="h",
                             color_discrete_sequence=[WARN])
                fig = chart_layout(fig, f"Top 10 {sel_dim} — % Breaks > 90 Days",
                                   "% > 90 Days", "", height=max(300, len(risk)*32))
                st.plotly_chart(fig, use_container_width=True)

    # Period trend for top 5
    if period_order and "_Period_label" in df.columns:
        st.markdown(f"### {sel_dim} — Period Trend (Top 5)")
        top5 = dq(f"""
            SELECT "{dim_col}" AS factor FROM tbl {not_null_filter}
            GROUP BY "{dim_col}" ORDER BY COUNT(*) DESC LIMIT 5
        """, df)["factor"].tolist()
        top5_in = ", ".join(f"'{str(v).replace(chr(39),chr(39)*2)}'" for v in top5)
        tr_df = dq(f"""
            SELECT "{dim_col}" AS factor, _Period_label AS period, COUNT(*) AS cnt
            FROM tbl WHERE "{dim_col}" IN ({top5_in})
            GROUP BY "{dim_col}", _Period_label ORDER BY _Period_label
        """, df)
        fig = px.line(tr_df, x="period", y="cnt", color="factor",
                      color_discrete_sequence=COLORS, markers=True)
        fig = chart_layout(fig, f"Top 5 {sel_dim} — Break Count Trend","Period","Count")
        st.plotly_chart(fig, use_container_width=True)

    # MoM change
    if len(period_order) >= 2:
        st.markdown(f"### MoM Change: {prev} → {latest}")
        mom_df = dq(f"""
            SELECT "{dim_col}" AS factor,
                   COUNT(*) FILTER (WHERE _Period_label='{latest}') AS lat,
                   COUNT(*) FILTER (WHERE _Period_label='{prev}')   AS prv
            FROM tbl {not_null_filter}
            GROUP BY "{dim_col}"
        """, df)
        mom_df["MoM Δ"]   = mom_df["lat"] - mom_df["prv"]
        mom_df["MoM Δ %"] = ((mom_df["lat"] - mom_df["prv"]) /
                              mom_df["prv"].replace(0, np.nan) * 100).round(1)
        mom_df = mom_df.sort_values("MoM Δ")
        bar_colors = [COLORS[0] if v >= 0 else COLORS[4] for v in mom_df["MoM Δ"]]
        fig = go.Figure(go.Bar(
            x=mom_df["MoM Δ"], y=mom_df["factor"], orientation="h",
            marker_color=bar_colors,
            text=mom_df["MoM Δ"].apply(lambda x: f"+{x:,}" if x >= 0 else f"{x:,}"),
            textposition="outside",
        ))
        fig.add_vline(x=0, line_dash="dash", line_color=MUTED, line_width=1)
        fig = chart_layout(fig, f"MoM Break Count Change by {sel_dim}",
                           "Change in Break Count","", height=max(360, len(mom_df)*26))
        st.plotly_chart(fig, use_container_width=True)

    # Cross-dim heatmap (Jira Ref × System)
    if (jira_ref_col and jira_ref_col in df.columns and
            system_col and system_col in df.columns):
        st.markdown("### Jira Reference × System to be Fixed — Heatmap")
        cross = dq(f"""
            SELECT "{jira_ref_col}" AS jira_ref, "{system_col}" AS system_fix,
                   COUNT(*) AS cnt
            FROM tbl
            WHERE "{jira_ref_col}" IS NOT NULL AND "{system_col}" IS NOT NULL
              AND TRIM(CAST("{jira_ref_col}" AS VARCHAR)) NOT IN ('','nan','None','N/A')
              AND TRIM(CAST("{system_col}"   AS VARCHAR)) NOT IN ('','nan','None','N/A')
            GROUP BY "{jira_ref_col}", "{system_col}"
            ORDER BY cnt DESC LIMIT 200
        """, df)
        if len(cross):
            pivot = cross.pivot_table(index="jira_ref", columns="system_fix",
                                      values="cnt", fill_value=0)
            top20 = cross.groupby("jira_ref")["cnt"].sum().nlargest(20).index
            pivot = pivot.loc[pivot.index.isin(top20)]
            fig = px.imshow(pivot, color_continuous_scale=["#E8F5E9","#FFC553","#A84B2F"],
                            aspect="auto", text_auto=".0f")
            fig = chart_layout(fig,"Jira Ref × System to be Fixed","","",
                               height=max(350, len(pivot)*26))
            st.plotly_chart(fig, use_container_width=True)

    st.download_button(f"📥 Download {sel_dim} Factor Summary (CSV)",
                       summary.to_csv(index=False).encode("utf-8"),
                       file_name=f"factor_{sel_dim.replace(' ','_').lower()}.csv",
                       mime="text/csv")


# ═══════════════════════════════════════════════════════════════════════════════
# TAB 6: PHASE 2 INTELLIGENCE PREVIEW
# ═══════════════════════════════════════════════════════════════════════════════

def tab_phase2_preview(df: pd.DataFrame, col_map: dict):
    st.markdown("## Phase 2 Intelligence Preview")
    st.markdown(
        '<div class="banner-phase2">🚀 <b>Phase 2 Readiness:</b> This tab shows the data '
        'that will feed Phase 2 — the LLM/RAG root cause engine, SSI clustering, '
        'and BERTopic taxonomy discovery. No LLM calls are made here — these are '
        'pre-computed signals from Phase 1 flags.</div>', unsafe_allow_html=True)

    n = len(df)
    abs_col = col_map.get("ABS GBP") or col_map.get("BREAK AMOUNT GBP")
    amt_expr = safe_amount_expr(abs_col) if abs_col and abs_col in df.columns else "0"

    # ── Pareto Coverage ─────────────────────────────────────────────────────
    st.markdown("### Pareto Root Cause Coverage")
    st.markdown("Phase 2 Rule Engine classifies these two categories **without any LLM cost**, "
                "covering the majority of break volume.")

    timing_n = int(df["_is_timing"].sum()) if "_is_timing" in df.columns else 0
    ssi_n    = int(df["_has_ssi"].sum())   if "_has_ssi"   in df.columns else 0
    ca_n     = int(df["_has_ca"].sum())    if "_has_ca"    in df.columns else 0
    timing_pct = round(timing_n / n * 100, 1)
    ssi_pct    = round(ssi_n    / n * 100, 1)
    ca_pct     = round(ca_n     / n * 100, 1)
    pareto_pct = round((timing_n + ssi_n) / n * 100, 1)

    c1,c2,c3,c4 = st.columns(4)
    with c1: kpi_card("Timing Candidates (#1)", f"{timing_pct}%",
                      f"{format_number(timing_n)} breaks")
    with c2: kpi_card("SSI Signals (#2)",       f"{ssi_pct}%",
                      f"{format_number(ssi_n)} breaks")
    with c3: kpi_card("CA Signals (#6)",        f"{ca_pct}%",
                      f"{format_number(ca_n)} breaks")
    with c4: kpi_card("Pareto Coverage",        f"{pareto_pct}%",
                      "Timing + SSI auto-classifiable")

    pareto_data = pd.DataFrame({
        "Category":    ["Timing (#1)", "SSI/Static (#2)", "CA (#6)", "Needs LLM / Manual"],
        "Break Count": [timing_n, ssi_n, ca_n, n - timing_n - ssi_n - ca_n],
    })
    pareto_data["Break Count"] = pareto_data["Break Count"].clip(lower=0)
    fig = px.pie(pareto_data, values="Break Count", names="Category",
                 color_discrete_sequence=[PRIMARY, COLORS[4], COLORS[8], MUTED],
                 hole=0.45)
    fig = chart_layout(fig, "Phase 2 Pareto Coverage", height=320)
    st.plotly_chart(fig, use_container_width=True)

    # ── SSI Clustering Preview ───────────────────────────────────────────────
    st.markdown("---")
    st.markdown("### SSI Clustering Preview")
    st.markdown("Groups SSI-flagged breaks by Entity + TRADE CCY + Rec Name. "
                "Each cluster = ONE SSI record to fix → closes all related breaks.")

    if "_has_ssi" in df.columns:
        ssi_df = df[df["_has_ssi"]].copy()
        if len(ssi_df) > 0:
            rec_col    = col_map.get("Rec Name (as per Rec Cube)")
            entity_col = col_map.get("Entity")
            ccy_col    = col_map.get("TRADE CCY")
            group_cols = [c for c in [rec_col, entity_col, ccy_col]
                          if c and c in ssi_df.columns]
            if group_cols:
                # Register just the SSI subset
                get_duck().register("ssi_tbl", ssi_df)
                cluster_cols = ", ".join(f'"{c}"' for c in group_cols)
                clusters = get_duck().execute(f"""
                    SELECT {cluster_cols}, COUNT(*) AS breaks_in_cluster
                    FROM ssi_tbl
                    GROUP BY {cluster_cols}
                    HAVING COUNT(*) >= 3
                    ORDER BY breaks_in_cluster DESC
                    LIMIT 20
                """).df()
                if len(clusters):
                    st.markdown(f"**{len(clusters)} SSI clusters identified** "
                                f"(each cluster = 1 SSI fix to close all related breaks):")
                    clusters["Action"] = "Raise 1 JIRA to fix SSI → closes all breaks in cluster"
                    render_aggrid(clusters, height=320, key="ssi_clusters")

                    total_fixable = int(clusters["breaks_in_cluster"].sum())
                    st.markdown(
                        f'<div class="banner-info">💡 <b>High Value:</b> '
                        f'Fixing <b>{len(clusters)} SSI records</b> would close '
                        f'<b>{format_number(total_fixable)} breaks</b> '
                        f'({round(total_fixable/n*100,1)}% of all breaks in current filter).'
                        f'</div>', unsafe_allow_html=True)
            else:
                st.info("Rec Name, Entity, or TRADE CCY columns not found for clustering.")
        else:
            st.info("No SSI-flagged breaks in current filter.")

    # ── ISSUE CATEGORY taxonomy preview ─────────────────────────────────────
    st.markdown("---")
    st.markdown("### Issue Category Analysis (Phase 2 Taxonomy Validation)")
    st.markdown("The ISSUE CATEGORY column provides a partial taxonomy already in the data. "
                "Phase 2 will validate and extend this with BERTopic discovery on Comments.")

    iss_col = col_map.get("ISSUE CATEGORY")
    if iss_col and iss_col in df.columns:
        cat_df = dq(f"""
            SELECT "{iss_col}" AS issue_category,
                   COUNT(*) AS break_count,
                   ROUND(100.0 * COUNT(*) / SUM(COUNT(*)) OVER (), 1) AS pct
            FROM tbl
            WHERE "{iss_col}" IS NOT NULL
              AND TRIM(CAST("{iss_col}" AS VARCHAR)) NOT IN ('','nan','None','N/A')
            GROUP BY "{iss_col}" ORDER BY break_count DESC LIMIT 20
        """, df)
        if len(cat_df):
            cat_df["pct"] = cat_df["pct"].apply(lambda x: f"{x}%")
            fig = px.bar(cat_df.sort_values("break_count", ascending=True),
                         x="break_count", y="issue_category", orientation="h",
                         color_discrete_sequence=[COLORS[9]])
            fig = chart_layout(fig,"Issue Category Distribution (Top 20)",
                               "Break Count","", height=max(300, len(cat_df)*28))
            st.plotly_chart(fig, use_container_width=True)
            render_aggrid(cat_df, height=280, key="iss_cat")
    else:
        st.info("ISSUE CATEGORY column not found in this dataset.")

    # ── BERTopic sample preparation ──────────────────────────────────────────
    st.markdown("---")
    st.markdown("### BERTopic Sample Preparation")
    st.markdown("Prepares a 10,000-comment sample for Phase 2A unsupervised topic discovery. "
                "This sample is used to validate the root cause taxonomy before building any classifier.")

    comments_col = col_map.get("Comments")
    if comments_col and comments_col in df.columns:
        valid_comments = df[df[comments_col].notna() &
                            (df[comments_col].astype(str).str.strip() != "")]
        total_comments = len(valid_comments)
        sample_size    = min(10_000, total_comments)

        kc1, kc2 = st.columns(2)
        with kc1:
            kpi_card("Total Non-Null Comments", format_number(total_comments))
        with kc2:
            kpi_card("BERTopic Sample Size", format_number(sample_size),
                     "Ready for Phase 2A")

        if st.button("⬇️ Download BERTopic Sample (10K Comments)", key="bertopic_btn"):
            sample = valid_comments[[comments_col]].sample(
                n=sample_size, random_state=42).reset_index(drop=True)
            csv = sample.to_csv(index=False).encode("utf-8")
            st.download_button("📥 Save BERTopic Sample CSV", csv,
                               file_name="bertopic_sample_10k.csv", mime="text/csv")
    else:
        st.info("Comments column not found.")

    # ── Root Cause current state ─────────────────────────────────────────────
    st.markdown("---")
    st.markdown("### Root Cause Identified — Current Population Rate")
    rc_col = col_map.get("Root Cause identified")
    if rc_col and rc_col in df.columns:
        populated = int(df[rc_col].notna().sum())
        pct = round(populated / n * 100, 1)
        kpi_card("Root Cause Identified Population",
                 f"{pct}%",
                 f"{format_number(populated)} / {format_number(n)} records",
                 warn=(pct < 10))
        if pct == 0:
            st.markdown(
                '<div class="banner-warn">⚠️ <b>Root Cause is 0% populated.</b> '
                'Phase 2 will use the LLM/RAG pipeline to populate this column from '
                'Comments + JIRA DESC. Phase 1 SSI clustering and timing flags are the '
                'fastest path to populating it without waiting for LLM approval.</div>',
                unsafe_allow_html=True)


# ═══════════════════════════════════════════════════════════════════════════════
# MAIN
# ═══════════════════════════════════════════════════════════════════════════════

def main():
    st.sidebar.markdown(f"""
    <div style="text-align:center;padding:10px 0 5px">
      <h2 style="color:{PRIMARY};margin:0">Accounting Control AI</h2>
      <p style="color:{MUTED};font-size:.8rem;margin:0">Phase 1 + Phase 2 Preview</p>
    </div>
    """, unsafe_allow_html=True)
    st.sidebar.markdown("---")
    st.sidebar.markdown("### Data Upload")

    uploaded = st.sidebar.file_uploader(
        "Upload CSV / Excel / Parquet",
        type=["csv","xlsx","xls","xlsm","parquet"],
        key="uploader",
    )

    if not uploaded:
        st.markdown("## 👋 Welcome")
        st.markdown("""
Upload your **MI Report** (CSV, Excel, or Parquet) to begin.

| Format | First Load | Reruns |
|---|---|---|
| `.parquet` | ⚡ ~0.2s | ⚡ Instant (cached) |
| `.csv`     | 🟢 ~1–2s | ⚡ Instant (cached) |
| `.xlsx`    | 🟡 ~4–8s | ⚡ Instant (cached) |

**6 Tabs:**  Data Quality · Ageing Validation · Break Counts · Amount Analysis · Jira Factor Analysis · Phase 2 Preview

**Key fixes in this version:**
- ✅ `format_short()` handles **K / M / B / T / P** — no more `10^16` on chart axes
- ✅ ABS GBP values > 2^53 flagged as data quality violations (JS integer overflow)
- ✅ DuckDB uses `TRY_CAST AS DOUBLE` for all amount aggregations
- ✅ AgGrid casts large integers to string before rendering
        """)
        return

    file_bytes = uploaded.read()
    filename   = uploaded.name

    result = clean_dataframe(file_bytes, filename)
    df, col_map, filter_options, violations_df, dropped_cols, filtered_for_del = result

    vcount = int(violations_df["Violation Count"].sum()) if len(violations_df) else 0
    overflow = st.session_state.get("_amount_overflow_count", 0)

    st.sidebar.markdown(f"""
    **File:** `{filename}`
    **Rows:** {len(df):,} &nbsp;|&nbsp; **Cols:** {len(df.columns)}
    """)
    if filtered_for_del:
        st.sidebar.caption(f"🗑️ For Del: {filtered_for_del:,} removed")
    if vcount:
        st.sidebar.markdown(
            f'<span style="color:{WARN};font-weight:600">⚠️ {vcount} violations</span>',
            unsafe_allow_html=True)
    if overflow:
        st.sidebar.markdown(
            f'<span style="color:{WARN};font-weight:600">⚠️ {overflow} amount overflows</span>',
            unsafe_allow_html=True)

    df_filtered = apply_filters(df, col_map, filter_options)
    st.sidebar.markdown(f"**Filtered:** {len(df_filtered):,} rows")

    st.markdown(f"""
    <h1 style="margin-bottom:0">Accounting Control AI Platform
    <span style="color:{MUTED};font-size:.85rem"> · Phase 1</span></h1>
    """, unsafe_allow_html=True)

    tab1, tab2, tab3, tab4, tab5, tab6 = st.tabs([
        "🧹 Data Quality",
        "📅 Ageing Validation",
        "📈 Break Counts",
        "💷 Amount Analysis",
        "🔍 Jira Factor Analysis",
        "🚀 Phase 2 Preview",
    ])

    with tab1:
        tab_data_quality(df_filtered, col_map, violations_df,
                         file_bytes, filename, dropped_cols, filtered_for_del)
    with tab2:
        tab_ageing_validation(df_filtered, col_map)
    with tab3:
        tab_break_counts(df_filtered, col_map)
    with tab4:
        tab_amount_analysis(df_filtered, col_map)
    with tab5:
        tab_jira_factor_analysis(df_filtered, col_map)
    with tab6:
        tab_phase2_preview(df_filtered, col_map)


if __name__ == "__main__":
    main()

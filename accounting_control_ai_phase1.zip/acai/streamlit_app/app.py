"""
streamlit_app/app.py
────────────────────
Streamlit analyst app — separate StatPy service.

Run:  streamlit run streamlit_app/app.py --server.port 8501

Reads data directly from the Parquet cache written by the Flask pipeline
(Option A — fastest). Falls back to re-running the pipeline if the file
is uploaded directly into the Streamlit UI.
"""
import os
import sys

# Allow imports from project root
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

import streamlit as st
from dotenv import load_dotenv

load_dotenv()

# ── Page config — MUST be first Streamlit call ────────────────────────────────
st.set_page_config(
    page_title="Accounting Control AI — Analyst",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded",
)

from streamlit_app.utils.loader import (
    load_and_process, compute_file_hash, apply_sidebar_filters
)
from streamlit_app.tabs import (
    data_quality, ageing_validation, break_counts,
    break_amounts, drill_down, threshold_alerts, factor_analysis,
)
from core.constants import PRIMARY, DARK, MUTED, BG_LIGHT

# ── Global CSS ────────────────────────────────────────────────────────────────
st.markdown(f"""
<style>
  .main .block-container {{ padding-top: 1rem; padding-bottom: 1rem; }}
  h1 {{ color: {DARK}; font-size: 1.6rem !important; }}
  h2 {{ color: {DARK}; font-size: 1.25rem !important; }}
  h3 {{ color: {DARK}; font-size: 1.05rem !important; }}
  .stTabs [data-baseweb="tab-list"] {{ gap: 8px; }}
  .stTabs [data-baseweb="tab"] {{
    background-color: {BG_LIGHT}; border-radius: 6px 6px 0 0;
    padding: 8px 16px; font-weight: 600; color: {DARK};
  }}
  .stTabs [aria-selected="true"] {{
    background-color: {PRIMARY} !important; color: white !important;
  }}
</style>
""", unsafe_allow_html=True)

# ── Sidebar — branding + upload ───────────────────────────────────────────────
st.sidebar.markdown(f"""
<div style="text-align:center;padding:10px 0 5px">
  <h2 style="color:{PRIMARY};margin:0">Accounting Control</h2>
  <p style="color:{MUTED};font-size:0.8rem;margin:0">AI Platform · Phase 1 · Analyst</p>
</div>
""", unsafe_allow_html=True)
st.sidebar.markdown("---")

st.sidebar.markdown("### Data Upload")
uploaded_file = st.sidebar.file_uploader(
    "Upload CSV or XLSX", type=["csv", "xlsx", "xlsm"], key="file_upload"
)

# ── Ageing date config ────────────────────────────────────────────────────────
st.sidebar.markdown("### Ageing Date")
date_mode = st.sidebar.radio(
    "Reference date mode",
    ["month_end", "manual"],
    format_func=lambda x: "Month-End (default)" if x == "month_end" else "Manual date",
    key="date_mode",
)
report_run_date = None
if date_mode == "manual":
    report_run_date = st.sidebar.date_input("Report run date", key="run_date")
    report_run_date = str(report_run_date) if report_run_date else None

# ── Load data ─────────────────────────────────────────────────────────────────
result = None

if uploaded_file is not None:
    file_bytes = uploaded_file.read()
    fhash      = compute_file_hash(file_bytes)

    with st.spinner("Processing data…"):
        result = load_and_process(
            file_bytes, uploaded_file.name, fhash, report_run_date, date_mode
        )

    meta = result["metadata"]
    st.sidebar.success(
        f"✅ {uploaded_file.name}\n\n"
        f"{meta['processed_rows']:,} rows · {meta['columns']} cols · "
        f"{meta['processing_ms']}ms"
    )
    if meta["filtered_for_del"]:
        st.sidebar.info(f"For Del filtered: {meta['filtered_for_del']:,} records")
    if meta["surrogate_keys"]:
        st.sidebar.info(f"Surrogate keys assigned: {meta['surrogate_keys']:,}")

    st.sidebar.markdown(f"""
    <div style="background:#E6F4F1;padding:8px 12px;border-radius:4px;
    border-left:4px solid {PRIMARY};font-size:0.8rem;color:#1B474D">
    <b>Phase 2 flags</b><br>
    Timing: {meta['timing_flag_pct']}% &nbsp;|&nbsp;
    SSI: {meta['ssi_flag_pct']}% &nbsp;|&nbsp;
    CA: {meta['ca_flag_pct']}%
    </div>
    """, unsafe_allow_html=True)

else:
    st.markdown(f"""
    <div style="text-align:center;padding:100px 20px">
      <h1 style="color:{PRIMARY}">Accounting Control AI Platform</h1>
      <p style="color:{MUTED};font-size:1.1rem">
        Upload a CSV or XLSX file in the sidebar to begin analysis.
      </p>
      <p style="color:{MUTED};font-size:0.9rem">
        Supports files up to 200 MB · 621K+ rows · 41 columns
      </p>
    </div>
    """, unsafe_allow_html=True)
    st.stop()

# ── Apply global filters ──────────────────────────────────────────────────────
df_raw     = result["df"]
col_map    = result["col_map"]
filter_opt = result["filter_options"]

filtered_df = apply_sidebar_filters(df_raw, col_map, filter_opt)

# ── Header ────────────────────────────────────────────────────────────────────
st.markdown(f"""
<h1 style="margin-bottom:0">
  Accounting Control AI Platform
  <span style="color:{MUTED};font-size:0.85rem;font-weight:400"> · Phase 1 Analyst View</span>
</h1>
""", unsafe_allow_html=True)

# ── Tabs ──────────────────────────────────────────────────────────────────────
tab1, tab2, tab3, tab4, tab5, tab6, tab7 = st.tabs([
    "📋 Data Quality",
    "⏳ Ageing Validation",
    "📊 Break Counts",
    "💰 Break Amounts",
    "🔍 Drill-Down",
    "🚨 Threshold Alerts",
    "📈 Factor Analysis",
])

with tab1:
    data_quality.render(result)

with tab2:
    ageing_validation.render(result)

with tab3:
    break_counts.render(filtered_df, col_map)

with tab4:
    break_amounts.render(filtered_df, col_map)

with tab5:
    drill_down.render(filtered_df, col_map)

with tab6:
    threshold_alerts.render(filtered_df, col_map)

with tab7:
    factor_analysis.render(filtered_df, col_map)

"""streamlit_app/utils/formatters.py — Number and string formatters."""
import pandas as pd


def fmt_number(n, prefix="", decimals=0):
    if n is None or (isinstance(n, float) and pd.isna(n)):
        return "N/A"
    if decimals > 0:
        return f"{prefix}{n:,.{decimals}f}"
    return f"{prefix}{int(n):,}"


def fmt_short(n, prefix="£"):
    if n is None or (isinstance(n, float) and pd.isna(n)):
        return "N/A"
    v = float(n)
    sign = "-" if v < 0 else ""
    v = abs(v)
    if v >= 1_000_000_000:
        return f"{sign}{prefix}{v/1_000_000_000:.1f}B"
    if v >= 1_000_000:
        return f"{sign}{prefix}{v/1_000_000:.1f}M"
    if v >= 1_000:
        return f"{sign}{prefix}{v/1_000:.1f}K"
    return f"{sign}{prefix}{v:,.0f}"


def safe_mom_pct(current, previous):
    if previous is None or previous == 0:
        return None
    return round(((current - previous) / abs(previous)) * 100, 1)

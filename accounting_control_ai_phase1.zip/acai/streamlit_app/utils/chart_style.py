"""streamlit_app/utils/chart_style.py — Shared Plotly theme."""
import plotly.graph_objects as go

COLORS = ["#01696F","#0C4E54","#20808D","#4F98A3","#A84B2F",
          "#1B474D","#BCE2E7","#944454","#FFC553","#5C2D91"]
PRIMARY = "#01696F"
ACCENT  = "#A84B2F"
DARK    = "#28251D"
MUTED   = "#7A7974"


def apply_style(fig, title="", xaxis_title="", yaxis_title="", height=400):
    fig.update_layout(
        title=dict(text=title, font=dict(size=14, color=DARK)),
        xaxis_title=xaxis_title, yaxis_title=yaxis_title,
        height=height, margin=dict(l=40, r=20, t=50, b=40),
        font=dict(family="Inter, sans-serif", size=11, color=DARK),
        plot_bgcolor="white", paper_bgcolor="white",
        legend=dict(font=dict(size=10)),
    )
    fig.update_xaxes(showgrid=True, gridwidth=1, gridcolor="#ECECEC")
    fig.update_yaxes(showgrid=True, gridwidth=1, gridcolor="#ECECEC")
    return fig


def kpi_card(st, label, value, delta=None, invert=False):
    delta_str = None
    if delta:
        neg = (invert and not str(delta).startswith("-")) or \
              (not invert and str(delta).startswith("-"))
        color = "#A84B2F" if neg else "#01696F"
        delta_str = f":{('red' if neg else 'green')}[{delta}]"
    st.markdown(
        f"""<div style="background:white;border-left:4px solid {PRIMARY};
        padding:12px 16px;border-radius:4px;
        box-shadow:0 1px 3px rgba(0,0,0,0.08)">
        <p style="color:{MUTED};font-size:0.72rem;text-transform:uppercase;
        letter-spacing:0.5px;margin:0 0 2px 0">{label}</p>
        <p style="color:{DARK};font-size:1.4rem;font-weight:700;margin:0">{value}</p>
        </div>""",
        unsafe_allow_html=True,
    )

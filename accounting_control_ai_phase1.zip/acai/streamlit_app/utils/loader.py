"""
streamlit_app/utils/loader.py
──────────────────────────────
Loads and processes uploaded file through the core pipeline.
Uses @st.cache_data keyed on file_hash for sub-second reloads.
"""
import hashlib
import sys
import os

import streamlit as st

# Allow imports from project root
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

from core import pipeline
from core.ageing import period_to_datetime_scalar
from core.constants import BUCKET_ORDER


@st.cache_data(show_spinner="Processing data…")
def load_and_process(
    file_bytes: bytes,
    filename: str,
    file_hash: str,
    report_run_date: str | None,
    date_mode: str,
) -> dict:
    """Run the full pipeline. Cached by file_hash — re-runs only on new file."""
    return pipeline.run_pipeline(
        file_bytes=file_bytes,
        filename=filename,
        report_run_date=report_run_date,
        date_mode=date_mode,
    )


def compute_file_hash(file_bytes: bytes) -> str:
    chunk = file_bytes[:4 * 1024 * 1024]
    return hashlib.sha256(chunk + str(len(file_bytes)).encode()).hexdigest()


def apply_sidebar_filters(df, col_map, filter_options):
    """Render sidebar filters and return filtered DataFrame."""
    st.sidebar.markdown("---")
    st.sidebar.markdown("### 🔍 Global Filters")

    selections = {}
    for key, label, widget_key in [
        ("Period",                       "Period",         "f_period"),
        ("Team",                         "Team",           "f_team"),
        ("Rec Name (as per Rec Cube)",   "Rec Name",       "f_rec"),
        ("Entity",                       "Entity",         "f_entity"),
        ("Asset Class",                  "Asset Class",    "f_ac"),
        ("Type of break",                "Type of Break",  "f_tob"),
        ("True/Systemic Breaks",         "True/Systemic",  "f_ts"),
    ]:
        opts = filter_options.get(key, [])
        if not opts:
            continue
        if key == "Period":
            def _fmt(x):
                ts = period_to_datetime_scalar(x)
                return ts.strftime("%Y-%m") if ts is not None and ts is not ts.__class__(None) else str(x)
            try:
                fmt_func = _fmt
            except Exception:
                fmt_func = str
            selections[key] = st.sidebar.multiselect(
                label, opts, default=opts, key=widget_key,
                format_func=lambda x: period_to_datetime_scalar(x).strftime("%Y-%m")
                if period_to_datetime_scalar(x) is not None else str(x)
            )
        else:
            selections[key] = st.sidebar.multiselect(label, opts, default=opts, key=widget_key)

    mask = __import__("pandas").Series(True, index=df.index)
    for key, vals in selections.items():
        actual = col_map.get(key)
        if vals and actual and actual in df.columns:
            mask &= df[actual].isin(vals)

    return df.loc[mask]

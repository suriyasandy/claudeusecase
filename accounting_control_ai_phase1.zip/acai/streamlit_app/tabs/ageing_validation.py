"""Tab 2 — Ageing Validation."""
import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st

from streamlit_app.utils.chart_style import apply_style, kpi_card, COLORS, PRIMARY, ACCENT
from streamlit_app.utils.formatters import fmt_number
from core.constants import BUCKET_ORDER

try:
    from st_aggrid import AgGrid, GridOptionsBuilder, JsCode
    HAS_AGGRID = True
except ImportError:
    HAS_AGGRID = False


def render(result: dict):
    df      = result["df"]
    col_map = result["col_map"]
    age_col    = col_map.get("Age Days")
    bucket_col = col_map.get("Bucket")

    st.markdown("## ⏳ Ageing Validation")

    if "_Computed_Age_Days" not in df.columns:
        st.warning("Ageing not computed — ensure Period and Date columns are present.")
        return

    valid = df[df["_Computed_Age_Days"].notna()]
    if age_col and age_col in df.columns:
        valid = valid[valid[age_col].notna()]
    n = len(valid)

    age_mis    = int((~valid["_Age_Match"]).sum())    if "_Age_Match"    in valid.columns else 0
    bucket_mis = int((~valid["_Bucket_Match"]).sum()) if "_Bucket_Match" in valid.columns else 0
    age_pct    = round(age_mis    / n * 100, 1) if n else 0
    bucket_pct = round(bucket_mis / n * 100, 1) if n else 0
    acc        = round(100 - max(age_pct, bucket_pct), 1)

    mode = df.attrs.get("report_run_date_mode", "month_end")
    used = df.attrs.get("report_run_date_used", "month_end")

    c1, c2, c3, c4, c5 = st.columns(5)
    with c1: kpi_card(st, "Records Validated",     fmt_number(n))
    with c2: kpi_card(st, "Age Discrepancies",      f"{fmt_number(age_mis)} ({age_pct}%)")
    with c3: kpi_card(st, "Bucket Discrepancies",   f"{fmt_number(bucket_mis)} ({bucket_pct}%)")
    with c4: kpi_card(st, "Accuracy Rate",          f"{acc}%")
    with c5: kpi_card(st, "Reference Date Mode",    f"{mode} ({used})")

    st.markdown("---")
    col_left, col_right = st.columns(2)

    with col_left:
        st.markdown("### Age Days Distribution: Computed vs Pre-populated")
        hist_data = valid[[age_col, "_Computed_Age_Days"]].dropna() if age_col else valid[["_Computed_Age_Days"]].dropna()
        if len(hist_data):
            fig = go.Figure()
            if age_col and age_col in hist_data.columns:
                fig.add_trace(go.Histogram(x=hist_data[age_col], name="Pre-populated",
                                           opacity=0.6, marker_color=PRIMARY, nbinsx=50))
            fig.add_trace(go.Histogram(x=hist_data["_Computed_Age_Days"], name="Computed",
                                       opacity=0.6, marker_color=ACCENT, nbinsx=50))
            fig.update_layout(barmode="overlay")
            fig = apply_style(fig, "Age Days Distribution", "Age Days", "Count")
            st.plotly_chart(fig, use_container_width=True)

    with col_right:
        st.markdown("### Bucket Distribution Comparison")
        if bucket_col and bucket_col in valid.columns:
            bc = pd.DataFrame({
                "Pre-populated": valid[bucket_col].value_counts(),
                "Computed":      valid["_Computed_Bucket"].value_counts(),
            }).reindex(BUCKET_ORDER).fillna(0).reset_index()
            bc.columns = ["Bucket", "Pre-populated", "Computed"]
            fig2 = go.Figure()
            fig2.add_trace(go.Bar(x=bc["Bucket"], y=bc["Pre-populated"],
                                  name="Pre-populated", marker_color=PRIMARY))
            fig2.add_trace(go.Bar(x=bc["Bucket"], y=bc["Computed"],
                                  name="Computed", marker_color=ACCENT))
            fig2.update_layout(barmode="group")
            fig2 = apply_style(fig2, "Bucket Distribution Comparison", "Bucket", "Count")
            st.plotly_chart(fig2, use_container_width=True)

    # Discrepancy records table
    st.markdown("### Discrepancy Records (up to 500 shown)")
    disc_mask = pd.Series(False, index=valid.index)
    if "_Age_Match" in valid.columns:    disc_mask |= ~valid["_Age_Match"]
    if "_Bucket_Match" in valid.columns: disc_mask |= ~valid["_Bucket_Match"]
    disc_df = valid[disc_mask]

    if len(disc_df):
        show_keys = ["Period","Team","Rec Name (as per Rec Cube)","Entity","Date","TRADE REF"]
        show_cols = [col_map[k] for k in show_keys if k in col_map and col_map[k] in disc_df.columns]
        for extra in [age_col, "_Computed_Age_Days", bucket_col, "_Computed_Bucket",
                      "_Age_Match", "_Bucket_Match"]:
            if extra and extra in disc_df.columns:
                show_cols.append(extra)
        disp = disc_df[show_cols].head(500).copy()
        st.dataframe(disp, height=380, use_container_width=True)
        st.download_button("📥 Download Discrepancy Report (CSV)",
                           disc_df.to_csv(index=False).encode("utf-8"),
                           file_name="ageing_discrepancy_report.csv", mime="text/csv")
    else:
        st.success("✅ No discrepancies found!")

    # Trend charts
    if "_Period_label" in df.columns:
        st.markdown("---")
        st.markdown("### Ageing Trends Over Time")
        trend = df[df["_Computed_Age_Days"].notna()]
        period_order = sorted(trend["_Period_label"].unique())

        col_t1, col_t2 = st.columns(2)
        with col_t1:
            age_tr = (trend.groupby("_Period_label")["_Computed_Age_Days"]
                      .agg(["mean","median"]).reindex(period_order).reset_index())
            fig3 = go.Figure()
            fig3.add_trace(go.Bar(x=age_tr["_Period_label"], y=age_tr["mean"],
                                  name="Mean Age Days", marker_color=PRIMARY, opacity=0.85))
            fig3.add_trace(go.Scatter(x=age_tr["_Period_label"], y=age_tr["median"],
                                      name="Median", mode="lines+markers",
                                      line=dict(color=ACCENT, width=2.5)))
            fig3 = apply_style(fig3, "Average Age Days Trend", "Period", "Days")
            st.plotly_chart(fig3, use_container_width=True)

        with col_t2:
            bp = (trend.groupby(["_Period_label","_Computed_Bucket"], observed=False)
                  .size().reset_index(name="Count"))
            fig4 = px.bar(bp, x="_Period_label", y="Count", color="_Computed_Bucket",
                          color_discrete_sequence=COLORS, barmode="stack",
                          category_orders={"_Computed_Bucket": BUCKET_ORDER})
            fig4 = apply_style(fig4, "Ageing Bucket Distribution Over Time", "Period", "Count")
            st.plotly_chart(fig4, use_container_width=True)

"""streamlit_app/tabs — one module per dashboard tab."""
from streamlit_app.tabs import (
    data_quality, ageing_validation, break_counts,
    break_amounts, drill_down, threshold_alerts, factor_analysis,
)

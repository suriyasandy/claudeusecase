"""Tab 3 — Trend Analysis: Break Counts."""
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st

from streamlit_app.utils.chart_style import apply_style, kpi_card, COLORS, PRIMARY, ACCENT
from streamlit_app.utils.formatters import fmt_number, safe_mom_pct
from core.constants import BUCKET_ORDER


def render(df: pd.DataFrame, col_map: dict):
    st.markdown("## 📊 Trend Analysis: Break Counts")
    period_col = col_map.get("Period")
    team_col   = col_map.get("Team")
    rec_col    = col_map.get("Rec Name (as per Rec Cube)")
    ac_col     = col_map.get("Asset Class")
    ts_col     = col_map.get("True/Systemic Breaks")
    bucket_col = col_map.get("Bucket")

    if not period_col or period_col not in df.columns:
        st.warning("Period column not found."); return

    periods_sorted = sorted(df[period_col].dropna().unique())
    total_breaks   = len(df)
    latest_period  = periods_sorted[-1] if periods_sorted else None
    prev_period    = periods_sorted[-2] if len(periods_sorted) >= 2 else None
    latest_count   = int(df[df[period_col] == latest_period].shape[0]) if latest_period else 0
    prev_count     = int(df[df[period_col] == prev_period].shape[0])   if prev_period else 0
    mom            = safe_mom_pct(latest_count, prev_count)
    unique_recs    = df[rec_col].nunique() if rec_col and rec_col in df.columns else "N/A"

    c1,c2,c3,c4 = st.columns(4)
    with c1: kpi_card(st, "Total Breaks", fmt_number(total_breaks))
    with c2: kpi_card(st, "Latest Period Count", fmt_number(latest_count),
                      f"{'+' if mom and mom>0 else ''}{mom}% MoM" if mom else None)
    with c3: kpi_card(st, "Avg Breaks/Period",
                      fmt_number(round(total_breaks/len(periods_sorted),0) if periods_sorted else 0))
    with c4: kpi_card(st, "Unique Recs with Breaks", str(unique_recs))

    st.markdown("---")
    if "_Period_label" not in df.columns:
        st.warning("_Period_label not computed."); return

    period_counts = df.groupby("_Period_label", observed=True).size().reset_index(name="Break Count")
    period_order  = sorted(period_counts["_Period_label"].unique())

    col_a, col_b = st.columns(2)
    with col_a:
        fig = go.Figure()
        fig.add_trace(go.Bar(x=period_counts["_Period_label"], y=period_counts["Break Count"],
                             name="Break Count", marker_color=PRIMARY, opacity=0.85))
        fig.add_trace(go.Scatter(x=period_counts["_Period_label"], y=period_counts["Break Count"],
                                 name="Trend", line=dict(color=ACCENT, width=2.5), mode="lines+markers"))
        fig = apply_style(fig, "Break Count Trend by Period", "Period", "Count")
        st.plotly_chart(fig, use_container_width=True)

    with col_b:
        if team_col and team_col in df.columns:
            team_period = df.groupby([team_col, "_Period_label"], observed=True).size().reset_index(name="Count")
            fig2 = px.bar(team_period, x="_Period_label", y="Count", color=team_col,
                          color_discrete_sequence=COLORS, barmode="group")
            fig2 = apply_style(fig2, "Break Count by Team Over Periods", "Period", "Count")
            st.plotly_chart(fig2, use_container_width=True)

    col_c, col_d = st.columns(2)
    with col_c:
        if ts_col and ts_col in df.columns:
            ts_period = df.groupby([ts_col, "_Period_label"], observed=True).size().reset_index(name="Count")
            fig3 = px.bar(ts_period, x="_Period_label", y="Count", color=ts_col,
                          color_discrete_sequence=[PRIMARY, ACCENT], barmode="group")
            fig3 = apply_style(fig3, "True vs Systemic Breaks Over Time", "Period", "Count")
            st.plotly_chart(fig3, use_container_width=True)

    with col_d:
        if team_col and team_col in df.columns:
            heat = df.groupby([team_col,"_Period_label"], observed=True).size().reset_index(name="Count")
            pivot = heat.pivot_table(index=team_col, columns="_Period_label", values="Count", fill_value=0)
            fig4 = px.imshow(pivot, color_continuous_scale=["#FFFFFF", PRIMARY],
                             aspect="auto", text_auto=True)
            fig4 = apply_style(fig4, "Heatmap: Team × Period", "", "", height=350)
            st.plotly_chart(fig4, use_container_width=True)

    col_e, col_f = st.columns(2)
    with col_e:
        if bucket_col and bucket_col in df.columns:
            bp = df.groupby([bucket_col,"_Period_label"], observed=True).size().reset_index(name="Count")
            bp[bucket_col] = pd.Categorical(bp[bucket_col], categories=BUCKET_ORDER, ordered=True)
            bp = bp.sort_values(bucket_col)
            fig5 = px.bar(bp, x="_Period_label", y="Count", color=bucket_col,
                          color_discrete_sequence=COLORS, barmode="stack")
            fig5 = apply_style(fig5, "Age Bucket Distribution Over Time", "Period", "Count")
            st.plotly_chart(fig5, use_container_width=True)

    with col_f:
        if rec_col and rec_col in df.columns:
            top10 = df[rec_col].value_counts().head(10).reset_index()
            top10.columns = ["Rec Name","Count"]
            top10 = top10.sort_values("Count", ascending=True)
            fig6 = px.bar(top10, x="Count", y="Rec Name", orientation="h",
                          color_discrete_sequence=[PRIMARY])
            fig6 = apply_style(fig6, "Top 10 Rec Names by Break Count", "Count", "")
            st.plotly_chart(fig6, use_container_width=True)

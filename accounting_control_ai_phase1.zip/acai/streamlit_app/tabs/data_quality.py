"""Tab 1 — Data Quality & Ingestion Scorecard."""
import numpy as np
import pandas as pd
import plotly.express as px
import streamlit as st

from streamlit_app.utils.chart_style import apply_style, kpi_card, PRIMARY, COLORS
from streamlit_app.utils.formatters import fmt_number

try:
    from st_aggrid import AgGrid, GridOptionsBuilder
    HAS_AGGRID = True
except ImportError:
    HAS_AGGRID = False


def _grid(df, height=300, key=None):
    if HAS_AGGRID and len(df):
        gb = GridOptionsBuilder.from_dataframe(df)
        gb.configure_pagination(paginationAutoPageSize=False, paginationPageSize=20)
        gb.configure_default_column(filterable=True, sortable=True, resizable=True)
        AgGrid(df, gridOptions=gb.build(), height=height, theme="streamlit", key=key)
    else:
        st.dataframe(df, height=height, use_container_width=True)


def render(result: dict):
    sc      = result["scorecard"]
    df      = result["df"]
    col_map = result["col_map"]
    meta    = result["metadata"]

    st.markdown("## 📋 Data Quality & Ingestion Scorecard")

    c1, c2, c3, c4, c5 = st.columns(5)
    with c1: kpi_card(st, "Total Records",     fmt_number(sc["total_records"]))
    with c2: kpi_card(st, "Completeness",      f"{sc['overall_completeness']}%")
    with c3: kpi_card(st, "Type Violations",   fmt_number(sc["total_type_violations"]))
    with c4: kpi_card(st, "For Del Filtered",  fmt_number(meta["filtered_for_del"]))
    with c5: kpi_card(st, "Surrogate Keys",    fmt_number(meta["surrogate_keys"]))

    st.markdown("---")
    col_left, col_right = st.columns(2)

    with col_left:
        st.markdown("### Column Completeness")
        cdata = pd.DataFrame(sc["column_completeness"]).sort_values("completeness_pct", ascending=True)
        fig = px.bar(cdata, x="completeness_pct", y="column", orientation="h",
                     color_discrete_sequence=[PRIMARY])
        fig = apply_style(fig, "Per-Column Completeness (%)", "Completeness %", "",
                          height=max(300, len(cdata) * 15))
        fig.update_layout(yaxis=dict(tickfont=dict(size=9)))
        st.plotly_chart(fig, use_container_width=True)

    with col_right:
        st.markdown("### Type Violation Details")
        if sc["type_violations"]:
            _grid(pd.DataFrame(sc["type_violations"]), height=200, key="tv_grid")
        else:
            st.success("✅ No type violations detected.")

        st.markdown("### Outlier Detection (IQR)")
        if sc["outliers"]:
            _grid(pd.DataFrame(sc["outliers"]), height=200, key="ol_grid")
        else:
            st.info("No significant outliers detected.")

    st.markdown("### Numeric Column Summary Statistics")
    ns = sc.get("numeric_summary", [])
    if ns:
        _grid(pd.DataFrame(ns), height=280, key="ns_grid")

    st.markdown("### Phase 2 Readiness Flags")
    flag_cols = [c for c in ["is_timing_candidate", "has_ssi_signal", "has_ca_signal"]
                 if c in df.columns]
    if flag_cols:
        n = len(df)
        flag_data = []
        labels = {"is_timing_candidate": "Timing Candidate (#1)",
                  "has_ssi_signal":      "SSI Signal (#2)",
                  "has_ca_signal":       "Corporate Action Signal (#6)"}
        for fc in flag_cols:
            cnt = int(df[fc].sum())
            flag_data.append({
                "Flag": labels.get(fc, fc),
                "Count": cnt,
                "Pct (%)": round(cnt / n * 100, 1),
                "Note": "Auto-classifiable in Phase 2 without LLM",
            })
        st.dataframe(pd.DataFrame(flag_data), use_container_width=True)
        pareto = sum(d["Count"] for d in flag_data[:2])
        st.info(f"Pareto coverage: **{round(pareto/n*100,1)}%** of breaks pre-flagged "
                f"for Timing + SSI auto-classification in Phase 2.")

    st.markdown("---")
    st.download_button("📥 Download Cleaned Dataset (CSV)",
                       df.to_csv(index=False).encode("utf-8"),
                       file_name="cleaned_data.csv", mime="text/csv")

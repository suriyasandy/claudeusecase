"""Tab 4 — Trend Analysis: Break Amounts."""
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st

from streamlit_app.utils.chart_style import apply_style, kpi_card, COLORS, PRIMARY, ACCENT
from streamlit_app.utils.formatters import fmt_short, safe_mom_pct


def render(df: pd.DataFrame, col_map: dict):
    st.markdown("## 💰 Trend Analysis: Break Amounts (GBP)")
    period_col = col_map.get("Period")
    team_col   = col_map.get("Team")
    rec_col    = col_map.get("Rec Name (as per Rec Cube)")
    ac_col     = col_map.get("Asset Class")
    abs_col    = col_map.get("ABS GBP")
    gbp_col    = col_map.get("BREAK AMOUNT GBP")
    amt_col    = (abs_col if abs_col and abs_col in df.columns else gbp_col)

    if not amt_col or amt_col not in df.columns:
        st.warning("Break Amount GBP / ABS GBP column not found."); return
    if not period_col or period_col not in df.columns:
        st.warning("Period column not found."); return
    if "_Period_label" not in df.columns:
        st.warning("_Period_label not computed."); return

    periods_sorted = sorted(df[period_col].dropna().unique())
    total_amount   = df[amt_col].sum()
    latest_period  = periods_sorted[-1] if periods_sorted else None
    prev_period    = periods_sorted[-2] if len(periods_sorted) >= 2 else None

    def _period_label(p):
        from core.ageing import period_to_datetime_scalar
        ts = period_to_datetime_scalar(p)
        return ts.strftime("%Y-%m") if ts is not None else str(p)

    latest_lbl = _period_label(latest_period) if latest_period else ""
    prev_lbl   = _period_label(prev_period)   if prev_period   else ""

    latest_amt = float(df[df["_Period_label"] == latest_lbl][amt_col].sum()) if latest_lbl else 0
    prev_amt   = float(df[df["_Period_label"] == prev_lbl][amt_col].sum())   if prev_lbl   else 0
    mom        = safe_mom_pct(latest_amt, prev_amt)

    c1,c2,c3,c4 = st.columns(4)
    with c1: kpi_card(st, "Total Break Amount", fmt_short(total_amount))
    with c2: kpi_card(st, "Latest Period Amount", fmt_short(latest_amt),
                      f"{'+' if mom and mom>0 else ''}{mom}% MoM" if mom else None)
    with c3: kpi_card(st, "Avg Amount/Period",
                      fmt_short(total_amount/len(periods_sorted) if periods_sorted else 0))
    with c4: kpi_card(st, "Max Single Break", fmt_short(df[amt_col].max()))

    st.markdown("---")
    period_amt = df.groupby("_Period_label", observed=True)[amt_col].sum().reset_index(name="Amount")
    period_order = sorted(period_amt["_Period_label"].unique())

    col_a, col_b = st.columns(2)
    with col_a:
        fig = go.Figure()
        fig.add_trace(go.Bar(x=period_amt["_Period_label"], y=period_amt["Amount"],
                             name="Amount", marker_color=PRIMARY, opacity=0.85))
        fig.add_trace(go.Scatter(x=period_amt["_Period_label"], y=period_amt["Amount"],
                                 name="Trend", line=dict(color=ACCENT, width=2.5), mode="lines+markers"))
        fig = apply_style(fig, "Break Amount (GBP) Trend by Period", "Period", "Amount (GBP)")
        st.plotly_chart(fig, use_container_width=True)

    with col_b:
        if team_col and team_col in df.columns:
            ta = df.groupby([team_col,"_Period_label"], observed=True)[amt_col].sum().reset_index(name="Amount")
            fig2 = px.bar(ta, x="_Period_label", y="Amount", color=team_col,
                          color_discrete_sequence=COLORS, barmode="group")
            fig2 = apply_style(fig2, "Break Amount by Team Over Periods", "Period", "Amount (GBP)")
            st.plotly_chart(fig2, use_container_width=True)

    col_c, col_d = st.columns(2)
    with col_c:
        log_scale = st.checkbox("Use log scale", value=True, key="amt_log")
        valid_amt = df[amt_col].dropna()
        if len(valid_amt):
            fig3 = px.histogram(valid_amt.to_frame(), x=amt_col, nbins=60,
                                color_discrete_sequence=[PRIMARY], log_y=log_scale)
            fig3 = apply_style(fig3, "Break Amount Distribution", "Amount (GBP)", "Frequency")
            st.plotly_chart(fig3, use_container_width=True)

    with col_d:
        if ac_col and ac_col in df.columns:
            ac_amt = df.groupby(ac_col, observed=True)[amt_col].sum().abs().reset_index(name="Amount")
            fig4 = px.bar(ac_amt.sort_values("Amount", ascending=True),
                          x="Amount", y=ac_col, orientation="h",
                          color_discrete_sequence=[PRIMARY])
            fig4 = apply_style(fig4, "Break Amount by Asset Class", "Amount (GBP)", "")
            st.plotly_chart(fig4, use_container_width=True)

    # Top 10 largest breaks
    st.markdown("### Top 10 Largest Individual Breaks")
    top_breaks = df.nlargest(10, amt_col)
    show_keys  = ["Period","Team","Rec Name (as per Rec Cube)","Entity","TRADE REF"]
    show_cols  = [col_map[k] for k in show_keys if k in col_map and col_map[k] in top_breaks.columns]
    show_cols.append(amt_col)
    st.dataframe(top_breaks[show_cols].reset_index(drop=True), use_container_width=True)

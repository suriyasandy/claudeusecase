"""Tab 6 — Threshold Alerts (Median + MAD)."""
import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st

from streamlit_app.utils.chart_style import apply_style, kpi_card, COLORS, PRIMARY, ACCENT, MUTED
from streamlit_app.utils.formatters import fmt_number, fmt_short
from core.ageing import period_to_datetime_scalar


def _classify(vals, mad_k, watch_k):
    med = float(np.median(vals))
    mad = float(np.median(np.abs(vals - med)))
    if mad == 0:
        mad = max(med * 0.1, 1.0)
    latest     = float(vals.iloc[-1]) if hasattr(vals, "iloc") else float(vals[-1])
    upper_mat  = med + mad_k   * mad
    upper_wch  = med + watch_k * mad
    cls = ("Material"  if latest > upper_mat  else
           "Watchlist" if latest > upper_wch  else "Normal")
    dev = round((latest - med) / mad * 100, 1) if mad > 0 else 0.0
    return dict(median=round(med, 1), mad=round(mad, 2),
                upper_mat=round(upper_mat, 1), upper_wch=round(upper_wch, 1),
                latest=round(latest, 2), classification=cls, deviation_pct=dev)


def render(df: pd.DataFrame, col_map: dict):
    st.markdown("## 🚨 Threshold Alerts")

    period_col = col_map.get("Period")
    team_col   = col_map.get("Team")
    rec_col    = col_map.get("Rec Name (as per Rec Cube)")
    entity_col = col_map.get("Entity")
    ac_col     = col_map.get("Asset Class")
    abs_col    = col_map.get("ABS GBP")
    gbp_col    = col_map.get("BREAK AMOUNT GBP")
    amt_col    = abs_col if abs_col and abs_col in df.columns else gbp_col
    has_amt    = bool(amt_col and amt_col in df.columns)

    if not period_col or period_col not in df.columns:
        st.warning("Period column not found."); return

    # ── Config ────────────────────────────────────────────────────────────────
    seg_opts = {k: v for k, v in {
        "Team": team_col, "Rec Name": rec_col,
        "Entity": entity_col, "Asset Class": ac_col,
    }.items() if v and v in df.columns}

    if not seg_opts:
        st.warning("No dimension columns available for segmentation."); return

    col_s1, col_s2, col_s3, col_s4 = st.columns(4)
    with col_s1:
        seg_choice = st.selectbox("Segment Dimension", list(seg_opts.keys()), key="thr_seg")
    with col_s2:
        metric_opts = ["Break Count", "Break Amount", "Both"] if has_amt else ["Break Count"]
        metric      = st.radio("Metric", metric_opts, horizontal=True, key="thr_metric")
    with col_s3:
        mad_k   = st.slider("MAD multiplier (k)",   1.0, 5.0, 3.0, 0.5, key="thr_k")
    with col_s4:
        watch_k = st.slider("Watchlist multiplier", 1.0, 4.0, 2.0, 0.5, key="thr_wk")

    seg_col = seg_opts[seg_choice]

    # ── Compute per-segment stats ─────────────────────────────────────────────
    sp_count = (df.groupby([seg_col, period_col], observed=True)
                .size().reset_index(name="Break Count"))
    if has_amt:
        sp_amt = (df.groupby([seg_col, period_col], observed=True)[amt_col]
                  .sum().abs().reset_index(name="Break Amount"))
        sp = sp_count.merge(sp_amt, on=[seg_col, period_col], how="left")
    else:
        sp = sp_count.copy()
        sp["Break Amount"] = 0.0

    rows = []
    for seg_val, grp in sp.groupby(seg_col, observed=True):
        grp = grp.sort_values(period_col)
        n   = len(grp)
        if n < 2:
            rows.append({"Segment": seg_val, "Classification": "Insufficient Data",
                         "Periods": n, "Latest Count": int(grp["Break Count"].iloc[-1]) if n else 0,
                         "Latest Amount": float(grp["Break Amount"].iloc[-1]) if n else 0,
                         "Median Count": None, "Deviation %": None})
            continue
        cs = _classify(grp["Break Count"], mad_k, watch_k)
        as_ = _classify(grp["Break Amount"], mad_k, watch_k)
        cls_rank = {"Material": 2, "Watchlist": 1, "Normal": 0}
        combined = (cs["classification"]
                    if metric == "Break Count" else
                    as_["classification"]
                    if metric == "Break Amount" else
                    cs["classification"] if cls_rank[cs["classification"]] >= cls_rank[as_["classification"]]
                    else as_["classification"])
        dev = (cs["deviation_pct"] if metric == "Break Count" else
               as_["deviation_pct"] if metric == "Break Amount" else
               max(cs["deviation_pct"], as_["deviation_pct"]))
        rows.append({
            "Segment":         str(seg_val),
            "Latest Count":    cs["latest"],
            "Median Count":    cs["median"],
            "MAD Count":       cs["mad"],
            "Upper Count Thr": cs["upper_mat"],
            "Count Cls":       cs["classification"],
            "Latest Amount":   as_["latest"],
            "Median Amount":   as_["median"],
            "MAD Amount":      as_["mad"],
            "Upper Amt Thr":   as_["upper_mat"],
            "Amount Cls":      as_["classification"],
            "Classification":  combined,
            "Deviation %":     dev,
            "Periods":         n,
        })

    alert_df = pd.DataFrame(rows)

    # ── KPIs ──────────────────────────────────────────────────────────────────
    mat  = int((alert_df["Classification"] == "Material").sum())
    wch  = int((alert_df["Classification"] == "Watchlist").sum())
    nor  = int((alert_df["Classification"] == "Normal").sum())
    ins  = int((alert_df["Classification"] == "Insufficient Data").sum())

    c1,c2,c3,c4 = st.columns(4)
    with c1: kpi_card(st, "Total Segments",  str(len(alert_df)))
    with c2: kpi_card(st, "Material Alerts", str(mat))
    with c3: kpi_card(st, "Watchlist",       str(wch))
    with c4: kpi_card(st, "Normal",          str(nor))

    st.markdown("---")

    # ── Alert table ───────────────────────────────────────────────────────────
    st.markdown("### Alert Summary Table")
    disp = alert_df.sort_values("Deviation %", ascending=False, na_position="last").reset_index(drop=True)

    def _color_row(row):
        c = row["Classification"]
        bg = ("#FDECEA" if c == "Material" else
              "#FFF8E1" if c == "Watchlist" else
              "#E8F5E9" if c == "Normal" else "#F5F5F5")
        return [f"background-color:{bg}"] * len(row)

    cols_show = ["Segment","Latest Count","Median Count","Upper Count Thr",
                 "Latest Amount","Upper Amt Thr","Classification","Deviation %","Periods"]
    cols_show = [c for c in cols_show if c in disp.columns]
    styled = disp[cols_show].style.apply(_color_row, axis=1)
    st.dataframe(styled, height=400, use_container_width=True)

    st.markdown("---")
    col_a, col_b = st.columns(2)

    # Classification bar
    with col_a:
        cls_counts = alert_df["Classification"].value_counts().reset_index()
        cls_counts.columns = ["Classification", "Count"]
        cls_colors = {"Material": ACCENT, "Watchlist": "#FFC553",
                      "Normal": PRIMARY, "Insufficient Data": MUTED}
        fig = go.Figure(go.Bar(
            x=cls_counts["Classification"], y=cls_counts["Count"],
            marker_color=[cls_colors.get(c, MUTED) for c in cls_counts["Classification"]],
            text=cls_counts["Count"], textposition="auto",
        ))
        fig = apply_style(fig, "Segments by Classification", "Classification", "Count")
        st.plotly_chart(fig, use_container_width=True)

    # Top 10 deviated
    with col_b:
        top_dev = alert_df[alert_df["Deviation %"].notna()].nlargest(10, "Deviation %")
        if len(top_dev):
            top_dev_s = top_dev.sort_values("Deviation %", ascending=True)
            colors_bar = [ACCENT if c=="Material" else "#FFC553" if c=="Watchlist" else PRIMARY
                          for c in top_dev_s["Classification"]]
            fig2 = go.Figure(go.Bar(
                x=top_dev_s["Deviation %"], y=top_dev_s["Segment"],
                orientation="h", marker_color=colors_bar,
                text=top_dev_s["Deviation %"].apply(lambda x: f"{x:.1f}%"),
                textposition="auto",
            ))
            fig2 = apply_style(fig2, "Top 10 Most Deviated Segments", "Deviation %", "",
                               height=max(300, len(top_dev)*35))
            st.plotly_chart(fig2, use_container_width=True)

    # Time-series with threshold bands
    st.markdown("### Segment Time Series with Threshold Bands")
    selectable = alert_df[alert_df["Classification"].isin(["Material","Watchlist","Normal"])]["Segment"].tolist()
    if selectable:
        default_mat = alert_df[alert_df["Classification"]=="Material"]["Segment"].tolist()
        default_idx = selectable.index(default_mat[0]) if default_mat and default_mat[0] in selectable else 0
        sel_seg = st.selectbox("Select segment", selectable, index=default_idx, key="thr_ts")
        seg_ts  = sp[sp[seg_col].astype(str) == sel_seg].sort_values(period_col)
        seg_row = alert_df[alert_df["Segment"] == sel_seg]
        if len(seg_row) and len(seg_ts) >= 2:
            sr        = seg_row.iloc[0]
            ts_y      = "Break Amount" if metric == "Break Amount" else "Break Count"
            ts_med    = sr.get("Median Amount" if metric=="Break Amount" else "Median Count", 0) or 0
            ts_mad    = sr.get("MAD Amount"    if metric=="Break Amount" else "MAD Count",    1) or 1
            upper_mat = ts_med + mad_k   * ts_mad
            upper_wch = ts_med + watch_k * ts_mad

            period_labels = seg_ts[period_col].apply(
                lambda x: period_to_datetime_scalar(x).strftime("%Y-%m")
                if period_to_datetime_scalar(x) is not None else str(x)
            )
            y_vals = seg_ts[ts_y]
            y_max  = max(float(y_vals.max()) * 1.2, upper_mat * 1.3)

            fig3 = go.Figure()
            fig3.add_hrect(y0=upper_mat, y1=y_max,
                           fillcolor="rgba(168,75,47,0.10)", line_width=0,
                           annotation_text="Material Zone", annotation_position="top left")
            fig3.add_hrect(y0=upper_wch, y1=upper_mat,
                           fillcolor="rgba(255,197,83,0.15)", line_width=0,
                           annotation_text="Watchlist Zone", annotation_position="top left")
            fig3.add_hline(y=ts_med,    line_dash="dash", line_color=MUTED,  line_width=1, annotation_text="Median")
            fig3.add_hline(y=upper_mat, line_dash="dot",  line_color=ACCENT, line_width=1)
            fig3.add_hline(y=upper_wch, line_dash="dot",  line_color="#FFC553", line_width=1)
            fig3.add_trace(go.Scatter(x=period_labels, y=y_vals,
                                      mode="lines+markers", name=ts_y,
                                      line=dict(color=PRIMARY, width=2.5),
                                      marker=dict(size=8)))
            fig3 = apply_style(fig3, f"Time Series: {sel_seg}", "Period", ts_y)
            st.plotly_chart(fig3, use_container_width=True)

    st.markdown("---")
    st.download_button("📥 Download Alert Report (CSV)",
                       alert_df.to_csv(index=False).encode("utf-8"),
                       file_name="threshold_alerts.csv", mime="text/csv")

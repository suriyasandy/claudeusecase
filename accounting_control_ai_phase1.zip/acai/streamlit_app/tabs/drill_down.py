"""Tab 5 — Detailed Drill-Down."""
import numpy as np
import pandas as pd
import plotly.graph_objects as go
import streamlit as st

from streamlit_app.utils.chart_style import apply_style, kpi_card, PRIMARY, ACCENT
from streamlit_app.utils.formatters import fmt_number, fmt_short


def render(df: pd.DataFrame, col_map: dict):
    st.markdown("## 🔍 Detailed Drill-Down Analysis")
    period_col  = col_map.get("Period")
    team_col    = col_map.get("Team")
    rec_col     = col_map.get("Rec Name (as per Rec Cube)")
    entity_col  = col_map.get("Entity")
    product_col = col_map.get("Products Reconciled")
    abs_col     = col_map.get("ABS GBP")
    gbp_col     = col_map.get("BREAK AMOUNT GBP")
    amt_col     = abs_col if abs_col and abs_col in df.columns else gbp_col

    c1,c2,c3,c4 = st.columns(4)
    with c1:
        teams = ["All"] + sorted(df[team_col].dropna().unique().tolist()) if team_col and team_col in df.columns else ["All"]
        sel_team = st.selectbox("Team", teams, key="dd_team")
    filtered = df if sel_team == "All" else df[df[team_col] == sel_team]

    with c2:
        recs = ["All"] + sorted(filtered[rec_col].dropna().unique().tolist()) if rec_col and rec_col in filtered.columns else ["All"]
        sel_rec = st.selectbox("Rec Name", recs, key="dd_rec")
    if sel_rec != "All" and rec_col: filtered = filtered[filtered[rec_col] == sel_rec]

    with c3:
        entities = ["All"] + sorted(filtered[entity_col].dropna().unique().tolist()) if entity_col and entity_col in filtered.columns else ["All"]
        sel_entity = st.selectbox("Entity", entities, key="dd_entity")
    if sel_entity != "All" and entity_col: filtered = filtered[filtered[entity_col] == sel_entity]

    with c4:
        products = ["All"] + sorted(filtered[product_col].dropna().unique().tolist()) if product_col and product_col in filtered.columns else ["All"]
        sel_product = st.selectbox("Product", products, key="dd_product")
    if sel_product != "All" and product_col: filtered = filtered[filtered[product_col] == sel_product]

    st.markdown("---")
    if len(filtered) == 0:
        st.info("No records match the selected filters."); return

    k1,k2,k3,k4 = st.columns(4)
    with k1: kpi_card(st, "Filtered Records", fmt_number(len(filtered)))
    with k2:
        amt_total = filtered[amt_col].sum() if amt_col and amt_col in filtered.columns else 0
        kpi_card(st, "Total Amount GBP", fmt_short(amt_total))
    with k3:
        kpi_card(st, "Periods",
                 str(filtered[period_col].nunique()) if period_col and period_col in filtered.columns else "N/A")
    with k4:
        kpi_card(st, "Unique Recs",
                 str(filtered[rec_col].nunique()) if rec_col and rec_col in filtered.columns else "N/A")

    st.markdown("---")
    if "_Period_label" in filtered.columns:
        col_l, col_r = st.columns(2)
        cnt_trend = filtered.groupby("_Period_label", observed=True).size().reset_index(name="Break Count")
        with col_l:
            fig = go.Figure()
            fig.add_trace(go.Bar(x=cnt_trend["_Period_label"], y=cnt_trend["Break Count"],
                                 marker_color=PRIMARY, opacity=0.85, name="Count"))
            fig.add_trace(go.Scatter(x=cnt_trend["_Period_label"], y=cnt_trend["Break Count"],
                                     line=dict(color=ACCENT, width=2.5), mode="lines+markers", name="Trend"))
            fig = apply_style(fig, "Break Count Trend (Filtered)", "Period", "Count")
            st.plotly_chart(fig, use_container_width=True)

        with col_r:
            if amt_col and amt_col in filtered.columns:
                amt_trend = filtered.groupby("_Period_label", observed=True)[amt_col].sum().reset_index(name="Amount")
                fig2 = go.Figure()
                fig2.add_trace(go.Bar(x=amt_trend["_Period_label"], y=amt_trend["Amount"],
                                      marker_color=PRIMARY, opacity=0.85, name="Amount"))
                fig2.add_trace(go.Scatter(x=amt_trend["_Period_label"], y=amt_trend["Amount"],
                                          line=dict(color=ACCENT, width=2.5), mode="lines+markers"))
                fig2 = apply_style(fig2, "Break Amount Trend (Filtered)", "Period", "Amount (GBP)")
                st.plotly_chart(fig2, use_container_width=True)

    st.markdown("### Full Data (Filtered — up to 1,000 rows)")
    display_keys = ["Period","Team","Rec Name (as per Rec Cube)","Entity","Products Reconciled",
                    "Type of break","TRADE REF","BREAK AMOUNT GBP","ABS GBP","Age Days","Bucket",
                    "True/Systemic Breaks","Comments","is_timing_candidate","has_ssi_signal","has_ca_signal"]
    show_cols = []
    for k in display_keys:
        actual = col_map.get(k, k)
        if actual in filtered.columns: show_cols.append(actual)
        elif k in filtered.columns: show_cols.append(k)
    if show_cols:
        st.dataframe(filtered[show_cols].head(1000).reset_index(drop=True),
                     height=420, use_container_width=True)
    st.download_button("📥 Download Drill-Down Data (CSV)",
                       filtered.to_csv(index=False).encode("utf-8"),
                       file_name="drill_down_data.csv", mime="text/csv")

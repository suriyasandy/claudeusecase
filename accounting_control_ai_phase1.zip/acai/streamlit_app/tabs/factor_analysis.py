"""Tab 7 — Factor Influence Analysis."""
import re
import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st

from streamlit_app.utils.chart_style import apply_style, kpi_card, COLORS, PRIMARY, ACCENT, DARK, MUTED
from streamlit_app.utils.formatters import fmt_number, fmt_short, safe_mom_pct
from core.ageing import period_to_datetime_scalar


def _fmt_period(p):
    ts = period_to_datetime_scalar(p)
    return ts.strftime("%Y-%m") if ts is not None else str(p)


def render(df: pd.DataFrame, col_map: dict):
    st.markdown("## 📈 Factor Influence Analysis")

    period_col = col_map.get("Period")
    team_col   = col_map.get("Team")
    rec_col    = col_map.get("Rec Name (as per Rec Cube)")
    entity_col = col_map.get("Entity")
    ac_col     = col_map.get("Asset Class")
    tob_col    = col_map.get("Type of break")
    ts_col     = col_map.get("True/Systemic Breaks")
    abs_col    = col_map.get("ABS GBP")
    gbp_col    = col_map.get("BREAK AMOUNT GBP")
    amt_col    = abs_col if abs_col and abs_col in df.columns else gbp_col

    if not period_col or period_col not in df.columns:
        st.warning("Period column not found."); return

    periods_sorted = sorted(df[period_col].dropna().unique())
    if len(periods_sorted) < 2:
        st.warning("Need at least 2 periods for factor analysis."); return

    col_p1, col_p2, col_p3 = st.columns(3)
    with col_p1:
        prev_period = st.selectbox(
            "Previous Period", periods_sorted[:-1],
            index=len(periods_sorted)-2,
            format_func=_fmt_period, key="fa_prev"
        )
    with col_p2:
        curr_period = st.selectbox(
            "Current Period", periods_sorted[1:],
            index=len(periods_sorted[1:])-1,
            format_func=_fmt_period, key="fa_curr"
        )
    with col_p3:
        dim_opts = {k: v for k, v in {
            "Team": team_col, "Rec Name": rec_col,
            "Entity": entity_col, "Asset Class": ac_col,
            "Type of Break": tob_col, "True/Systemic": ts_col,
        }.items() if v and v in df.columns}
        sel_dim = st.selectbox("Decompose by", list(dim_opts.keys()), key="fa_dim")

    dim_col    = dim_opts[sel_dim]
    df_prev    = df[df[period_col] == prev_period]
    df_curr    = df[df[period_col] == curr_period]
    prev_label = _fmt_period(prev_period)
    curr_label = _fmt_period(curr_period)

    total_prev = len(df_prev)
    total_curr = len(df_curr)
    net_change = total_curr - total_prev
    net_pct    = safe_mom_pct(total_curr, total_prev)

    prev_amt   = float(df_prev[amt_col].sum()) if amt_col and amt_col in df_prev.columns else 0
    curr_amt   = float(df_curr[amt_col].sum()) if amt_col and amt_col in df_curr.columns else 0
    amt_change = curr_amt - prev_amt
    amt_pct    = safe_mom_pct(curr_amt, prev_amt) if prev_amt != 0 else None

    # Per-dimension breakdown
    def _agg(frame):
        cnt = frame.groupby(dim_col, observed=True).size().rename("count")
        if amt_col and amt_col in frame.columns:
            amt = frame.groupby(dim_col, observed=True)[amt_col].sum().abs().rename("amount")
            return pd.concat([cnt, amt], axis=1)
        return cnt.to_frame().assign(amount=0.0)

    prev_agg = _agg(df_prev).add_prefix("prev_")
    curr_agg = _agg(df_curr).add_prefix("curr_")
    factor_df = prev_agg.join(curr_agg, how="outer").fillna(0).reset_index()
    factor_df["Count Change"]    = factor_df["curr_count"]  - factor_df["prev_count"]
    factor_df["Amount Change"]   = factor_df["curr_amount"] - factor_df["prev_amount"]
    factor_df["Count Change %"]  = np.where(
        factor_df["prev_count"] > 0,
        (factor_df["Count Change"] / factor_df["prev_count"] * 100).round(1),
        np.where(factor_df["curr_count"] > 0, 100.0, 0.0)
    )
    factor_df = factor_df.sort_values("Count Change", ascending=False)

    # ── Plain-English Summary ─────────────────────────────────────────────────
    direction = "increased" if net_change >= 0 else "decreased"
    summary   = [f"Break count **{direction} by {abs(net_change):,}** ({net_pct:+.1f}%) "
                 f"from **{prev_label}** to **{curr_label}**."]
    if len(factor_df):
        top_inc = factor_df.loc[factor_df["Count Change"].idxmax()]
        top_dec = factor_df.loc[factor_df["Count Change"].idxmin()]
        if top_inc["Count Change"] > 0:
            summary.append(f"Largest increase: **{top_inc[dim_col]}** (+{int(top_inc['Count Change']):,}).")
        if top_dec["Count Change"] < 0:
            summary.append(f"Largest decrease: **{top_dec[dim_col]}** ({int(top_dec['Count Change']):,}).")
        if amt_col and amt_pct is not None:
            summary.append(f"Total amount {'increased' if amt_change>=0 else 'decreased'} "
                           f"by **{fmt_short(abs(amt_change))}** ({amt_pct:+.1f}%).")
        top3_chg = factor_df.nlargest(3, "Count Change")["Count Change"].sum()
        if net_change != 0:
            conc = round(top3_chg / net_change * 100, 1)
            if abs(conc) > 50:
                names = ", ".join(factor_df.nlargest(3, "Count Change")[dim_col].astype(str).tolist())
                summary.append(f"Top 3 segments ({names}) account for **{abs(conc):.0f}%** of the net change.")

    summary_html = re.sub(r'\*\*(.+?)\*\*', r'<strong>\1</strong>', " ".join(summary))
    st.markdown(
        f'<div style="background:#E6F4F1;border-left:4px solid {PRIMARY};'
        f'padding:12px 16px;border-radius:4px;margin-bottom:16px;color:#1B474D">'
        f'{summary_html}</div>', unsafe_allow_html=True
    )

    # ── KPIs ──────────────────────────────────────────────────────────────────
    c1,c2,c3,c4 = st.columns(4)
    with c1: kpi_card(st, f"Count ({prev_label})", fmt_number(total_prev))
    with c2: kpi_card(st, f"Count ({curr_label})", fmt_number(total_curr),
                      f"{'+' if net_change>=0 else ''}{net_change:,} ({net_pct:+.1f}%)" if net_pct else None)
    with c3: kpi_card(st, f"Amount ({prev_label})", fmt_short(prev_amt))
    with c4: kpi_card(st, f"Amount ({curr_label})", fmt_short(curr_amt),
                      f"{fmt_short(amt_change)} ({amt_pct:+.1f}%)" if amt_pct else None)

    st.markdown("---")
    col_a, col_b = st.columns(2)

    # Waterfall
    with col_a:
        wf = factor_df.sort_values("Count Change", ascending=False)
        measures = ["relative"] * len(wf) + ["total"]
        x_labels = wf[dim_col].astype(str).tolist() + ["Net Change"]
        y_values = wf["Count Change"].tolist() + [0]
        fig = go.Figure(go.Waterfall(
            x=x_labels, y=y_values, measure=measures,
            increasing=dict(marker_color=ACCENT),
            decreasing=dict(marker_color=PRIMARY),
            totals=dict(marker_color=DARK),
            connector=dict(line=dict(color=MUTED, width=1)),
            text=[f"{v:+,.0f}" for v in wf["Count Change"]] + [f"{net_change:+,.0f}"],
            textposition="outside",
        ))
        fig = apply_style(fig, f"Break Count Change by {sel_dim}", sel_dim, "Count Change", height=440)
        fig.update_xaxes(tickangle=45)
        st.plotly_chart(fig, use_container_width=True)

    # Side-by-side bar
    with col_b:
        bar_df = factor_df.sort_values("curr_count", ascending=True).tail(15)
        fig2 = go.Figure()
        fig2.add_trace(go.Bar(y=bar_df[dim_col].astype(str), x=bar_df["prev_count"],
                              name=prev_label, orientation="h", marker_color=PRIMARY, opacity=0.75))
        fig2.add_trace(go.Bar(y=bar_df[dim_col].astype(str), x=bar_df["curr_count"],
                              name=curr_label, orientation="h", marker_color=ACCENT, opacity=0.75))
        fig2.update_layout(barmode="group")
        fig2 = apply_style(fig2, f"{prev_label} vs {curr_label} by {sel_dim}",
                           "Count", "", height=max(350, len(bar_df)*30))
        st.plotly_chart(fig2, use_container_width=True)

    col_c, col_d = st.columns(2)

    # Top movers cards
    with col_c:
        st.markdown("### Top Movers")
        top_inc = factor_df[factor_df["Count Change"] > 0].nlargest(5, "Count Change")
        top_dec = factor_df[factor_df["Count Change"] < 0].nsmallest(5, "Count Change")
        mc1, mc2 = st.columns(2)
        with mc1:
            st.markdown(f'<p style="color:{ACCENT};font-weight:bold">Top Increases</p>',
                        unsafe_allow_html=True)
            for _, r in top_inc.iterrows():
                st.markdown(
                    f'<div style="padding:4px 8px;margin:2px 0;background:#FDECEA;border-radius:4px">'
                    f'<b>{r[dim_col]}</b>: +{int(r["Count Change"]):,} ({r["Count Change %"]:+.1f}%)</div>',
                    unsafe_allow_html=True)
            if top_inc.empty: st.caption("No increases")
        with mc2:
            st.markdown(f'<p style="color:{PRIMARY};font-weight:bold">Top Decreases</p>',
                        unsafe_allow_html=True)
            for _, r in top_dec.iterrows():
                st.markdown(
                    f'<div style="padding:4px 8px;margin:2px 0;background:#E6F4F1;border-radius:4px">'
                    f'<b>{r[dim_col]}</b>: {int(r["Count Change"]):,} ({r["Count Change %"]:+.1f}%)</div>',
                    unsafe_allow_html=True)
            if top_dec.empty: st.caption("No decreases")

    # Pareto chart
    with col_d:
        pareto = factor_df[[dim_col, "Count Change"]].copy()
        pareto["Abs Change"] = pareto["Count Change"].abs()
        pareto = pareto.sort_values("Abs Change", ascending=False)
        total_abs = pareto["Abs Change"].sum()
        pareto["Cumulative %"] = (pareto["Abs Change"].cumsum() / total_abs * 100).round(1) if total_abs > 0 else 0

        fig3 = go.Figure()
        fig3.add_trace(go.Bar(x=pareto[dim_col].astype(str), y=pareto["Abs Change"],
                              name="Abs Change", marker_color=PRIMARY, opacity=0.85))
        fig3.add_trace(go.Scatter(x=pareto[dim_col].astype(str), y=pareto["Cumulative %"],
                                  name="Cumulative %", yaxis="y2",
                                  line=dict(color=ACCENT, width=2.5), mode="lines+markers"))
        fig3.update_layout(
            yaxis2=dict(title="Cumulative %", overlaying="y", side="right", range=[0, 110]),
            showlegend=False,
        )
        fig3 = apply_style(fig3, f"Pareto: Contribution by {sel_dim}", sel_dim,
                           "Abs Count Change", height=400)
        fig3.update_xaxes(tickangle=45)
        st.plotly_chart(fig3, use_container_width=True)

    # Detail table
    with st.expander("Dimension Breakdown Table", expanded=False):
        rename = {dim_col: sel_dim,
                  "prev_count": f"Count ({prev_label})", "curr_count": f"Count ({curr_label})",
                  "prev_amount": f"Amount ({prev_label})", "curr_amount": f"Amount ({curr_label})"}
        st.dataframe(factor_df.rename(columns=rename).reset_index(drop=True),
                     use_container_width=True)

    st.markdown("---")
    st.download_button("📥 Download Factor Analysis (CSV)",
                       factor_df.to_csv(index=False).encode("utf-8"),
                       file_name="factor_analysis.csv", mime="text/csv")

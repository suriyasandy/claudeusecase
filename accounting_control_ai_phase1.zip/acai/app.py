"""
app.py — Flask application factory.
Dash executive dashboard is mounted on the same Flask process at /dashboard/
Streamlit analyst app runs as a separate StatPy service (streamlit_app/app.py)
"""
import logging
import os

from flask import Flask, jsonify, send_from_directory
from flask_cors import CORS
from flask_caching import Cache

from config import get_config

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(name)s  %(message)s",
)
log = logging.getLogger(__name__)

cache_ext = Cache()


def create_app(config_class=None) -> Flask:
    app = Flask(__name__, static_folder="static")

    # ── Config ────────────────────────────────────────────────────────────────
    cfg = config_class or get_config()
    app.config.from_object(cfg)

    # ── Extensions ───────────────────────────────────────────────────────────
    CORS(app, resources={r"/api/*": {"origins": "*"}})
    cache_ext.init_app(app)

    # Ensure data dirs exist
    os.makedirs(app.config.get("UPLOAD_DIR", "data/uploads"), exist_ok=True)
    os.makedirs(app.config.get("CACHE_DIR",  "data/cache"),   exist_ok=True)

    # ── Register Flask REST blueprints ────────────────────────────────────────
    from api.data      import data_bp
    from api.quality   import quality_bp
    from api.ageing    import ageing_bp
    from api.analytics import analytics_bp

    app.register_blueprint(data_bp,      url_prefix="/api/data")
    app.register_blueprint(quality_bp,   url_prefix="/api/quality")
    app.register_blueprint(ageing_bp,    url_prefix="/api/ageing")
    app.register_blueprint(analytics_bp, url_prefix="/api/analytics")

    # ── Mount Dash dashboard on Flask ────────────────────────────────────────
    from dashboard import create_dash_app
    create_dash_app(app)

    # ── Health check ─────────────────────────────────────────────────────────
    @app.route("/health")
    def health():
        return jsonify({"status": "ok", "service": "accounting-control-ai-phase1"})

    # ── React static build (optional) ────────────────────────────────────────
    @app.route("/", defaults={"path": ""})
    @app.route("/<path:path>")
    def serve_react(path):
        static_dir = app.static_folder
        if path and os.path.exists(os.path.join(static_dir, path)):
            return send_from_directory(static_dir, path)
        index = os.path.join(static_dir, "index.html")
        if os.path.exists(index):
            return send_from_directory(static_dir, "index.html")
        return jsonify({"message": "Accounting Control AI — Phase 1 API", "docs": "/dashboard/"}), 200

    log.info("Flask app created  env=%s", cfg.__name__ if hasattr(cfg, "__name__") else cfg)
    return app


if __name__ == "__main__":
    application = create_app()
    port = int(os.environ.get("PORT", 8050))
    application.run(host="0.0.0.0", port=port, debug=False)

# Accounting Control AI Platform — Phase 1

> **621,804 break records · 41 columns · TCFC Business · OMRC AI/ML Team**

## Architecture

```
StatPy Project
├── Flask API  (port 8050)         → /api/*  REST endpoints
│   └── Dash Dashboard             → /dashboard/  executive UI
└── Streamlit App (port 8501)      → analyst deep-dive UI
```

## Quick Start

```bash
# 1. Clone and install
pip install -r requirements.txt

# 2. Configure environment
cp .env.example .env
# Edit .env — set SECRET_KEY at minimum

# 3. Create data directories
mkdir -p data/uploads data/cache

# 4. Run Flask + Dash (terminal 1)
python app.py

# 5. Run Streamlit (terminal 2)
streamlit run streamlit_app/app.py --server.port 8501
```

## Endpoints

| Method | Path | Description |
|--------|------|-------------|
| POST | `/api/data/upload` | Upload XLSX/CSV, run pipeline |
| GET | `/api/data/schema/<file_id>` | Column mapping result |
| GET | `/api/quality/scorecard/<file_id>` | Full data quality scorecard |
| GET | `/api/quality/column-completeness/<file_id>` | Per-column completeness |
| GET | `/api/quality/flags-summary/<file_id>` | Phase 2 pre-computed flags |
| GET | `/api/ageing/validation/<file_id>` | Ageing validation KPIs |
| GET | `/api/ageing/discrepancies/<file_id>` | Paginated discrepancy records |
| GET | `/api/analytics/trends/<file_id>` | Break count/amount by period |
| GET | `/api/analytics/threshold-alerts/<file_id>` | MAD alerting per segment |
| GET | `/api/analytics/factor-analysis/<file_id>` | Period-over-period decomposition |
| GET | `/api/analytics/drill-down/<file_id>` | Filtered + paginated records |
| GET | `/api/analytics/filter-options/<file_id>` | Sidebar filter choices |

## Dashboard Tabs (both Dash and Streamlit)

| # | Tab | What it shows |
|---|-----|---------------|
| 1 | Data Quality | Completeness, type violations, outliers, Phase 2 flags |
| 2 | Ageing Validation | Computed vs pre-populated Age Days & Bucket discrepancies |
| 3 | Break Counts | Trend by period, team, rec, asset class, true/systemic |
| 4 | Break Amounts | ABS GBP trend, distribution, top 10 largest breaks |
| 5 | Drill-Down | Hierarchical filter to individual Trade Ref level |
| 6 | Threshold Alerts | Median+MAD Material/Watchlist/Normal classification |
| 7 | Factor Analysis | Period-over-period waterfall, Pareto, top movers |

## Key Corrections Incorporated

| # | Correction |
|---|-----------|
| 5 | `For Del` pre-filter removes deletion-flagged records before all processing |
| 6 | Configurable `report_run_date` — month-end or manual date |
| 7 | Dedup on `['TRADE REF', 'Period']` — null Trade Refs get surrogate SHA-256 key |
| 10| Single embedding model (`text-embedding-3-small`) — no dimension mismatch |
| 13| `thefuzz` replaces deprecated `FuzzyWuzzy` |

## Phase 2 Preparation

Every record gets three pre-computed flags:
- `is_timing_candidate` — Timing/Settlement breaks auto-classifiable without LLM (~35-45%)
- `has_ssi_signal` — SSI/Static Data breaks for Phase 2 clustering engine (~20-30%)
- `has_ca_signal` — Corporate Action signals for Phase 2 CA classification (~3-6%)

Combined Pareto coverage: **55-75% of breaks pre-classified without any LLM cost.**

## Running Tests

```bash
pytest tests/ -v
```

## StatPy Deployment

```bash
# Flask + Dash service
# Entry point: app.py  Port: 8050

# Streamlit service  
# Entry point: streamlit_app/app.py  Port: 8501
# Start command: streamlit run streamlit_app/app.py --server.port 8501 --server.headless true
```

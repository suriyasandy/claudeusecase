"""dashboard/__init__.py — Dash app factory mounted on Flask."""
import dash
import dash_bootstrap_components as dbc

from dashboard.layout import build_layout
from dashboard.callbacks import register_callbacks


def create_dash_app(flask_server):
    """Mount Dash on Flask. Returns the Dash app instance."""
    app = dash.Dash(
        __name__,
        server=flask_server,
        routes_pathname_prefix="/dashboard/",
        external_stylesheets=[
            dbc.themes.BOOTSTRAP,
            "https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap",
        ],
        suppress_callback_exceptions=True,
        title="Accounting Control AI",
    )
    app.layout = build_layout()
    register_callbacks(app)
    return app

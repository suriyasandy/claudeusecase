"""dashboard/callbacks.py — All Dash callback definitions."""
import base64
import io
import json
import logging

import pandas as pd
import requests
from dash import Input, Output, State, callback, html, dcc, dash_table, no_update
import dash_ag_grid as dag
import plotly.express as px
import plotly.graph_objects as go

from core.constants import PRIMARY, ACCENT, DARK, MUTED, COLORS, BUCKET_ORDER
from dashboard.components.charts import (
    trend_combo, completeness_bar, bucket_grouped, heatmap,
    waterfall, kpi_html, _apply,
)

log = logging.getLogger(__name__)

# Base URL for Flask API calls (same process — no network hop)
API_BASE = "http://localhost:8050"


def _api(path: str, params: dict = None):
    try:
        r = requests.get(f"{API_BASE}{path}", params=params, timeout=30)
        r.raise_for_status()
        return r.json()
    except Exception as exc:
        log.error("API call failed: %s — %s", path, exc)
        return None


def register_callbacks(app):

    # ── 1. Upload → process → store file_id ──────────────────────────────────
    @app.callback(
        Output("file-id-store", "data"),
        Output("upload-status", "children"),
        Output("filter-options-store", "data"),
        Input("upload-data", "contents"),
        State("upload-data", "filename"),
        State("date-mode", "value"),
        State("report-run-date", "date"),
        prevent_initial_call=True,
    )
    def handle_upload(contents, filename, date_mode, report_run_date):
        if not contents:
            return no_update, no_update, no_update
        try:
            content_type, content_string = contents.split(",")
            file_bytes = base64.b64decode(content_string)
        except Exception:
            return no_update, html.P("❌ Could not decode file", style={"color": ACCENT}), no_update

        # POST to Flask API
        try:
            resp = requests.post(
                f"{API_BASE}/api/data/upload",
                files={"file": (filename, io.BytesIO(file_bytes))},
                data={"date_mode": date_mode,
                      "report_run_date": report_run_date or ""},
                timeout=120,
            )
            resp.raise_for_status()
            data = resp.json()
        except Exception as exc:
            return no_update, html.P(f"❌ Upload failed: {exc}", style={"color": ACCENT}), no_update

        file_id = data["file_id"]

        # Fetch filter options
        fopts = _api(f"/api/analytics/filter-options/{file_id}")

        status = html.Div([
            html.P(f"✅ {filename}", style={"color": "#BCE2E7", "margin": "0",
                                             "fontSize": "0.85rem", "fontWeight": "600"}),
            html.P(f"{data['rows']:,} rows · {data['cols']} cols · "
                   f"{data['processing_ms']}ms",
                   style={"color": MUTED, "margin": "0", "fontSize": "0.75rem"}),
            html.P(f"For Del filtered: {data['filtered_for_del']} · "
                   f"Surrogate keys: {data['surrogate_keys']}",
                   style={"color": MUTED, "margin": "0", "fontSize": "0.72rem"}),
        ])
        return file_id, status, fopts.get("options", {}) if fopts else {}

    # ── 2. Toggle manual date picker ─────────────────────────────────────────
    @app.callback(
        Output("report-run-date", "disabled"),
        Input("date-mode", "value"),
    )
    def toggle_date_picker(mode):
        return mode != "manual"

    # ── 3. Build filter panel from options ────────────────────────────────────
    @app.callback(
        Output("filter-panel", "children"),
        Input("filter-options-store", "data"),
    )
    def build_filter_panel(options):
        if not options:
            return html.P("Upload a file to enable filters",
                          style={"color": MUTED, "fontSize": "0.8rem"})
        children = []
        filter_keys = [
            ("Period", "Period"),
            ("Team", "Team"),
            ("Rec Name (as per Rec Cube)", "Rec Name"),
            ("Entity", "Entity"),
            ("Asset Class", "Asset Class"),
            ("Type of break", "Type of Break"),
        ]
        for key, label in filter_keys:
            opts = options.get(key, [])
            if not opts:
                continue
            children += [
                html.P(label, style={"color": "#BCE2E7", "fontSize": "0.75rem",
                                      "marginBottom": "2px", "marginTop": "8px"}),
                dcc.Dropdown(
                    id={"type": "filter-dd", "key": key},
                    options=[{"label": str(o), "value": o} for o in opts],
                    value=opts,
                    multi=True,
                    style={"fontSize": "0.8rem"},
                ),
            ]
        return children

    # ── 4. Render tab content ─────────────────────────────────────────────────
    @app.callback(
        Output("tab-content", "children"),
        Input("main-tabs", "value"),
        Input("file-id-store", "data"),
        prevent_initial_call=False,
    )
    def render_tab(tab, file_id):
        if not file_id:
            return html.Div([
                html.Div(style={"textAlign": "center", "padding": "80px 20px"}, children=[
                    html.H2("📁 Upload a file to get started",
                            style={"color": MUTED}),
                    html.P("Supports XLSX and CSV. Up to 200 MB.",
                           style={"color": MUTED}),
                ])
            ])

        if tab == "tab-overview":
            return _tab_overview(file_id)
        elif tab == "tab-quality":
            return _tab_quality(file_id)
        elif tab == "tab-ageing":
            return _tab_ageing(file_id)
        elif tab == "tab-trends":
            return _tab_trends(file_id)
        elif tab == "tab-alerts":
            return _tab_alerts(file_id)
        return html.P("Select a tab")


# ── Tab renderers ──────────────────────────────────────────────────────────────

def _kpi_row(cards: list[tuple]) -> html.Div:
    """Render a row of KPI cards. Each tuple = (label, value, delta, invert)."""
    items = [
        html.Div(
            html.Div(dangerouslySetInnerHTML={"__html": kpi_html(l, v, d, i)}),
            style={"flex": "1", "minWidth": "150px", "margin": "4px"},
        )
        for l, v, d, i in cards
    ]
    return html.Div(items, style={"display": "flex", "flexWrap": "wrap", "gap": "8px", "marginBottom": "20px"})


def _section(title: str, *children) -> html.Div:
    return html.Div([
        html.H3(title, style={"color": DARK, "borderBottom": f"2px solid {PRIMARY}",
                               "paddingBottom": "6px", "marginBottom": "16px"}),
        *children,
    ], style={"marginBottom": "28px"})


def _tab_overview(file_id: str) -> html.Div:
    sc   = _api(f"/api/quality/scorecard/{file_id}")
    ag   = _api(f"/api/ageing/validation/{file_id}")
    tr   = _api(f"/api/analytics/trends/{file_id}")
    alr  = _api(f"/api/analytics/threshold-alerts/{file_id}")
    flg  = _api(f"/api/quality/flags-summary/{file_id}")

    if not sc:
        return html.P("Could not load scorecard data.")

    mom = f"{tr['mom_count_pct']:+.1f}% MoM" if tr and tr.get("mom_count_pct") else "N/A"
    n   = sc.get("total_records", 0)
    comp = f"{sc.get('overall_completeness', 0):.1f}%"
    viol = sc.get("total_type_violations", 0)
    mat  = alr.get("summary", {}).get("material", 0) if alr else 0
    acc  = ag.get("accuracy_rate", 100) if ag else 100

    kpi_row = html.Div([
        html.Div(dangerouslySetInnerHTML={"__html": kpi_html("Total Records", f"{n:,}")},
                 style={"flex": "1", "minWidth": "160px"}),
        html.Div(dangerouslySetInnerHTML={"__html": kpi_html("Completeness", comp)},
                 style={"flex": "1", "minWidth": "160px"}),
        html.Div(dangerouslySetInnerHTML={"__html": kpi_html("Type Violations", f"{viol:,}", invert=True)},
                 style={"flex": "1", "minWidth": "160px"}),
        html.Div(dangerouslySetInnerHTML={"__html": kpi_html("Ageing Accuracy", f"{acc:.1f}%")},
                 style={"flex": "1", "minWidth": "160px"}),
        html.Div(dangerouslySetInnerHTML={"__html": kpi_html("Material Alerts", str(mat), invert=True)},
                 style={"flex": "1", "minWidth": "160px"}),
        html.Div(dangerouslySetInnerHTML={"__html": kpi_html("MoM Change", mom)},
                 style={"flex": "1", "minWidth": "160px"}),
    ], style={"display": "flex", "flexWrap": "wrap", "gap": "10px", "marginBottom": "24px"})

    # Trend chart
    trend_fig = html.Div()
    if tr and tr.get("data"):
        df_tr = pd.DataFrame(tr["data"])
        if "_Period_label" in df_tr.columns and "break_count" in df_tr.columns:
            fig = trend_combo(df_tr["_Period_label"], df_tr["break_count"],
                              title="Break Count by Period")
            trend_fig = dcc.Graph(figure=fig)

    # Phase 2 flag banner
    flg_banner = html.Div()
    if flg:
        f = flg.get("flags", {})
        timing_pct = f.get("is_timing_candidate", {}).get("pct", 0)
        ssi_pct    = f.get("has_ssi_signal", {}).get("pct", 0)
        pareto     = flg.get("pareto_coverage_pct", 0)
        flg_banner = html.Div([
            html.H4("🚀 Phase 2 Readiness Flags", style={"color": PRIMARY, "marginBottom": "8px"}),
            html.P(f"Timing candidates: {timing_pct}%  ·  SSI signals: {ssi_pct}%  ·  "
                   f"Pareto coverage (Timing + SSI): {pareto}% of breaks pre-classified",
                   style={"background": "#E6F4F1", "padding": "12px 16px",
                          "borderLeft": f"4px solid {PRIMARY}", "borderRadius": "4px",
                          "color": DARK, "margin": "0"}),
        ], style={"marginTop": "20px"})

    return html.Div([kpi_row, trend_fig, flg_banner])


def _tab_quality(file_id: str) -> html.Div:
    sc    = _api(f"/api/quality/scorecard/{file_id}")
    compl = _api(f"/api/quality/column-completeness/{file_id}")
    nsum  = _api(f"/api/quality/numeric-summary/{file_id}")

    if not sc:
        return html.P("Load a file first.")

    viol_table = html.Div()
    if sc.get("type_violations"):
        viol_table = dag.AgGrid(
            rowData=sc["type_violations"],
            columnDefs=[{"field": k} for k in
                        ["column", "expected_type", "violation_count", "violation_pct", "sample_values"]],
            defaultColDef={"sortable": True, "filter": True, "resizable": True},
            dashGridOptions={"pagination": True, "paginationPageSize": 20},
            style={"height": "240px"},
        )
    else:
        viol_table = html.Div("✅ No type violations detected.",
                              style={"background": "#E8F5E9", "padding": "12px",
                                     "borderRadius": "4px", "color": "#1B7A3E"})

    outlier_table = html.Div()
    if sc.get("outliers"):
        outlier_table = dag.AgGrid(
            rowData=sc["outliers"],
            columnDefs=[{"field": k} for k in
                        ["column", "outlier_count", "outlier_pct", "iqr_lower", "iqr_upper",
                         "min_outlier", "max_outlier"]],
            defaultColDef={"sortable": True, "resizable": True},
            style={"height": "200px"},
        )
    else:
        outlier_table = html.P("No significant outliers detected.", style={"color": MUTED})

    compl_fig = html.Div()
    if compl and compl.get("data"):
        compl_fig = dcc.Graph(figure=completeness_bar(compl["data"]))

    summary_table = html.Div()
    if nsum and nsum.get("data"):
        cols = list(nsum["data"][0].keys()) if nsum["data"] else []
        summary_table = dag.AgGrid(
            rowData=nsum["data"],
            columnDefs=[{"field": c} for c in cols],
            defaultColDef={"sortable": True, "resizable": True, "width": 110},
            dashGridOptions={"pagination": True, "paginationPageSize": 20},
            style={"height": "320px"},
        )

    return html.Div([
        _section("Column Completeness", compl_fig),
        _section("Type Violation Details", viol_table),
        _section("Outlier Detection (IQR)", outlier_table),
        _section("Numeric Summary Statistics", summary_table),
    ])


def _tab_ageing(file_id: str) -> html.Div:
    ag   = _api(f"/api/ageing/validation/{file_id}")
    disc = _api(f"/api/ageing/discrepancies/{file_id}", {"page": 1, "page_size": 500})

    if not ag:
        return html.P("Ageing data not available — ensure Period and Date columns are present.")

    kpi_row = html.Div([
        html.Div(dangerouslySetInnerHTML={"__html": kpi_html(
            "Records Validated", f"{ag['total_validated']:,}")},
                 style={"flex": "1", "minWidth": "150px"}),
        html.Div(dangerouslySetInnerHTML={"__html": kpi_html(
            "Age Days Discrepancies",
            f"{ag['age_mismatch_count']:,} ({ag['age_mismatch_pct']}%)", invert=True)},
                 style={"flex": "1", "minWidth": "150px"}),
        html.Div(dangerouslySetInnerHTML={"__html": kpi_html(
            "Bucket Discrepancies",
            f"{ag['bucket_mismatch_count']:,} ({ag['bucket_mismatch_pct']}%)", invert=True)},
                 style={"flex": "1", "minWidth": "150px"}),
        html.Div(dangerouslySetInnerHTML={"__html": kpi_html(
            "Accuracy Rate", f"{ag['accuracy_rate']}%")},
                 style={"flex": "1", "minWidth": "150px"}),
        html.Div(dangerouslySetInnerHTML={"__html": kpi_html(
            "Reference Date Mode", ag.get("report_run_date_mode", "month_end"))},
                 style={"flex": "1", "minWidth": "150px"}),
    ], style={"display": "flex", "flexWrap": "wrap", "gap": "10px", "marginBottom": "20px"})

    bucket_fig = html.Div()
    bd = ag.get("bucket_distribution", {})
    if bd:
        bucket_fig = dcc.Graph(
            figure=bucket_grouped(bd.get("pre_populated", {}), bd.get("computed", {}))
        )

    disc_table = html.Div()
    if disc and disc.get("data"):
        cols = list(disc["data"][0].keys()) if disc["data"] else []
        row_style = {
            "styleConditions": [
                {"condition": "params.data['_Age_Match'] === false",
                 "style": {"backgroundColor": "#FDECEA"}},
                {"condition": "params.data['_Bucket_Match'] === false",
                 "style": {"backgroundColor": "#FFF8E1"}},
            ]
        }
        disc_table = dag.AgGrid(
            rowData=disc["data"],
            columnDefs=[{"field": c, "width": 130} for c in cols],
            defaultColDef={"sortable": True, "filter": True, "resizable": True},
            dashGridOptions={"pagination": True, "paginationPageSize": 25,
                             "rowClassRules": {}},
            style={"height": "420px"},
        )
        disc_table = html.Div([
            html.P(f"Showing {len(disc['data'])} of {disc['total']} discrepancy records",
                   style={"color": MUTED, "fontSize": "0.85rem", "marginBottom": "8px"}),
            disc_table,
        ])
    else:
        disc_table = html.Div("✅ No discrepancies found!",
                              style={"background": "#E8F5E9", "padding": "12px",
                                     "borderRadius": "4px", "color": "#1B7A3E"})

    return html.Div([kpi_row, _section("Bucket Distribution", bucket_fig),
                     _section("Discrepancy Records", disc_table)])


def _tab_trends(file_id: str) -> html.Div:
    tr_all   = _api(f"/api/analytics/trends/{file_id}")
    tr_team  = _api(f"/api/analytics/trends/{file_id}", {"group_by": "Team"})
    tr_amt   = _api(f"/api/analytics/trends/{file_id}")

    charts = []
    if tr_all and tr_all.get("data"):
        df = pd.DataFrame(tr_all["data"])
        if "_Period_label" in df.columns and "break_count" in df.columns:
            fig = trend_combo(df["_Period_label"], df["break_count"],
                              amounts=df.get("abs_gbp"),
                              title="Total Break Count & Amount by Period")
            charts.append(_section("Overall Trend", dcc.Graph(figure=fig)))

    if tr_team and tr_team.get("data"):
        df_t = pd.DataFrame(tr_team["data"])
        # Find team col name
        team_col = [c for c in df_t.columns
                    if c not in ("_Period_label", "break_count", "abs_gbp")]
        if team_col:
            fig2 = px.bar(df_t, x="_Period_label", y="break_count",
                          color=team_col[0], barmode="group",
                          color_discrete_sequence=COLORS,
                          title="Break Count by Team Over Periods")
            fig2 = _apply(fig2, "Break Count by Team Over Periods", "Period", "Count")
            charts.append(_section("Team Breakdown", dcc.Graph(figure=fig2)))

    if not charts:
        return html.P("No trend data available. Ensure Period and Date columns are mapped.")
    return html.Div(charts)


def _tab_alerts(file_id: str) -> html.Div:
    alr = _api(f"/api/analytics/threshold-alerts/{file_id}")
    fa  = _api(f"/api/analytics/factor-analysis/{file_id}")

    children = []

    if alr and alr.get("segments"):
        segs = alr["segments"]
        sm   = alr.get("summary", {})
        kpi_row = html.Div([
            html.Div(dangerouslySetInnerHTML={"__html": kpi_html(
                "Material Alerts", sm.get("material", 0), invert=True)},
                     style={"flex": "1"}),
            html.Div(dangerouslySetInnerHTML={"__html": kpi_html(
                "Watchlist", sm.get("watchlist", 0))},
                     style={"flex": "1"}),
            html.Div(dangerouslySetInnerHTML={"__html": kpi_html(
                "Normal", sm.get("normal", 0))},
                     style={"flex": "1"}),
        ], style={"display": "flex", "gap": "10px", "marginBottom": "16px"})

        cls_colors = {"Material": "#FDECEA", "Watchlist": "#FFF8E1", "Normal": "#E8F5E9"}
        alert_table = dag.AgGrid(
            rowData=segs,
            columnDefs=[
                {"field": "segment", "width": 200},
                {"field": "count_latest", "headerName": "Latest Count", "width": 130},
                {"field": "count_median", "headerName": "Median Count", "width": 130},
                {"field": "count_deviation_pct", "headerName": "Deviation %", "width": 130},
                {"field": "amt_latest", "headerName": "Latest Amount", "width": 150},
                {"field": "classification", "width": 130,
                 "cellStyle": {"function":
                     "params.value === 'Material' ? {backgroundColor:'#FDECEA',color:'#A84B2F',fontWeight:'bold'} : "
                     "params.value === 'Watchlist' ? {backgroundColor:'#FFF8E1',color:'#E65100',fontWeight:'bold'} : "
                     "{backgroundColor:'#E8F5E9',color:'#01696F'}"}},
            ],
            defaultColDef={"sortable": True, "filter": True, "resizable": True},
            dashGridOptions={"pagination": True, "paginationPageSize": 25},
            style={"height": "380px"},
        )
        children += [_section("MAD Threshold Alerts", kpi_row, alert_table)]

    if fa and fa.get("breakdown"):
        bd      = fa["breakdown"]
        labels  = [r.get(list(r.keys())[0], "") for r in bd]
        changes = [r.get("count_change", 0) for r in bd]
        wf_fig  = waterfall(labels, changes, fa.get("net_count_change", 0),
                            title=f"Break Count Change by Dimension "
                                  f"({fa.get('prev_label','')} → {fa.get('curr_label','')})")
        children += [_section("Factor Analysis (Period-over-Period)", dcc.Graph(figure=wf_fig))]

    if not children:
        return html.P("Upload a file with multiple periods to see alerts and factor analysis.")
    return html.Div(children)

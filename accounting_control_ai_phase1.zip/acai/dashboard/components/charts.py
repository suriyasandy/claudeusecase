"""dashboard/components/charts.py — Reusable Plotly figure builders."""
import plotly.express as px
import plotly.graph_objects as go

from core.constants import COLORS, PRIMARY, ACCENT, DARK, MUTED, BUCKET_ORDER

_LAYOUT = dict(
    font=dict(family="Inter, Arial, sans-serif", size=11, color=DARK),
    plot_bgcolor="white", paper_bgcolor="white",
    margin=dict(l=40, r=20, t=48, b=40),
    legend=dict(font=dict(size=10)),
)


def _apply(fig, title="", xaxis_title="", yaxis_title="", height=380):
    fig.update_layout(
        title=dict(text=title, font=dict(size=13, color=DARK)),
        xaxis_title=xaxis_title, yaxis_title=yaxis_title,
        height=height, **_LAYOUT,
    )
    fig.update_xaxes(showgrid=True, gridwidth=1, gridcolor="#ECECEC")
    fig.update_yaxes(showgrid=True, gridwidth=1, gridcolor="#ECECEC")
    return fig


# ── Trend combo (bar + line) ──────────────────────────────────────────────────
def trend_combo(periods, counts, amounts=None, title="Break Count Trend", height=360):
    fig = go.Figure()
    fig.add_trace(go.Bar(x=periods, y=counts, name="Break Count",
                         marker_color=PRIMARY, opacity=0.85))
    fig.add_trace(go.Scatter(x=periods, y=counts, name="Trend",
                             mode="lines+markers",
                             line=dict(color=ACCENT, width=2.5)))
    if amounts is not None:
        fig.add_trace(go.Scatter(x=periods, y=amounts, name="ABS GBP",
                                 yaxis="y2", mode="lines",
                                 line=dict(color=COLORS[4], width=1.5, dash="dot")))
        fig.update_layout(yaxis2=dict(overlaying="y", side="right",
                                      title="Amount (GBP)", showgrid=False))
    return _apply(fig, title, "Period", "Break Count", height)


# ── Completeness horizontal bar ───────────────────────────────────────────────
def completeness_bar(data: list[dict], height=None):
    import pandas as pd
    df = pd.DataFrame(data).sort_values("completeness_pct", ascending=True)
    fig = px.bar(df, x="completeness_pct", y="column", orientation="h",
                 color_discrete_sequence=[PRIMARY])
    h = height or max(300, len(df) * 16)
    fig = _apply(fig, "Per-Column Completeness (%)", "Completeness %", "", h)
    fig.update_layout(yaxis=dict(tickfont=dict(size=9)))
    return fig


# ── Bucket distribution grouped bar ──────────────────────────────────────────
def bucket_grouped(pre: dict, computed: dict):
    buckets = BUCKET_ORDER
    fig = go.Figure()
    fig.add_trace(go.Bar(x=buckets, y=[pre.get(b, 0) for b in buckets],
                         name="Pre-populated", marker_color=PRIMARY))
    fig.add_trace(go.Bar(x=buckets, y=[computed.get(b, 0) for b in buckets],
                         name="Computed", marker_color=ACCENT))
    fig.update_layout(barmode="group")
    return _apply(fig, "Bucket Distribution: Computed vs Pre-populated", "Bucket", "Count")


# ── Age Days histogram overlay ────────────────────────────────────────────────
def age_histogram(pre_vals, comp_vals):
    fig = go.Figure()
    fig.add_trace(go.Histogram(x=pre_vals, name="Pre-populated",
                               opacity=0.6, marker_color=PRIMARY, nbinsx=50))
    fig.add_trace(go.Histogram(x=comp_vals, name="Computed",
                               opacity=0.6, marker_color=ACCENT, nbinsx=50))
    fig.update_layout(barmode="overlay")
    return _apply(fig, "Age Days Distribution: Computed vs Pre-populated", "Age Days", "Count")


# ── Heatmap ───────────────────────────────────────────────────────────────────
def heatmap(pivot_df, title=""):
    fig = px.imshow(pivot_df, color_continuous_scale=["#FFFFFF", PRIMARY],
                    aspect="auto", text_auto=True)
    return _apply(fig, title, "", "", height=350)


# ── Waterfall (factor analysis) ───────────────────────────────────────────────
def waterfall(labels, values, net_change, title="Count Change by Dimension"):
    measures = ["relative"] * len(labels) + ["total"]
    x_labels = labels + ["Net Change"]
    y_values = list(values) + [0]
    fig = go.Figure(go.Waterfall(
        x=x_labels, y=y_values, measure=measures,
        increasing=dict(marker_color=ACCENT),
        decreasing=dict(marker_color=PRIMARY),
        totals=dict(marker_color=DARK),
        connector=dict(line=dict(color=MUTED, width=1)),
        text=[f"{v:+,.0f}" for v in values] + [f"{net_change:+,.0f}"],
        textposition="outside",
    ))
    fig = _apply(fig, title, "Dimension", "Count Change", height=440)
    fig.update_xaxes(tickangle=45)
    return fig


# ── MAD scatter ───────────────────────────────────────────────────────────────
def mad_scatter(segments_df):
    color_map = {"Material": ACCENT, "Watchlist": "#FFC553", "Normal": PRIMARY}
    fig = px.scatter(
        segments_df, x="count_median", y="count_latest",
        color="classification",
        color_discrete_map=color_map,
        hover_name="segment", size_max=25,
    )
    return _apply(fig, "Latest Count vs Median by Segment", "Median", "Latest Count")


# ── KPI card HTML helper ──────────────────────────────────────────────────────
def kpi_html(label: str, value, delta: str = None, invert: bool = False) -> str:
    delta_html = ""
    if delta:
        neg = (invert and not str(delta).startswith("-")) or (not invert and str(delta).startswith("-"))
        color = "#A84B2F" if neg else "#01696F"
        delta_html = f'<p style="color:{color};font-size:0.8rem;margin:0">{delta}</p>'
    return f"""
    <div style="background:white;border-left:4px solid {PRIMARY};
                padding:12px 16px;border-radius:4px;
                box-shadow:0 1px 3px rgba(0,0,0,0.08);margin-bottom:8px">
        <p style="color:#7A7974;font-size:0.72rem;text-transform:uppercase;
                  letter-spacing:0.5px;margin:0 0 2px 0">{label}</p>
        <p style="color:#28251D;font-size:1.4rem;font-weight:700;margin:0">{value}</p>
        {delta_html}
    </div>"""

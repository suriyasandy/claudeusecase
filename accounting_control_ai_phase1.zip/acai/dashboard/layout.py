"""dashboard/layout.py — Complete Dash app layout."""
from dash import dcc, html
import dash_bootstrap_components as dbc

from core.constants import PRIMARY, DARK, MUTED, BG_LIGHT

SIDEBAR_STYLE = {
    "width": "280px", "minHeight": "100vh", "backgroundColor": "#0C3547",
    "padding": "20px 16px", "position": "fixed", "left": 0, "top": 0,
    "overflowY": "auto", "zIndex": 100,
}
CONTENT_STYLE = {
    "marginLeft": "296px", "padding": "24px", "backgroundColor": BG_LIGHT,
    "minHeight": "100vh",
}
HEADER_STYLE = {
    "backgroundColor": PRIMARY, "padding": "12px 24px",
    "color": "white", "marginBottom": "20px", "borderRadius": "6px",
}


def build_layout():
    sidebar = html.Div([
        html.Div([
            html.H2("Accounting Control", style={"color": PRIMARY, "fontSize": "1.1rem",
                                                  "marginBottom": "2px", "fontWeight": "700"}),
            html.P("AI Platform · Phase 1", style={"color": MUTED, "fontSize": "0.75rem",
                                                    "marginBottom": "20px"}),
        ]),
        html.Hr(style={"borderColor": "#1B474D", "marginBottom": "16px"}),

        # File upload
        html.P("Data Upload", style={"color": "#BCE2E7", "fontSize": "0.75rem",
                                      "textTransform": "uppercase", "letterSpacing": "1px",
                                      "marginBottom": "8px"}),
        dcc.Upload(
            id="upload-data",
            children=html.Div([
                html.Span("📁 ", style={"fontSize": "1.2rem"}),
                html.Span("Drop XLSX / CSV here", style={"color": "#BCE2E7"}),
                html.Br(),
                html.Span("or click to browse", style={"color": MUTED, "fontSize": "0.8rem"}),
            ]),
            style={
                "borderWidth": "2px", "borderStyle": "dashed", "borderColor": "#1B474D",
                "borderRadius": "6px", "padding": "16px", "textAlign": "center",
                "cursor": "pointer", "marginBottom": "12px", "backgroundColor": "#0C4E54",
            },
            multiple=False,
        ),

        # Report date option
        html.P("Report Run Date", style={"color": "#BCE2E7", "fontSize": "0.75rem",
                                          "textTransform": "uppercase", "letterSpacing": "1px",
                                          "marginBottom": "4px"}),
        dcc.RadioItems(
            id="date-mode",
            options=[
                {"label": " Month-end (default)", "value": "month_end"},
                {"label": " Manual date", "value": "manual"},
            ],
            value="month_end",
            style={"color": "white", "fontSize": "0.85rem", "marginBottom": "8px"},
            labelStyle={"display": "block", "marginBottom": "4px"},
        ),
        dcc.DatePickerSingle(
            id="report-run-date", disabled=True,
            placeholder="Select date",
            style={"marginBottom": "16px", "width": "100%"},
        ),

        html.Hr(style={"borderColor": "#1B474D", "marginBottom": "12px"}),

        # Global filters (populated by callback after upload)
        html.P("Global Filters", style={"color": "#BCE2E7", "fontSize": "0.75rem",
                                         "textTransform": "uppercase", "letterSpacing": "1px",
                                         "marginBottom": "8px"}),
        html.Div(id="filter-panel"),

        html.Hr(style={"borderColor": "#1B474D", "margin": "16px 0 12px"}),

        # Upload status
        html.Div(id="upload-status"),

        # Hidden stores
        dcc.Store(id="file-id-store"),
        dcc.Store(id="col-map-store"),
        dcc.Store(id="filter-options-store"),
        dcc.Store(id="active-filters-store", data={}),
    ], style=SIDEBAR_STYLE)

    content = html.Div([
        html.Div([
            html.H1("Accounting Control AI Platform",
                    style={"margin": 0, "fontSize": "1.5rem", "fontWeight": "700",
                           "color": "white"}),
            html.P("Phase 1 · Data Quality · Ageing Validation · Trend Analysis",
                   style={"margin": "4px 0 0", "fontSize": "0.85rem",
                           "color": "#BCE2E7", "opacity": "0.85"}),
        ], style=HEADER_STYLE),

        dcc.Tabs(id="main-tabs", value="tab-overview", children=[
            dcc.Tab(label="📋 Overview",         value="tab-overview"),
            dcc.Tab(label="🔍 Data Quality",     value="tab-quality"),
            dcc.Tab(label="⏳ Ageing Validation", value="tab-ageing"),
            dcc.Tab(label="📊 Trend Analysis",   value="tab-trends"),
            dcc.Tab(label="🚨 Alerts & Factors", value="tab-alerts"),
        ], style={"marginBottom": "20px"}),

        html.Div(id="tab-content"),
    ], style=CONTENT_STYLE)

    return html.Div([sidebar, content])

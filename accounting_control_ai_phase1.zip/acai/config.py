"""config.py — Application configuration for Dev / Production."""
import os
from dotenv import load_dotenv

load_dotenv()


class BaseConfig:
    SECRET_KEY            = os.environ.get("SECRET_KEY", "dev-secret-change-me")
    MAX_CONTENT_LENGTH    = int(os.getenv("MAX_UPLOAD_MB", 200)) * 1024 * 1024
    CACHE_TTL             = int(os.getenv("CACHE_TTL_SECONDS", 300))
    UPLOAD_DIR            = os.getenv("UPLOAD_DIR", "data/uploads")
    CACHE_DIR             = os.getenv("CACHE_DIR", "data/cache")
    FLASK_API_BASE        = os.getenv("FLASK_API_BASE_URL", "http://localhost:8050")
    REPORT_RUN_DATE_MODE  = os.getenv("DEFAULT_REPORT_RUN_DATE_MODE", "month_end")
    REPORT_RUN_DATE       = os.getenv("REPORT_RUN_DATE", None)
    CACHE_TYPE            = "SimpleCache"
    CACHE_DEFAULT_TIMEOUT = int(os.getenv("CACHE_TTL_SECONDS", 300))


class DevelopmentConfig(BaseConfig):
    DEBUG     = True
    CACHE_TTL = 30


class ProductionConfig(BaseConfig):
    DEBUG = False


config_map = {
    "development": DevelopmentConfig,
    "production":  ProductionConfig,
}


def get_config():
    env = os.getenv("FLASK_ENV", "production")
    return config_map.get(env, ProductionConfig)

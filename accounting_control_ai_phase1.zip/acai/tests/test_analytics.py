"""tests/test_analytics.py — Unit tests for core/analytics.py"""
import sys, os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

import numpy as np
import pandas as pd
import pytest
from core.analytics import (
    safe_mom_pct, get_trend_data, compute_mad_alerts,
    compute_factor_analysis, apply_filters,
)
from core.ageing import compute_ageing
from core.ingestion import build_col_map


@pytest.fixture
def sample_df():
    df = pd.DataFrame({
        "Period":    [202501]*50 + [202502]*60 + [202503]*40,
        "Team":      (["Alpha"]*30 + ["Beta"]*20) +
                     (["Alpha"]*35 + ["Beta"]*25) +
                     (["Alpha"]*25 + ["Beta"]*15),
        "ABS GBP":   np.random.uniform(1000, 500000, 150),
        "Date":      pd.to_datetime(["2025-01-15"] * 50 +
                                    ["2025-02-10"] * 60 +
                                    ["2025-03-05"] * 40),
        "Age Days":  np.random.randint(1, 365, 150).astype(float),
        "Bucket":    ["0-15"] * 150,
    })
    col_map = build_col_map(df.columns.tolist())
    df = compute_ageing(df, col_map, date_mode="month_end")
    return df


@pytest.fixture
def col_map(sample_df):
    return build_col_map(sample_df.columns.tolist())


class TestSafeMomPct:
    def test_positive_change(self):
        assert safe_mom_pct(110, 100) == 10.0

    def test_negative_change(self):
        assert safe_mom_pct(90, 100) == -10.0

    def test_zero_previous(self):
        assert safe_mom_pct(100, 0) is None

    def test_none_previous(self):
        assert safe_mom_pct(100, None) is None


class TestGetTrendData:
    def test_returns_period_order(self, sample_df, col_map):
        result = get_trend_data(sample_df, col_map)
        assert "period_order" in result
        assert len(result["period_order"]) == 3

    def test_data_contains_break_count(self, sample_df, col_map):
        result = get_trend_data(sample_df, col_map)
        df_out = pd.DataFrame(result["data"])
        assert "break_count" in df_out.columns
        total = df_out["break_count"].sum()
        assert total == 150

    def test_grouped_by_team(self, sample_df, col_map):
        result = get_trend_data(sample_df, col_map, group_by_key="Team")
        df_out = pd.DataFrame(result["data"])
        team_col = [c for c in df_out.columns if c not in ("_Period_label","break_count","abs_gbp")]
        assert len(team_col) > 0

    def test_mom_pct_computed(self, sample_df, col_map):
        result = get_trend_data(sample_df, col_map)
        # Feb has 60, Jan has 50 → +20%
        assert result["mom_count_pct"] is not None


class TestComputeMadAlerts:
    def test_returns_segments(self, sample_df, col_map):
        result = compute_mad_alerts(sample_df, col_map, segment_key="Team")
        assert "segments" in result
        assert len(result["segments"]) == 2  # Alpha and Beta

    def test_summary_counts_add_up(self, sample_df, col_map):
        result = compute_mad_alerts(sample_df, col_map, segment_key="Team")
        sm = result["summary"]
        total = sm["material"] + sm["watchlist"] + sm["normal"]
        assert total == 2

    def test_classification_values_valid(self, sample_df, col_map):
        result = compute_mad_alerts(sample_df, col_map, segment_key="Team")
        valid  = {"Material", "Watchlist", "Normal", "Insufficient Data"}
        for seg in result["segments"]:
            assert seg["classification"] in valid

    def test_missing_segment_col_returns_error(self, sample_df, col_map):
        result = compute_mad_alerts(sample_df, col_map, segment_key="NonExistentCol")
        assert "error" in result


class TestComputeFactorAnalysis:
    def test_net_change(self, sample_df, col_map):
        result = compute_factor_analysis(sample_df, col_map, "Team", 202501, 202502)
        assert result["net_count_change"] == 10   # 60 - 50

    def test_breakdown_present(self, sample_df, col_map):
        result = compute_factor_analysis(sample_df, col_map, "Team", 202501, 202502)
        assert "breakdown" in result
        assert len(result["breakdown"]) > 0

    def test_labels_formatted(self, sample_df, col_map):
        result = compute_factor_analysis(sample_df, col_map, "Team", 202501, 202502)
        assert result["prev_label"] == "2025-01"
        assert result["curr_label"] == "2025-02"


class TestApplyFilters:
    def test_filter_by_team(self, sample_df, col_map):
        filtered = apply_filters(sample_df, col_map, {"Team": ["Alpha"]})
        team_col = col_map.get("Team", "Team")
        assert all(filtered[team_col] == "Alpha")

    def test_empty_filter_returns_all(self, sample_df, col_map):
        filtered = apply_filters(sample_df, col_map, {})
        assert len(filtered) == len(sample_df)

    def test_unknown_key_ignored(self, sample_df, col_map):
        filtered = apply_filters(sample_df, col_map, {"NonExistent": ["X"]})
        assert len(filtered) == len(sample_df)

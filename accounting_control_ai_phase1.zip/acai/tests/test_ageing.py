"""tests/test_ageing.py — Unit tests for core/ageing.py"""
import sys, os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

import pandas as pd
import pytest
from core.ageing import (
    period_to_datetime_vec, period_to_datetime_scalar,
    age_to_bucket_vec, period_labels_vec, compute_ageing,
)
from core.ingestion import build_col_map


class TestPeriodToDatetimeVec:
    def test_jan_2025(self):
        s = pd.Series([202501])
        r = period_to_datetime_vec(s)
        assert r[0] == pd.Timestamp("2025-01-31")

    def test_december_rollover(self):
        s = pd.Series([202412])
        r = period_to_datetime_vec(s)
        assert r[0] == pd.Timestamp("2024-12-31")

    def test_february_non_leap(self):
        s = pd.Series([202502])
        r = period_to_datetime_vec(s)
        assert r[0] == pd.Timestamp("2025-02-28")

    def test_february_leap(self):
        s = pd.Series([202402])
        r = period_to_datetime_vec(s)
        assert r[0] == pd.Timestamp("2024-02-29")

    def test_invalid_month_returns_nat(self):
        s = pd.Series([202513])
        r = period_to_datetime_vec(s)
        assert pd.isna(r[0])

    def test_multiple_periods(self):
        s = pd.Series([202501, 202502, 202512])
        r = period_to_datetime_vec(s)
        assert r[0] == pd.Timestamp("2025-01-31")
        assert r[1] == pd.Timestamp("2025-02-28")
        assert r[2] == pd.Timestamp("2025-12-31")


class TestPeriodToDatetimeScalar:
    def test_jan(self):
        ts = period_to_datetime_scalar(202501)
        assert ts == pd.Timestamp("2025-01-31")

    def test_invalid(self):
        ts = period_to_datetime_scalar("NOT_A_PERIOD")
        assert ts is pd.NaT or ts is None or pd.isna(ts)


class TestAgeToBucketVec:
    def test_buckets(self):
        ages = pd.Series([5, 15, 20, 30, 45, 60, 75, 90, 120, 180, 200, 365, 400, None])
        result = age_to_bucket_vec(ages)
        assert str(result[0])  == "0-15"
        assert str(result[1])  == "0-15"
        assert str(result[2])  == "16-30"
        assert str(result[3])  == "16-30"
        assert str(result[4])  == "31-60"
        assert str(result[5])  == "31-60"
        assert str(result[6])  == "61-90"
        assert str(result[7])  == "61-90"
        assert str(result[8])  == "91-180"
        assert str(result[9])  == "91-180"
        assert str(result[10]) == "181-365"
        assert str(result[11]) == "181-365"
        assert str(result[12]) == "365+"
        assert str(result[13]) == "Unknown"

    def test_returns_categorical(self):
        r = age_to_bucket_vec(pd.Series([10, 20, 365]))
        assert hasattr(r, "categories")


class TestComputeAgeing:
    @pytest.fixture
    def df_with_ageing(self):
        df = pd.DataFrame({
            "Period":    [202501, 202501, 202502],
            "Date":      pd.to_datetime(["2025-01-10", "2025-01-20", "2025-02-01"]),
            "Age Days":  [21.0, 11.0, 27.0],
            "Bucket":    ["16-30", "0-15", "16-30"],
        })
        return df

    def test_compute_ageing_month_end(self, df_with_ageing):
        col_map = build_col_map(df_with_ageing.columns.tolist())
        result  = compute_ageing(df_with_ageing, col_map, date_mode="month_end")
        assert "_Computed_Age_Days" in result.columns
        # Jan 31 - Jan 10 = 21 days
        assert result["_Computed_Age_Days"].iloc[0] == 21
        # Jan 31 - Jan 20 = 11 days
        assert result["_Computed_Age_Days"].iloc[1] == 11

    def test_compute_ageing_manual_date(self, df_with_ageing):
        col_map = build_col_map(df_with_ageing.columns.tolist())
        result  = compute_ageing(df_with_ageing, col_map,
                                 report_run_date="2025-02-05", date_mode="manual")
        # Feb 05 - Jan 10 = 26 days
        assert result["_Computed_Age_Days"].iloc[0] == 26

    def test_age_match_flag(self, df_with_ageing):
        col_map = build_col_map(df_with_ageing.columns.tolist())
        result  = compute_ageing(df_with_ageing, col_map, date_mode="month_end")
        assert "_Age_Match" in result.columns
        # First row: computed=21, pre-populated=21 → should match
        assert result["_Age_Match"].iloc[0] == True

    def test_bucket_computed(self, df_with_ageing):
        col_map = build_col_map(df_with_ageing.columns.tolist())
        result  = compute_ageing(df_with_ageing, col_map, date_mode="month_end")
        assert "_Computed_Bucket" in result.columns
        assert str(result["_Computed_Bucket"].iloc[0]) == "16-30"

    def test_period_label_generated(self, df_with_ageing):
        col_map = build_col_map(df_with_ageing.columns.tolist())
        result  = compute_ageing(df_with_ageing, col_map, date_mode="month_end")
        assert "_Period_label" in result.columns
        assert result["_Period_label"].iloc[0] == "2025-01"

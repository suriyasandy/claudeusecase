"""tests/test_cleaning.py — Unit tests for core/cleaning.py"""
import sys, os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

import numpy as np
import pandas as pd
import pytest
from core.cleaning import parse_amount_vec, parse_age_days_vec, detect_type_violations


class TestParseAmountVec:
    def test_plain_number(self):
        s = pd.Series(["1000", "2000.50", "3000"])
        r = parse_amount_vec(s)
        assert r.tolist() == [1000.0, 2000.50, 3000.0]

    def test_pound_symbol(self):
        r = parse_amount_vec(pd.Series(["£15,000", "£1,234.56"]))
        assert r[0] == 15000.0
        assert r[1] == 1234.56

    def test_currency_codes(self):
        r = parse_amount_vec(pd.Series(["GBP 15000", "USD 20000", "EUR 5000"]))
        assert r[0] == 15000.0
        assert r[1] == 20000.0

    def test_parenthesised_negative(self):
        r = parse_amount_vec(pd.Series(["(15000)", "(1,234.56)"]))
        assert r[0] == -15000.0
        assert r[1] == -1234.56

    def test_shorthand_k(self):
        r = parse_amount_vec(pd.Series(["15K", "1.5M", "2B"]))
        assert r[0] == 15_000.0
        assert r[1] == 1_500_000.0
        assert r[2] == 2_000_000_000.0

    def test_na_preserved(self):
        r = parse_amount_vec(pd.Series([None, "N/A", "n/a", "1000"]))
        assert pd.isna(r[0])
        assert pd.isna(r[1])
        assert pd.isna(r[2])
        assert r[3] == 1000.0

    def test_mixed_violation(self):
        r = parse_amount_vec(pd.Series(["1000", "INVALID", "2000"]))
        assert r[0] == 1000.0
        assert pd.isna(r[1])
        assert r[2] == 2000.0


class TestParseAgeDaysVec:
    def test_plain_integer(self):
        r = parse_age_days_vec(pd.Series(["15", "30", "180"]))
        assert r.tolist() == [15.0, 30.0, 180.0]

    def test_tilde_prefix(self):
        r = parse_age_days_vec(pd.Series(["~30", "~15"]))
        assert r[0] == 30.0
        assert r[1] == 15.0

    def test_days_suffix(self):
        r = parse_age_days_vec(pd.Series(["15 days", "30d", "180 Days"]))
        assert r[0] == 15.0
        assert r[1] == 30.0
        assert r[2] == 180.0

    def test_negative_age(self):
        r = parse_age_days_vec(pd.Series(["-5"]))
        assert r[0] == -5.0

    def test_na_strings(self):
        r = parse_age_days_vec(pd.Series(["N/A", "n/a", "-", "", None]))
        assert all(pd.isna(r))


class TestDetectTypeViolations:
    def test_no_violations(self):
        original = pd.Series(["100", "200"])
        parsed   = pd.Series([100.0, 200.0])
        result   = detect_type_violations(original, parsed, "TestCol", "float64")
        assert result is None

    def test_detects_violation(self):
        original = pd.Series(["100", "INVALID", "300"])
        parsed   = pd.Series([100.0, np.nan, 300.0])
        result   = detect_type_violations(original, parsed, "TestCol", "float64")
        assert result is not None
        assert result["violation_count"] == 1
        assert "INVALID" in result["sample_values"]

    def test_null_original_not_counted(self):
        original = pd.Series([None, "INVALID"])
        parsed   = pd.Series([np.nan, np.nan])
        result   = detect_type_violations(original, parsed, "TestCol", "float64")
        assert result["violation_count"] == 1

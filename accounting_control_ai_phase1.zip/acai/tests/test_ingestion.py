"""tests/test_ingestion.py — Unit tests for core/ingestion.py"""
import io
import sys, os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

import pandas as pd
import pytest
from core.ingestion import for_del_filter, dedup, build_col_map, fuzzy_col_match


@pytest.fixture
def sample_df():
    return pd.DataFrame({
        "Period":          [202501, 202501, 202501, 202502],
        "TRADE REF":       ["TRD001", "TRD001", None, "TRD003"],
        "Rec Name (as per Rec Cube)": ["REC_A", "REC_A", "REC_B", "REC_C"],
        "Entity":          ["E1", "E1", "E2", "E3"],
        "BREAK AMOUNT GBP":["1000", "1000", "2000", "3000"],
        "Date":            ["2025-01-10","2025-01-10","2025-01-15","2025-02-05"],
        "For Del":         ["False", "True", "False", "False"],
    })


def test_for_del_filter_removes_true(sample_df):
    col_map = build_col_map(sample_df.columns.tolist())
    filtered, count = for_del_filter(sample_df, col_map)
    assert count == 1
    assert len(filtered) == 3
    assert "True" not in filtered["For Del"].values


def test_for_del_filter_missing_column():
    df = pd.DataFrame({"A": [1, 2, 3]})
    filtered, count = for_del_filter(df, {})
    assert count == 0
    assert len(filtered) == 3


def test_dedup_on_trade_ref_and_period(sample_df):
    col_map = build_col_map(sample_df.columns.tolist())
    # Remove the For Del row first so TRD001/202501 appears twice
    df_no_del = sample_df[sample_df["For Del"] != "True"].copy()
    deduped, surrogate_count = dedup(df_no_del, col_map)
    # TRD001 in period 202501 appears twice — should be 1 after dedup
    trd001 = deduped[(deduped["TRADE REF"] == "TRD001") & (deduped["Period"] == 202501)]
    assert len(trd001) == 1


def test_dedup_assigns_surrogate_for_null_trade_ref(sample_df):
    col_map = build_col_map(sample_df.columns.tolist())
    df_clean = sample_df[sample_df["For Del"] != "True"].copy()
    deduped, surrogate_count = dedup(df_clean, col_map)
    assert surrogate_count == 1
    # Surrogate key should start with SRG_
    null_rows = deduped[deduped["TRADE REF"].str.startswith("SRG_", na=False)]
    assert len(null_rows) == 1


def test_fuzzy_col_match_exact():
    cols = ["Period", "TRADE REF", "ABS GBP"]
    assert fuzzy_col_match(cols, "Period") == "Period"
    assert fuzzy_col_match(cols, "ABS GBP") == "ABS GBP"


def test_fuzzy_col_match_case_insensitive():
    cols = ["period", "trade ref", "abs gbp"]
    assert fuzzy_col_match(cols, "Period") == "period"


def test_fuzzy_col_match_partial():
    cols = ["Rec Name (as per Rec Cube)", "Break Amount GBP"]
    assert fuzzy_col_match(cols, "Rec Name (as per Rec Cube)") is not None


def test_build_col_map_returns_mapping():
    cols = ["Period", "Team", "TRADE REF", "ABS GBP", "Age Days", "Bucket", "Date", "Comments"]
    col_map = build_col_map(cols)
    assert "Period"    in col_map
    assert "Team"      in col_map
    assert "ABS GBP"   in col_map
    assert "Age Days"  in col_map

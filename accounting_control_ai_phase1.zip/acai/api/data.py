"""api/data.py — POST /api/data/upload   GET /api/data/schema/<file_id>"""
import logging

from flask import Blueprint, request, jsonify, current_app

from core import pipeline, cache
from api import store

log = logging.getLogger(__name__)
data_bp = Blueprint("data", __name__)


@data_bp.route("/upload", methods=["POST"])
def upload():
    """
    POST /api/data/upload
    Accepts: multipart/form-data  — file (XLSX/CSV), report_run_date (optional)
    Returns: {file_id, rows, cols, filtered_for_del, surrogate_keys, cache_hit, processing_ms}
    """
    if "file" not in request.files:
        return jsonify({"error": "No file in request"}), 400

    f = request.files["file"]
    if not f.filename:
        return jsonify({"error": "Empty filename"}), 400

    allowed = {".xlsx", ".xlsm", ".csv"}
    ext = "." + f.filename.rsplit(".", 1)[-1].lower()
    if ext not in allowed:
        return jsonify({"error": f"File type '{ext}' not supported. Use XLSX or CSV"}), 400

    file_bytes      = f.read()
    report_run_date = request.form.get("report_run_date")
    date_mode       = request.form.get("date_mode", current_app.config.get("REPORT_RUN_DATE_MODE", "month_end"))

    try:
        result = pipeline.run_pipeline(
            file_bytes=file_bytes,
            filename=f.filename,
            report_run_date=report_run_date,
            date_mode=date_mode,
        )
    except Exception as exc:
        log.exception("Pipeline error: %s", exc)
        return jsonify({"error": str(exc)}), 500

    store.put(result["file_id"], result)
    meta = result["metadata"]

    return jsonify({
        "file_id":          result["file_id"],
        "filename":         f.filename,
        "rows":             meta["processed_rows"],
        "raw_rows":         meta["raw_rows"],
        "cols":             meta["columns"],
        "filtered_for_del": meta["filtered_for_del"],
        "surrogate_keys":   meta["surrogate_keys"],
        "cache_hit":        meta["cache_hit"],
        "processing_ms":    meta["processing_ms"],
        "timing_flag_pct":  meta["timing_flag_pct"],
        "ssi_flag_pct":     meta["ssi_flag_pct"],
        "ca_flag_pct":      meta["ca_flag_pct"],
        "date_mode":        date_mode,
        "report_run_date":  report_run_date,
    }), 200


@data_bp.route("/schema/<file_id>", methods=["GET"])
def schema(file_id):
    """
    GET /api/data/schema/<file_id>
    Returns: {columns, dtypes, col_map, unmapped, mapped_count}
    """
    result = store.get(file_id)
    if not result:
        return jsonify({"error": "file_id not found — upload first"}), 404

    df      = result["df"]
    col_map = result["col_map"]

    dtypes = {col: str(dtype) for col, dtype in df.dtypes.items()}
    unmapped = [
        exp for exp in [
            "Period", "Team", "Rec Name (as per Rec Cube)", "Entity", "Asset Class",
            "Type of break", "BREAK AMOUNT GBP", "ABS GBP", "Age Days", "Bucket",
            "Date", "Comments", "True/Systemic Breaks",
        ]
        if exp not in col_map
    ]

    return jsonify({
        "file_id":     file_id,
        "columns":     df.columns.tolist(),
        "dtypes":      dtypes,
        "col_map":     col_map,
        "unmapped":    unmapped,
        "mapped_count": len(col_map),
    }), 200


@data_bp.route("/list", methods=["GET"])
def list_files():
    """GET /api/data/list — list all file_ids currently in memory + cache."""
    in_memory  = store.keys()
    on_disk    = cache.list_cache()
    return jsonify({
        "in_memory": in_memory,
        "cached_on_disk": on_disk,
    }), 200

"""api/ageing.py — GET /api/ageing/validation   GET /api/ageing/discrepancies"""
import logging

from flask import Blueprint, request, jsonify

from api import store
from core.constants import BUCKET_ORDER

log = logging.getLogger(__name__)
ageing_bp = Blueprint("ageing", __name__)


def _get_result(file_id):
    result = store.get(file_id)
    if not result:
        return None, (jsonify({"error": "file_id not found"}), 404)
    return result, None


@ageing_bp.route("/validation/<file_id>", methods=["GET"])
def validation(file_id):
    """
    GET /api/ageing/validation/<file_id>
    Returns ageing validation summary KPIs.
    """
    result, err = _get_result(file_id)
    if err:
        return err

    df      = result["df"]
    col_map = result["col_map"]

    age_col    = col_map.get("Age Days")
    bucket_col = col_map.get("Bucket")

    if "_Computed_Age_Days" not in df.columns:
        return jsonify({"error": "Ageing not computed — pipeline may have missing Period/Date"}), 422

    valid = df[df["_Computed_Age_Days"].notna()]
    if age_col and age_col in df.columns:
        valid = valid[valid[age_col].notna()]

    n = len(valid)
    if n == 0:
        return jsonify({"error": "No valid rows for ageing comparison"}), 422

    age_mismatch    = int((~valid["_Age_Match"]).sum())    if "_Age_Match"    in valid.columns else 0
    bucket_mismatch = int((~valid["_Bucket_Match"]).sum()) if "_Bucket_Match" in valid.columns else 0

    # Bucket distribution comparison
    bucket_dist = {}
    if bucket_col and bucket_col in valid.columns:
        pre = valid[bucket_col].value_counts().reindex(BUCKET_ORDER, fill_value=0).to_dict()
        comp = valid["_Computed_Bucket"].value_counts().reindex(BUCKET_ORDER, fill_value=0).to_dict()
        bucket_dist = {"pre_populated": pre, "computed": comp}

    return jsonify({
        "file_id":              file_id,
        "total_validated":      n,
        "age_mismatch_count":   age_mismatch,
        "age_mismatch_pct":     round(age_mismatch    / n * 100, 2),
        "bucket_mismatch_count": bucket_mismatch,
        "bucket_mismatch_pct":  round(bucket_mismatch / n * 100, 2),
        "accuracy_rate":        round((1 - max(age_mismatch, bucket_mismatch) / n) * 100, 2),
        "report_run_date_mode": df.attrs.get("report_run_date_mode", "month_end"),
        "report_run_date_used": df.attrs.get("report_run_date_used", "month_end"),
        "bucket_distribution":  bucket_dist,
    }), 200


@ageing_bp.route("/discrepancies/<file_id>", methods=["GET"])
def discrepancies(file_id):
    """
    GET /api/ageing/discrepancies/<file_id>
    Paginated discrepancy records.
    Query params: page (default 1), page_size (default 100), team, rec_name
    """
    result, err = _get_result(file_id)
    if err:
        return err

    df      = result["df"]
    col_map = result["col_map"]
    page      = int(request.args.get("page", 1))
    page_size = min(int(request.args.get("page_size", 100)), 500)

    if "_Age_Match" not in df.columns and "_Bucket_Match" not in df.columns:
        return jsonify({"error": "Ageing not computed"}), 422

    # Build discrepancy mask
    mask = pd.Series(True, index=df.index)
    if "_Age_Match" in df.columns:
        mask &= ~df["_Age_Match"]
    if "_Bucket_Match" in df.columns:
        mask |= ~df["_Bucket_Match"]

    disc = df[mask].copy()

    # Optional filters
    team_filter = request.args.get("team")
    rec_filter  = request.args.get("rec_name")
    team_col    = col_map.get("Team")
    rec_col     = col_map.get("Rec Name (as per Rec Cube)")
    if team_filter and team_col and team_col in disc.columns:
        disc = disc[disc[team_col].astype(str) == team_filter]
    if rec_filter and rec_col and rec_col in disc.columns:
        disc = disc[disc[rec_col].astype(str) == rec_filter]

    total = len(disc)
    start = (page - 1) * page_size
    page_df = disc.iloc[start: start + page_size]

    # Select display columns
    show_keys = ["Period", "Team", "Rec Name (as per Rec Cube)", "Entity",
                 "Date", "Age Days", "Bucket", "TRADE REF"]
    show_cols = [col_map[k] for k in show_keys if k in col_map and col_map[k] in page_df.columns]
    for extra in ["_Computed_Age_Days", "_Computed_Bucket", "_Age_Match", "_Bucket_Match"]:
        if extra in page_df.columns:
            show_cols.append(extra)

    data = page_df[show_cols].copy()
    # Convert datetimes to strings for JSON
    for col in data.select_dtypes(include=["datetime64[ns]"]).columns:
        data[col] = data[col].dt.strftime("%Y-%m-%d")

    return jsonify({
        "file_id":  file_id,
        "total":    total,
        "page":     page,
        "page_size": page_size,
        "pages":    (total + page_size - 1) // page_size,
        "data":     data.to_dict(orient="records"),
    }), 200


# Fix missing import
import pandas as pd  # noqa: E402

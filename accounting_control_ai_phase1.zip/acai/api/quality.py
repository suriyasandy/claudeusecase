"""api/quality.py — GET /api/quality/scorecard   GET /api/quality/column-completeness"""
import logging

from flask import Blueprint, jsonify

from api import store

log = logging.getLogger(__name__)
quality_bp = Blueprint("quality", __name__)


def _get_result(file_id):
    result = store.get(file_id)
    if not result:
        return None, (jsonify({"error": "file_id not found — upload first"}), 404)
    return result, None


@quality_bp.route("/scorecard/<file_id>", methods=["GET"])
def scorecard(file_id):
    """
    GET /api/quality/scorecard/<file_id>
    Returns the full Data Quality Scorecard dict.
    """
    result, err = _get_result(file_id)
    if err:
        return err

    sc = result["scorecard"]
    # Remove the heavy column_completeness and numeric_summary from top-level
    # (served by their own endpoints for performance)
    return jsonify({
        "file_id":               file_id,
        "total_records":         sc["total_records"],
        "total_columns":         sc["total_columns"],
        "overall_completeness":  sc["overall_completeness"],
        "total_type_violations": sc["total_type_violations"],
        "type_violations":       sc["type_violations"],
        "filtered_for_del":      sc["filtered_for_del"],
        "surrogate_keys":        sc["surrogate_keys"],
        "outliers":              sc["outliers"],
    }), 200


@quality_bp.route("/column-completeness/<file_id>", methods=["GET"])
def column_completeness(file_id):
    """
    GET /api/quality/column-completeness/<file_id>
    Returns per-column completeness list sorted ascending — for the horizontal bar chart.
    """
    result, err = _get_result(file_id)
    if err:
        return err

    data = result["scorecard"].get("column_completeness", [])
    return jsonify({"file_id": file_id, "data": data}), 200


@quality_bp.route("/numeric-summary/<file_id>", methods=["GET"])
def numeric_summary(file_id):
    """
    GET /api/quality/numeric-summary/<file_id>
    Returns describe() for all numeric columns.
    """
    result, err = _get_result(file_id)
    if err:
        return err

    data = result["scorecard"].get("numeric_summary", [])
    return jsonify({"file_id": file_id, "data": data}), 200


@quality_bp.route("/flags-summary/<file_id>", methods=["GET"])
def flags_summary(file_id):
    """
    GET /api/quality/flags-summary/<file_id>
    Returns Phase 2 pre-computation flag counts and percentages.
    """
    result, err = _get_result(file_id)
    if err:
        return err

    df   = result["df"]
    meta = result["metadata"]
    n    = len(df)

    timing_count = int(df["is_timing_candidate"].sum()) if "is_timing_candidate" in df.columns else 0
    ssi_count    = int(df["has_ssi_signal"].sum())      if "has_ssi_signal"      in df.columns else 0
    ca_count     = int(df["has_ca_signal"].sum())        if "has_ca_signal"       in df.columns else 0

    return jsonify({
        "file_id": file_id,
        "total_records": n,
        "flags": {
            "is_timing_candidate": {"count": timing_count, "pct": round(timing_count / n * 100, 1)},
            "has_ssi_signal":      {"count": ssi_count,    "pct": round(ssi_count    / n * 100, 1)},
            "has_ca_signal":       {"count": ca_count,     "pct": round(ca_count     / n * 100, 1)},
        },
        "pareto_coverage_pct": round((timing_count + ssi_count) / n * 100, 1),
    }), 200

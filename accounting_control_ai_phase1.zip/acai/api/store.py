"""
api/store.py
────────────
Simple in-memory store mapping file_id → pipeline result dict.
Keyed by SHA-256 hash — same file always returns same key.
Flask-caching handles TTL. DataFrames live in process memory.
For multi-worker deployments, replace with Redis + Parquet reload.
"""
import threading

_lock  = threading.Lock()
_store: dict[str, dict] = {}   # {file_id: pipeline_result_dict}


def put(file_id: str, result: dict):
    with _lock:
        _store[file_id] = result


def get(file_id: str) -> dict | None:
    with _lock:
        return _store.get(file_id)


def has(file_id: str) -> bool:
    with _lock:
        return file_id in _store


def keys() -> list[str]:
    with _lock:
        return list(_store.keys())

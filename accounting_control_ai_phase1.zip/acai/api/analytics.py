"""
api/analytics.py
────────────────
GET /api/analytics/trends/<file_id>
GET /api/analytics/threshold-alerts/<file_id>
GET /api/analytics/factor-analysis/<file_id>
GET /api/analytics/drill-down/<file_id>
GET /api/analytics/filter-options/<file_id>
"""
import logging

from flask import Blueprint, request, jsonify
import pandas as pd

from api import store
from core import analytics as an

log = logging.getLogger(__name__)
analytics_bp = Blueprint("analytics", __name__)


def _get_result(file_id):
    result = store.get(file_id)
    if not result:
        return None, (jsonify({"error": "file_id not found"}), 404)
    return result, None


def _amt_col(col_map, df):
    """Pick best available amount column."""
    for key in ("ABS GBP", "BREAK AMOUNT GBP", "BREAK AMOUNT CCY"):
        col = col_map.get(key)
        if col and col in df.columns:
            return col
    return None


# ── Filter options ────────────────────────────────────────────────────────────

@analytics_bp.route("/filter-options/<file_id>", methods=["GET"])
def filter_options(file_id):
    """GET /api/analytics/filter-options/<file_id>"""
    result, err = _get_result(file_id)
    if err:
        return err
    return jsonify({
        "file_id": file_id,
        "options": result["filter_options"],
    }), 200


# ── Trend data ────────────────────────────────────────────────────────────────

@analytics_bp.route("/trends/<file_id>", methods=["GET"])
def trends(file_id):
    """
    GET /api/analytics/trends/<file_id>
    Query params:
      group_by    — expected column key e.g. 'Team', 'Asset Class'
      filters     — JSON-encoded {key: [values]} dict
    """
    result, err = _get_result(file_id)
    if err:
        return err

    df      = result["df"]
    col_map = result["col_map"]

    group_by = request.args.get("group_by")        # e.g. "Team"
    amt_col  = _amt_col(col_map, df)

    # Apply filters if passed
    raw_filters = request.args.get("filters", "{}")
    try:
        import json
        filters = json.loads(raw_filters)
    except Exception:
        filters = {}

    df_f = an.apply_filters(df, col_map, filters) if filters else df

    data = an.get_trend_data(df_f, col_map, amt_col=amt_col, group_by_key=group_by)
    data["file_id"] = file_id
    return jsonify(data), 200


# ── Threshold alerts ──────────────────────────────────────────────────────────

@analytics_bp.route("/threshold-alerts/<file_id>", methods=["GET"])
def threshold_alerts(file_id):
    """
    GET /api/analytics/threshold-alerts/<file_id>
    Query params: segment (default 'Team'), mad_k (default 3.0), watchlist_k (default 2.0)
    """
    result, err = _get_result(file_id)
    if err:
        return err

    df      = result["df"]
    col_map = result["col_map"]

    segment_key  = request.args.get("segment", "Team")
    mad_k        = float(request.args.get("mad_k", 3.0))
    watchlist_k  = float(request.args.get("watchlist_k", 2.0))
    amt_key      = request.args.get("amt_key", "ABS GBP")

    data = an.compute_mad_alerts(
        df, col_map,
        segment_key=segment_key,
        amt_key=amt_key,
        mad_k=mad_k,
        watchlist_k=watchlist_k,
    )
    data["file_id"] = file_id
    return jsonify(data), 200


# ── Factor analysis ───────────────────────────────────────────────────────────

@analytics_bp.route("/factor-analysis/<file_id>", methods=["GET"])
def factor_analysis(file_id):
    """
    GET /api/analytics/factor-analysis/<file_id>
    Query params: prev_period (int), curr_period (int), dimension (expected col key)
    """
    result, err = _get_result(file_id)
    if err:
        return err

    df      = result["df"]
    col_map = result["col_map"]

    period_col = col_map.get("Period")
    if not period_col or period_col not in df.columns:
        return jsonify({"error": "Period column not found"}), 422

    periods_sorted = sorted(df[period_col].dropna().unique().tolist())
    if len(periods_sorted) < 2:
        return jsonify({"error": "Need at least 2 periods for factor analysis"}), 422

    prev_period = request.args.get("prev_period", periods_sorted[-2])
    curr_period = request.args.get("curr_period", periods_sorted[-1])
    dimension   = request.args.get("dimension", "Team")
    amt_key     = request.args.get("amt_key", "ABS GBP")

    try:
        prev_period = int(prev_period)
        curr_period = int(curr_period)
    except ValueError:
        pass

    data = an.compute_factor_analysis(
        df, col_map,
        dim_key=dimension,
        prev_period=prev_period,
        curr_period=curr_period,
        amt_key=amt_key,
    )
    data["file_id"] = file_id
    return jsonify(data), 200


# ── Drill-down ────────────────────────────────────────────────────────────────

@analytics_bp.route("/drill-down/<file_id>", methods=["GET"])
def drill_down(file_id):
    """
    GET /api/analytics/drill-down/<file_id>
    Query params: team, rec_name, entity, product, page, page_size
    Returns filtered + paginated records.
    """
    result, err = _get_result(file_id)
    if err:
        return err

    df      = result["df"]
    col_map = result["col_map"]

    # Build filter dict from query params
    filters = {}
    for key, param in [
        ("Team",                       "team"),
        ("Rec Name (as per Rec Cube)", "rec_name"),
        ("Entity",                     "entity"),
        ("Products Reconciled",        "product"),
        ("Asset Class",                "asset_class"),
        ("Type of break",              "type_of_break"),
    ]:
        val = request.args.get(param)
        if val:
            filters[key] = [val]

    df_f = an.apply_filters(df, col_map, filters)

    page      = int(request.args.get("page", 1))
    page_size = min(int(request.args.get("page_size", 200)), 1000)
    total     = len(df_f)
    start     = (page - 1) * page_size

    display_keys = [
        "Period", "Team", "Rec Name (as per Rec Cube)", "Entity",
        "Products Reconciled", "Type of break", "TRADE REF",
        "BREAK AMOUNT GBP", "ABS GBP", "Age Days", "Bucket",
        "True/Systemic Breaks", "Comments",
        "is_timing_candidate", "has_ssi_signal", "has_ca_signal",
    ]
    show_cols = []
    for k in display_keys:
        actual = col_map.get(k, k)
        if actual in df_f.columns:
            show_cols.append(actual)
        elif k in df_f.columns:   # flag columns (not in col_map)
            show_cols.append(k)

    page_df = df_f[show_cols].iloc[start: start + page_size].copy()

    # Serialise
    for col in page_df.select_dtypes(include=["datetime64[ns]"]).columns:
        page_df[col] = page_df[col].dt.strftime("%Y-%m-%d")
    for col in page_df.select_dtypes(include=["category"]).columns:
        page_df[col] = page_df[col].astype(str)

    # Trend summary for filtered subset
    trend = {}
    if "_Period_label" in df_f.columns:
        cnt = df_f.groupby("_Period_label", observed=True).size()
        trend = cnt.to_dict()

    amt_col = _amt_col(col_map, df_f)
    amt_total = float(df_f[amt_col].sum()) if amt_col else 0.0

    return jsonify({
        "file_id":    file_id,
        "total":      total,
        "page":       page,
        "page_size":  page_size,
        "pages":      (total + page_size - 1) // page_size,
        "total_amount": amt_total,
        "trend":      trend,
        "data":       page_df.to_dict(orient="records"),
    }), 200

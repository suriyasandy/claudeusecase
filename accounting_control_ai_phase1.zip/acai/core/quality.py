"""
core/quality.py
───────────────
Data quality analysis:
  • completeness_report()   — per-column completeness %
  • overall_scorecard()     — summary metrics dict
  • detect_outliers_iqr()   — IQR-based outlier detection
  • numeric_summary()       — describe() for numeric columns
"""
import logging

import numpy as np
import pandas as pd

log = logging.getLogger(__name__)

_AMOUNT_KEYS = ("BREAK AMOUNT CCY", "BREAK AMOUNT GBP", "ABS GBP", "Age Days")


# ── Per-column completeness ───────────────────────────────────────────────────

def completeness_report(df: pd.DataFrame) -> list[dict]:
    """Return list of {column, non_null_count, completeness_pct} sorted asc."""
    n = len(df)
    rows = []
    for col in df.columns:
        non_null = int(df[col].notna().sum())
        rows.append({
            "column":          col,
            "non_null_count":  non_null,
            "null_count":      n - non_null,
            "completeness_pct": round(non_null / n * 100, 2) if n else 0.0,
        })
    return sorted(rows, key=lambda x: x["completeness_pct"])


# ── Outlier detection (IQR) ───────────────────────────────────────────────────

def detect_outliers_iqr(series: pd.Series, col_name: str) -> dict | None:
    """
    IQR method: outlier if value < Q1 - 1.5*IQR  or  > Q3 + 1.5*IQR.
    Requires at least 20 non-null numeric values.
    Returns summary dict or None if insufficient data / no outliers.
    """
    if series.dtype not in (np.float64, np.int64, float, int):
        return None
    clean = series.dropna()
    if len(clean) < 20:
        return None
    q1, q3 = clean.quantile(0.25), clean.quantile(0.75)
    iqr    = q3 - q1
    if iqr == 0:
        return None
    lower, upper = q1 - 1.5 * iqr, q3 + 1.5 * iqr
    outliers = clean[(clean < lower) | (clean > upper)]
    if len(outliers) == 0:
        return None
    return {
        "column":        col_name,
        "outlier_count": int(len(outliers)),
        "outlier_pct":   round(len(outliers) / len(clean) * 100, 2),
        "iqr_lower":     round(float(lower), 2),
        "iqr_upper":     round(float(upper), 2),
        "min_outlier":   round(float(outliers.min()), 2),
        "max_outlier":   round(float(outliers.max()), 2),
    }


# ── Numeric summary ───────────────────────────────────────────────────────────

def numeric_summary(df: pd.DataFrame) -> list[dict]:
    """describe() for all numeric columns, returned as list of dicts."""
    num_cols = df.select_dtypes(include=[np.number]).columns.tolist()
    if not num_cols:
        return []
    summary = df[num_cols].describe().T.round(2)
    summary.index.name = "column"
    return summary.reset_index().to_dict(orient="records")


# ── Master scorecard ──────────────────────────────────────────────────────────

def overall_scorecard(
    df: pd.DataFrame,
    col_map: dict,
    violations: list[dict],
    filtered_for_del: int,
    surrogate_keys: int,
) -> dict:
    """
    Build the complete data quality scorecard dict for the /api/quality/scorecard endpoint.
    """
    n        = len(df)
    n_cols   = len(df.columns)
    total_cells = n * n_cols

    # Overall completeness
    non_null_total = int(df.notna().sum().sum())
    overall_completeness = round(non_null_total / total_cells * 100, 2) if total_cells else 0.0

    # Column completeness report
    col_completeness = completeness_report(df)

    # Outliers on amount / age columns
    outliers = []
    for key in _AMOUNT_KEYS:
        actual = col_map.get(key)
        if actual and actual in df.columns:
            o = detect_outliers_iqr(df[actual], actual)
            if o:
                outliers.append(o)

    # Total violation count
    total_violations = sum(v["violation_count"] for v in violations)

    return {
        "total_records":         n,
        "total_columns":         n_cols,
        "overall_completeness":  overall_completeness,
        "total_type_violations": total_violations,
        "type_violations":       violations,
        "filtered_for_del":      filtered_for_del,
        "surrogate_keys":        surrogate_keys,
        "outliers":              outliers,
        "column_completeness":   col_completeness,
        "numeric_summary":       numeric_summary(df),
    }

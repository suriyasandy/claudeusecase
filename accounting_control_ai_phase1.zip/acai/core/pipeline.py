"""
core/pipeline.py
────────────────
Master pipeline orchestrator.
Calls every core module in the correct order and returns
a fully processed DataFrame + metadata dict.

Used by both Flask API endpoints and Streamlit app.
"""
import logging
import os
import time

import pandas as pd

from core import cache, ingestion, cleaning, ageing, quality, flags, analytics

log = logging.getLogger(__name__)


def run_pipeline(
    file_bytes: bytes,
    filename: str,
    report_run_date: str | None = None,
    date_mode: str = "month_end",
    force_reprocess: bool = False,
) -> dict:
    """
    Full Phase 1 pipeline. Returns:
    {
      file_id:         str   — SHA-256 hash
      df:              DataFrame (fully processed, in memory)
      col_map:         dict  — expected→actual column mapping
      violations:      list  — type violation dicts
      filter_options:  dict  — sidebar filter choices
      scorecard:       dict  — data quality scorecard
      metadata:        dict  — row counts, timings, flags summary
    }
    """
    t0 = time.time()

    # ── 1. Hash the file ──────────────────────────────────────────────────────
    fhash = cache.file_hash(file_bytes)
    log.info("Pipeline START  file=%s  hash=%s", filename, fhash[:12])

    # ── 2. Cache hit (skip re-processing) ────────────────────────────────────
    cache.ensure_dirs()
    cached_df = None if force_reprocess else cache.read_cache(fhash)
    cache_hit = cached_df is not None

    if cache_hit:
        df = cached_df
        col_map = ingestion.build_col_map(df.columns.tolist())
        # Violations and scorecard are re-computed (fast on already-typed df)
        violations = []
        scorecard  = quality.overall_scorecard(df, col_map, violations, 0, 0)
        filter_options = analytics.filter_options_from_df(df, col_map)
        elapsed = round(time.time() - t0, 2)
        log.info("Pipeline CACHE HIT  %ds", elapsed)
        return _build_result(fhash, df, col_map, violations, filter_options,
                             scorecard, elapsed, cache_hit=True,
                             filtered_for_del=0, surrogate_keys=0)

    # ── 3. Load raw file ──────────────────────────────────────────────────────
    df = ingestion.load_file(file_bytes, filename)
    raw_rows = len(df)

    # ── 4. Build column map ───────────────────────────────────────────────────
    col_map = ingestion.build_col_map(df.columns.tolist())
    log.info("col_map: %d / %d columns matched", len(col_map), 41)

    # ── 5. For Del pre-filter  (CORRECTION #5) ────────────────────────────────
    df, filtered_for_del = ingestion.for_del_filter(df, col_map)

    # ── 6. Deduplication  (CORRECTION #7) ────────────────────────────────────
    df, surrogate_keys = ingestion.dedup(df, col_map)

    # ── 7. Type cleaning ──────────────────────────────────────────────────────
    df, violations = cleaning.clean_dataframe(df, col_map)

    # ── 8. Ageing computation  (CORRECTION #6) ───────────────────────────────
    df = ageing.compute_ageing(df, col_map,
                               report_run_date=report_run_date,
                               date_mode=date_mode)

    # ── 9. Phase 2 preparation flags ─────────────────────────────────────────
    df = flags.add_all_flags(df, col_map)

    # ── 10. Pre-compute filter options ───────────────────────────────────────
    filter_options = analytics.filter_options_from_df(df, col_map)

    # ── 11. Build quality scorecard ──────────────────────────────────────────
    scorecard = quality.overall_scorecard(
        df, col_map, violations, filtered_for_del, surrogate_keys
    )

    # ── 12. Write to Parquet cache ────────────────────────────────────────────
    cache.write_cache(fhash, df)

    elapsed = round(time.time() - t0, 2)
    log.info("Pipeline COMPLETE  %ds  rows=%d", elapsed, len(df))

    return _build_result(
        fhash, df, col_map, violations, filter_options, scorecard,
        elapsed, cache_hit=False,
        filtered_for_del=filtered_for_del,
        surrogate_keys=surrogate_keys,
        raw_rows=raw_rows,
    )


def _build_result(
    fhash, df, col_map, violations, filter_options, scorecard,
    elapsed, cache_hit, filtered_for_del, surrogate_keys, raw_rows=None
) -> dict:
    timing_pct = round(df["is_timing_candidate"].mean() * 100, 1) if "is_timing_candidate" in df.columns else 0
    ssi_pct    = round(df["has_ssi_signal"].mean() * 100, 1)      if "has_ssi_signal"      in df.columns else 0
    ca_pct     = round(df["has_ca_signal"].mean() * 100, 1)       if "has_ca_signal"        in df.columns else 0

    return {
        "file_id":        fhash,
        "df":             df,
        "col_map":        col_map,
        "violations":     violations,
        "filter_options": filter_options,
        "scorecard":      scorecard,
        "metadata": {
            "raw_rows":          raw_rows or len(df),
            "processed_rows":    len(df),
            "columns":           len(df.columns),
            "filtered_for_del":  filtered_for_del,
            "surrogate_keys":    surrogate_keys,
            "cache_hit":         cache_hit,
            "processing_ms":     int(elapsed * 1000),
            "timing_flag_pct":   timing_pct,
            "ssi_flag_pct":      ssi_pct,
            "ca_flag_pct":       ca_pct,
        },
    }

"""
core/flags.py
─────────────
Pre-computation flags for the Phase 2 rule engine.
These are computed in Phase 1 and stored on every record so Phase 2
can classify ~45-55% of breaks without any LLM calls.

  • flag_timing_candidate()  → is_timing_candidate (bool)
  • flag_ssi_signal()        → has_ssi_signal (bool)
  • flag_ca_signal()         → has_ca_signal (bool)
  • add_all_flags()          → adds all three columns to df
"""
import logging

import pandas as pd

from core.constants import SSI_KEYWORDS, CA_KEYWORDS, TIMING_BREAK_TYPES

log = logging.getLogger(__name__)


def _str_contains_any(series: pd.Series, keywords: list[str]) -> pd.Series:
    """
    Vectorised: True if series (lowercased) contains ANY keyword.
    Uses str.contains with combined regex OR pattern — single pass over 621K rows.
    """
    pattern = "|".join(map(str.lower, keywords))
    return series.astype(str).str.lower().str.contains(pattern, regex=True, na=False)


def flag_timing_candidate(df: pd.DataFrame, col_map: dict) -> pd.Series:
    """
    Returns bool Series.  True if:
      _Computed_Age_Days <= 3  AND
      (Bucket == '0-15'  OR  Type_of_break contains TIMING_BREAK_TYPES)

    These breaks are candidates for Phase 2 auto-classification as Timing (#1).
    Requires compute_ageing() to have already been called.
    """
    n = len(df)
    mask = pd.Series(False, index=df.index)

    # Age condition
    if "_Computed_Age_Days" in df.columns:
        mask |= df["_Computed_Age_Days"].fillna(999) <= 3

    # Bucket condition
    bucket_col = col_map.get("Bucket")
    if bucket_col and bucket_col in df.columns:
        mask |= df[bucket_col].astype(str).str.strip() == "0-15"

    # Type of break keyword condition
    tob_col = col_map.get("Type of break")
    if tob_col and tob_col in df.columns:
        mask |= _str_contains_any(df[tob_col], TIMING_BREAK_TYPES)

    log.info("flag_timing_candidate: %d / %d records flagged", mask.sum(), n)
    return mask


def flag_ssi_signal(df: pd.DataFrame, col_map: dict) -> pd.Series:
    """
    Returns bool Series. True if Comments OR JIRA DESC contains SSI keywords.
    These are candidates for Phase 2 SSI Clustering engine.
    """
    n = len(df)
    mask = pd.Series(False, index=df.index)

    for key in ("Comments", "JIRA DESC", "EPIC DESC"):
        col = col_map.get(key)
        if col and col in df.columns:
            mask |= _str_contains_any(df[col], SSI_KEYWORDS)

    # Also flag if SYSTEM TO BE FIXED references a known SSI system
    ssi_systems = ["bloomberg ssi", "omgeo", "alert", "avox", "bonnaire", "ssimatch"]
    sys_col = col_map.get("SYSTEM TO BE FIXED")
    if sys_col and sys_col in df.columns:
        mask |= _str_contains_any(df[sys_col], ssi_systems)

    log.info("flag_ssi_signal: %d / %d records flagged", mask.sum(), n)
    return mask


def flag_ca_signal(df: pd.DataFrame, col_map: dict) -> pd.Series:
    """
    Returns bool Series. True if Comments contains Corporate Action keywords.
    Candidates for Phase 2 Corporate Action root cause classification.
    """
    n = len(df)
    mask = pd.Series(False, index=df.index)

    for key in ("Comments", "JIRA DESC", "Thematic"):
        col = col_map.get(key)
        if col and col in df.columns:
            mask |= _str_contains_any(df[col], CA_KEYWORDS)

    log.info("flag_ca_signal: %d / %d records flagged", mask.sum(), n)
    return mask


def add_all_flags(df: pd.DataFrame, col_map: dict) -> pd.DataFrame:
    """
    Apply all three Phase 2 preparation flags to df.
    Adds: is_timing_candidate, has_ssi_signal, has_ca_signal (all bool).
    """
    df = df.copy()
    df["is_timing_candidate"] = flag_timing_candidate(df, col_map)
    df["has_ssi_signal"]      = flag_ssi_signal(df, col_map)
    df["has_ca_signal"]       = flag_ca_signal(df, col_map)

    timing_pct = round(df["is_timing_candidate"].mean() * 100, 1)
    ssi_pct    = round(df["has_ssi_signal"].mean() * 100, 1)
    ca_pct     = round(df["has_ca_signal"].mean() * 100, 1)
    log.info(
        "Flags summary — timing: %.1f%%  SSI: %.1f%%  CA: %.1f%%",
        timing_pct, ssi_pct, ca_pct,
    )
    return df

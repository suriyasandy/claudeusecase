"""core/cache.py — SHA-256 keyed Parquet cache for 621K-row DataFrames."""
import hashlib
import os
import logging
from io import BytesIO

import pandas as pd

log = logging.getLogger(__name__)

CACHE_DIR = os.getenv("CACHE_DIR", "data/cache")


def ensure_dirs():
    os.makedirs(CACHE_DIR, exist_ok=True)
    os.makedirs(os.getenv("UPLOAD_DIR", "data/uploads"), exist_ok=True)


def file_hash(file_bytes: bytes) -> str:
    """SHA-256 of first 4 MB + total length. Fast and collision-resistant."""
    chunk = file_bytes[:4 * 1024 * 1024]
    return hashlib.sha256(chunk + str(len(file_bytes)).encode()).hexdigest()


def parquet_path(fhash: str) -> str:
    return os.path.join(CACHE_DIR, f"{fhash}.parquet")


def read_cache(fhash: str) -> pd.DataFrame | None:
    """Return cached DataFrame or None if cache miss / corrupt."""
    path = parquet_path(fhash)
    if not os.path.exists(path):
        return None
    try:
        df = pd.read_parquet(path, engine="pyarrow")
        log.info("Cache HIT  %s  (%d rows)", fhash[:12], len(df))
        return df
    except Exception as exc:
        log.warning("Cache corrupt %s — %s", fhash[:12], exc)
        return None


def write_cache(fhash: str, df: pd.DataFrame) -> bool:
    """Persist DataFrame to Parquet. Returns True on success."""
    ensure_dirs()
    path = parquet_path(fhash)
    try:
        # Convert Categoricals → string so Parquet round-trips cleanly
        df_save = df.copy()
        for col in df_save.select_dtypes(["category"]).columns:
            df_save[col] = df_save[col].astype(str).replace("nan", pd.NA)
        df_save.to_parquet(path, index=False, engine="pyarrow", compression="snappy")
        log.info("Cache WRITE %s  (%d rows)", fhash[:12], len(df))
        return True
    except Exception as exc:
        log.warning("Cache write failed %s — %s", fhash[:12], exc)
        return False


def invalidate(fhash: str):
    """Delete a specific cache entry."""
    path = parquet_path(fhash)
    if os.path.exists(path):
        os.remove(path)
        log.info("Cache INVALIDATED %s", fhash[:12])


def list_cache() -> list[dict]:
    """List all cached files with size and mtime."""
    ensure_dirs()
    entries = []
    for f in os.listdir(CACHE_DIR):
        if f.endswith(".parquet"):
            full = os.path.join(CACHE_DIR, f)
            stat = os.stat(full)
            entries.append({
                "file_id": f.replace(".parquet", ""),
                "size_mb": round(stat.st_size / 1024 / 1024, 2),
                "mtime":   stat.st_mtime,
            })
    return sorted(entries, key=lambda x: x["mtime"], reverse=True)

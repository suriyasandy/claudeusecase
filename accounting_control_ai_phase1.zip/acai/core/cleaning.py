"""
core/cleaning.py
────────────────
Vectorised type coercion — no .apply() on columns > 10K rows.
  • parse_amount_vec()         — strip currency symbols → float64
  • parse_age_days_vec()       — extract leading int → float64
  • apply_categorical_dtypes() — high-cardinality strings → pd.Categorical
  • detect_type_violations()   — before/after comparison
  • clean_dataframe()          — orchestrates all cleaning steps
"""
import logging

import numpy as np
import pandas as pd

from core.constants import CATEGORICAL_COLS

log = logging.getLogger(__name__)

# ── Amount parsing ─────────────────────────────────────────────────────────────

_CCY_PATTERN  = r"(?i)^(GBP|USD|EUR|JPY|CHF|AUD|CAD|SGD|HKD)\s*"
_SYMBOL_CHARS = r"[£$€¥₹,\s]"


def parse_amount_vec(series: pd.Series) -> pd.Series:
    """
    Vectorised: strip £$€, currency codes (GBP/USD/EUR…), commas, spaces.
    Handles: '£15,000'  'GBP 15000'  '(15,000)'  '-15000'  '15K'  'N/A'
    Returns float64 Series. Preserves original NaN.
    """
    original_na = series.isna()
    s = series.astype(str).str.strip()

    # Remove currency codes
    s = s.str.replace(_CCY_PATTERN, "", regex=True)
    # Remove currency symbols and commas
    s = s.str.replace(_SYMBOL_CHARS, "", regex=True)
    # Convert parenthesised negatives  (15000) → -15000
    s = s.str.replace(r"^\((.+)\)$", r"-\1", regex=True)
    # Shorthand: 15K → 15000, 1.5M → 1500000, 2B → 2000000
    s = s.str.replace(r"(?i)^(-?\d+(?:\.\d+)?)K$", lambda m: str(float(m.group(1)) * 1_000), regex=True)
    s = s.str.replace(r"(?i)^(-?\d+(?:\.\d+)?)M$", lambda m: str(float(m.group(1)) * 1_000_000), regex=True)
    s = s.str.replace(r"(?i)^(-?\d+(?:\.\d+)?)B$", lambda m: str(float(m.group(1)) * 1_000_000_000), regex=True)

    result = pd.to_numeric(s, errors="coerce")
    result[original_na] = np.nan
    return result


# ── Age Days parsing ──────────────────────────────────────────────────────────

_NA_STRINGS = {"", "n/a", "na", "-", "nan", "none", "null", "#n/a", "#null!"}


def parse_age_days_vec(series: pd.Series) -> pd.Series:
    """
    Vectorised: extract leading integer from '15 days', '~30', '15d', etc.
    Returns float64. Marks N/A strings as NaN.
    """
    original_na = series.isna()
    s = series.astype(str).str.strip().str.lower()
    # Mark known NA patterns
    na_mask = original_na | s.isin(_NA_STRINGS)
    # Extract leading integer (optionally preceded by ~)
    extracted = s.str.extract(r"^[~]?(-?\d+)", expand=False)
    result = pd.to_numeric(extracted, errors="coerce")
    result[na_mask] = np.nan
    return result


# ── Categorical conversion ─────────────────────────────────────────────────────

def apply_categorical_dtypes(df: pd.DataFrame, col_map: dict) -> pd.DataFrame:
    """
    Convert high-cardinality string columns to pd.Categorical.
    Reduces memory ~40-60% and makes groupby(observed=True) safe and fast.
    """
    for expected_key in CATEGORICAL_COLS:
        actual_col = col_map.get(expected_key)
        if actual_col and actual_col in df.columns:
            if df[actual_col].dtype == object:
                df[actual_col] = df[actual_col].astype("category")
    return df


# ── Type violation detection ──────────────────────────────────────────────────

def detect_type_violations(
    original: pd.Series,
    parsed: pd.Series,
    col_name: str,
    expected_type: str,
) -> dict | None:
    """
    Compare original vs parsed series.
    A violation = original is non-null but parsed is NaN (conversion failed).
    Returns violation dict or None if no violations.
    """
    mask = original.notna() & parsed.isna()
    count = int(mask.sum())
    if count == 0:
        return None
    samples = original[mask].head(5).astype(str).tolist()
    return {
        "column":         col_name,
        "expected_type":  expected_type,
        "violation_count": count,
        "violation_pct":  round(count / len(original) * 100, 3),
        "sample_values":  ", ".join(samples),
    }


# ── Master cleaning orchestrator ──────────────────────────────────────────────

def clean_dataframe(df: pd.DataFrame, col_map: dict) -> tuple[pd.DataFrame, list[dict]]:
    """
    Apply all type coercions in one pass. Returns (cleaned_df, violations_list).
    All operations are vectorised — no .apply() on large columns.
    """
    df = df.copy()
    violations = []

    # ── Amount columns → float64
    for key in ("BREAK AMOUNT CCY", "BREAK AMOUNT GBP", "ABS GBP"):
        actual = col_map.get(key)
        if actual and actual in df.columns:
            original = df[actual].copy()
            df[actual] = parse_amount_vec(df[actual])
            v = detect_type_violations(original, df[actual], actual, "float64")
            if v:
                violations.append(v)
                log.info("Type violation in %s: %d rows", actual, v["violation_count"])

    # ── Age Days → float64
    actual = col_map.get("Age Days")
    if actual and actual in df.columns:
        original = df[actual].copy()
        df[actual] = parse_age_days_vec(df[actual])
        v = detect_type_violations(original, df[actual], actual, "numeric (Age Days)")
        if v:
            violations.append(v)

    # ── Date → datetime64
    actual = col_map.get("Date")
    if actual and actual in df.columns:
        df[actual] = pd.to_datetime(df[actual], errors="coerce", dayfirst=True)

    # ── Period → keep as int64 (it is already int64 per df.info screenshot)
    actual = col_map.get("Period")
    if actual and actual in df.columns:
        df[actual] = pd.to_numeric(df[actual], errors="coerce").astype("Int64")

    # ── Categorical dtypes (memory optimisation)
    df = apply_categorical_dtypes(df, col_map)

    log.info("clean_dataframe: %d violations detected", len(violations))
    return df, violations

"""
core/ageing.py
──────────────
Vectorised ageing computation.
  • period_to_datetime_vec()  — YYYYMM int → last day of month (no .apply())
  • period_labels_vec()       — YYYYMM int → 'YYYY-MM' string labels
  • compute_ageing()          — adds _Computed_Age_Days, _Computed_Bucket,
                                 _Age_Match, _Bucket_Match columns
                                 CORRECTION #6: configurable report_run_date
  • age_to_bucket_vec()       — np.select bucket derivation (100x vs .apply)
"""
import logging
from datetime import date

import numpy as np
import pandas as pd

from core.constants import BUCKET_ORDER

log = logging.getLogger(__name__)


# ── Period → datetime (vectorised) ───────────────────────────────────────────

def period_to_datetime_vec(series: pd.Series) -> pd.Series:
    """
    Converts YYYYMM integer series to the last calendar day of that month.
    E.g.  202501 → 2025-01-31,  202512 → 2025-12-31.
    Fully vectorised — no .apply().
    """
    s = pd.to_numeric(series, errors="coerce")
    year  = (s // 100).astype("Int64")
    month = (s  % 100).astype("Int64")
    valid = month.between(1, 12) & year.notna()

    next_month = month.where(valid) + 1
    next_year  = year.where(valid).copy()
    dec_mask   = month == 12
    next_month = next_month.where(~dec_mask, 1)
    next_year  = next_year.where(~dec_mask, year + 1)

    result = pd.Series(pd.NaT, index=series.index, dtype="datetime64[ns]")
    vi = valid[valid].index
    if len(vi):
        date_str = (
            next_year.loc[vi].astype(str)
            + "-"
            + next_month.loc[vi].astype(str).str.zfill(2)
            + "-01"
        )
        result.loc[vi] = pd.to_datetime(date_str, errors="coerce") - pd.Timedelta(days=1)
    return result


def period_to_datetime_scalar(period_val) -> pd.Timestamp | type(pd.NaT):
    """Scalar version — only used for UI format_func callbacks."""
    try:
        p     = int(period_val)
        year  = p // 100
        month = p % 100
        if not 1 <= month <= 12:
            return pd.NaT
        if month == 12:
            return pd.Timestamp(year + 1, 1, 1) - pd.Timedelta(days=1)
        return pd.Timestamp(year, month + 1, 1) - pd.Timedelta(days=1)
    except (ValueError, TypeError):
        return pd.NaT


def period_labels_vec(series: pd.Series) -> pd.Series:
    """YYYYMM → 'YYYY-MM' string labels. Vectorised, no .apply()."""
    dates = period_to_datetime_vec(series)
    labels = dates.dt.strftime("%Y-%m")
    return labels.where(labels.notna(), series.astype(str))


# ── Bucket derivation (vectorised) ───────────────────────────────────────────

def age_to_bucket_vec(age_series: pd.Series) -> pd.Categorical:
    """
    Map Age Days → Bucket label using np.select (100x faster than .apply).
    Returns ordered pd.Categorical.
    """
    a = age_series.values
    conditions = [
        pd.isna(age_series),
        a <= 15,
        a <= 30,
        a <= 60,
        a <= 90,
        a <= 180,
        a <= 365,
    ]
    choices = ["Unknown", "0-15", "16-30", "31-60", "61-90", "91-180", "181-365"]
    return pd.Categorical(
        np.select(conditions, choices, default="365+"),
        categories=BUCKET_ORDER,
        ordered=True,
    )


# ── Main ageing computation ───────────────────────────────────────────────────

def compute_ageing(
    df: pd.DataFrame,
    col_map: dict,
    report_run_date: str | None = None,
    date_mode: str = "month_end",
) -> pd.DataFrame:
    """
    CORRECTION #6: configurable report_run_date.

    Parameters
    ----------
    df              : cleaned DataFrame (Date col already datetime64)
    col_map         : expected→actual column mapping
    report_run_date : 'YYYY-MM-DD' string override (used when date_mode='manual')
    date_mode       : 'month_end' (default) or 'manual'

    Adds columns
    ──────────────
    _Period_date       : last day of Period month (or report_run_date if manual)
    _Period_label      : 'YYYY-MM' string for chart axes
    _Computed_Age_Days : int — period reference date minus break Date
    _Computed_Bucket   : ordered Categorical
    _Age_Match         : bool — computed ≈ pre-populated (atol=1 day)
    _Bucket_Match      : bool — computed == pre-populated
    """
    period_col = col_map.get("Period")
    date_col   = col_map.get("Date")
    age_col    = col_map.get("Age Days")
    bucket_col = col_map.get("Bucket")

    if not all([period_col, date_col]):
        log.warning("compute_ageing: Period or Date column missing — skipping")
        return df

    df = df.copy()

    # ── Reference date per record ─────────────────────────────────────────────
    if date_mode == "manual" and report_run_date:
        ref_date = pd.Timestamp(report_run_date)
        df["_Period_date"] = ref_date
        log.info("compute_ageing: using manual report_run_date=%s", report_run_date)
    else:
        df["_Period_date"] = period_to_datetime_vec(df[period_col])
        log.info("compute_ageing: using month_end reference dates")

    # Store the mode used in attrs for audit trail
    df.attrs["report_run_date_mode"] = date_mode
    df.attrs["report_run_date_used"] = (
        report_run_date if date_mode == "manual" else "month_end"
    )

    # ── Period labels ─────────────────────────────────────────────────────────
    df["_Period_label"] = period_labels_vec(df[period_col])

    # ── Computed Age Days ─────────────────────────────────────────────────────
    if date_col in df.columns:
        df["_Computed_Age_Days"] = (df["_Period_date"] - df[date_col]).dt.days

    # ── Computed Bucket ───────────────────────────────────────────────────────
    if "_Computed_Age_Days" in df.columns:
        df["_Computed_Bucket"] = age_to_bucket_vec(df["_Computed_Age_Days"])

    # ── Match flags ───────────────────────────────────────────────────────────
    if age_col and age_col in df.columns and "_Computed_Age_Days" in df.columns:
        df["_Age_Match"] = np.isclose(
            df[age_col].fillna(-999),
            df["_Computed_Age_Days"].fillna(-998),
            atol=1,
        )
    if bucket_col and bucket_col in df.columns and "_Computed_Bucket" in df.columns:
        df["_Bucket_Match"] = (
            df[bucket_col].astype(str).str.strip()
            == df["_Computed_Bucket"].astype(str).str.strip()
        )

    log.info("compute_ageing: completed for %d records", len(df))
    return df

"""
core/ingestion.py
─────────────────
File loading pipeline:
  1. load_file()       — XLSX/CSV → raw DataFrame (calamine fast path)
  2. fuzzy_col_match() — map uploaded columns → expected column names
  3. for_del_filter()  — CORRECTION #5: remove For Del=True FIRST
  4. dedup()           — CORRECTION #7: ['TRADE REF','Period'] dedup + surrogate nulls
"""
import hashlib
import logging
from io import BytesIO

import numpy as np
import pandas as pd

from core.constants import EXPECTED_COLUMNS

log = logging.getLogger(__name__)


# ── File loading ──────────────────────────────────────────────────────────────

def load_file(file_bytes: bytes, filename: str) -> pd.DataFrame:
    """
    Load XLSX or CSV from bytes.
    Tries python-calamine first (10-50x faster than openpyxl on 600K rows).
    Falls back to openpyxl, then to CSV parsing.
    Returns raw DataFrame before any cleaning.
    """
    buf = BytesIO(file_bytes)
    fname = filename.lower()

    if fname.endswith((".xlsx", ".xlsm")):
        # --- Calamine fast path ---
        try:
            import python_calamine  # noqa: F401
            df = pd.read_excel(buf, engine="calamine")
            log.info("Loaded %d rows via calamine (%s)", len(df), filename)
            return df
        except ImportError:
            log.warning("python-calamine not installed — falling back to openpyxl")
        buf.seek(0)
        df = pd.read_excel(buf, engine="openpyxl")
        log.info("Loaded %d rows via openpyxl (%s)", len(df), filename)
        return df

    # --- CSV ---
    buf.seek(0)
    # Try common encodings
    for enc in ("utf-8", "utf-8-sig", "latin-1", "cp1252"):
        try:
            buf.seek(0)
            df = pd.read_csv(buf, low_memory=False, encoding=enc)
            log.info("Loaded %d rows via CSV/%s (%s)", len(df), enc, filename)
            return df
        except UnicodeDecodeError:
            continue
    raise ValueError(f"Could not decode {filename} — try saving as UTF-8 CSV")


# ── Column mapping ─────────────────────────────────────────────────────────────

def _normalise(s: str) -> str:
    return s.lower().strip().replace("_", " ").replace("-", " ")


def fuzzy_col_match(uploaded_cols: list[str], target: str) -> str | None:
    """Case-insensitive fuzzy match: exact → partial → token subset."""
    t = _normalise(target)
    # Exact
    for c in uploaded_cols:
        if _normalise(c) == t:
            return c
    # Partial (target inside col or col inside target)
    for c in uploaded_cols:
        cn = _normalise(c)
        if t in cn or cn in t:
            return c
    # Token overlap ≥ 2 tokens
    t_tokens = set(t.split())
    for c in uploaded_cols:
        c_tokens = set(_normalise(c).split())
        if len(t_tokens & c_tokens) >= 2:
            return c
    return None


def build_col_map(uploaded_cols: list[str]) -> dict[str, str]:
    """Return {expected_name: actual_col_name} for all matched columns."""
    mapping = {}
    for expected in EXPECTED_COLUMNS:
        match = fuzzy_col_match(uploaded_cols, expected)
        if match:
            mapping[expected] = match
    return mapping


# ── For Del pre-filter ────────────────────────────────────────────────────────

_FOR_DEL_TRUE_VALUES = {"true", "yes", "y", "1", "x", "delete", "del"}


def for_del_filter(df: pd.DataFrame, col_map: dict) -> tuple[pd.DataFrame, int]:
    """
    CORRECTION #5: Remove 'For Del = True' records BEFORE any other processing.
    Returns (filtered_df, count_removed).
    """
    col = col_map.get("For Del")
    if not col or col not in df.columns:
        log.info("for_del_filter: 'For Del' column not found — no records removed")
        return df, 0

    mask_del = df[col].astype(str).str.strip().str.lower().isin(_FOR_DEL_TRUE_VALUES)
    count = int(mask_del.sum())
    filtered = df.loc[~mask_del].copy()
    log.info("for_del_filter: removed %d records (For Del=True)", count)
    return filtered, count


# ── Deduplication ─────────────────────────────────────────────────────────────

def _surrogate_key(row: pd.Series, col_map: dict) -> str:
    """SHA-256 of Rec + Entity + Amount + Date for null Trade Ref rows."""
    parts = [
        str(row.get(col_map.get("Rec Name (as per Rec Cube)", ""), "")),
        str(row.get(col_map.get("Entity", ""), "")),
        str(row.get(col_map.get("BREAK AMOUNT GBP", ""), "")),
        str(row.get(col_map.get("Date", ""), "")),
    ]
    return "SRG_" + hashlib.sha256("|".join(parts).encode()).hexdigest()[:16]


def dedup(df: pd.DataFrame, col_map: dict) -> tuple[pd.DataFrame, int]:
    """
    CORRECTION #7: Deduplicate on ['TRADE REF', 'Period'] (not just TRADE REF).
    Null TRADE REF rows get a surrogate key so they are not dropped.
    Returns (deduped_df, surrogate_key_count).
    """
    trade_col  = col_map.get("TRADE REF")
    period_col = col_map.get("Period")

    if not trade_col or trade_col not in df.columns:
        log.info("dedup: TRADE REF column not found — skipping deduplication")
        return df, 0

    df = df.copy()

    # Assign surrogate keys to null TRADE REF rows
    null_mask = df[trade_col].isna() | (df[trade_col].astype(str).str.strip() == "")
    surrogate_count = int(null_mask.sum())
    if surrogate_count > 0:
        df.loc[null_mask, trade_col] = df[null_mask].apply(
            lambda row: _surrogate_key(row, col_map), axis=1
        )
        log.info("dedup: assigned %d surrogate keys for null TRADE REF", surrogate_count)

    # Dedup on [TRADE REF, Period] combined
    dedup_cols = [trade_col]
    if period_col and period_col in df.columns:
        dedup_cols.append(period_col)

    before = len(df)
    df = df.drop_duplicates(subset=dedup_cols, keep="last")
    removed = before - len(df)
    log.info("dedup: removed %d duplicate rows (key: %s)", removed, dedup_cols)
    return df, surrogate_count

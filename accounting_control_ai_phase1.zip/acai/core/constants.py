"""core/constants.py — Shared constants across the entire platform."""

# ── Expected column names (fuzzy-matched against uploaded file) ──────────────
EXPECTED_COLUMNS = [
    "Period", "Asset Class", "Team", "Rec Name (as per Rec Cube)", "Entity",
    "Type of break", "Account Group", "Products Reconciled", "TRADE REF",
    "If Duplicate Trade, provide the CC, etc details", "TRADE CCY",
    "BREAK AMOUNT CCY", "BREAK AMOUNT GBP", "Date", "Age Days", "Bucket",
    "True/Systemic Breaks", "Journals Posted", "Comments", "ABS GBP",
    "Root Cause identified", "B/S Cert", "Cash/Non Cash",
    "ABS GBP(Greater than 1mn)", "Threshold", "RECS_CUBE_NAME",
    "Jira reference", "JIRA DESC", "ISSUE CATEGORY", "ISSUE CATEGORY2",
    "JIRA PRIORITY", "EPIC", "EPIC DESC", "SYSTEM TO BE FIXED",
    "High Level Product", "FIX REQUIRED", "ISSUE RAG RATING", "Month",
    "Thematic", "Type of issue", "Action", "For Del",
]

# ── Columns to convert to pd.Categorical (memory optimisation) ───────────────
CATEGORICAL_COLS = [
    "Team", "Rec Name (as per Rec Cube)", "Entity", "Asset Class",
    "Type of break", "Account Group", "Products Reconciled", "TRADE CCY",
    "True/Systemic Breaks", "Journals Posted", "Root Cause identified",
    "B/S Cert", "Bucket", "ISSUE CATEGORY", "ISSUE CATEGORY2",
    "JIRA PRIORITY", "ISSUE RAG RATING", "Thematic", "Type of issue",
    "Cash/Non Cash", "FIX REQUIRED",
]

# ── Ageing bucket order ───────────────────────────────────────────────────────
BUCKET_ORDER = ["0-15", "16-30", "31-60", "61-90", "91-180", "181-365", "365+", "Unknown"]

# ── NLP keyword lists for Phase 1 pre-computation flags ──────────────────────
SSI_KEYWORDS = [
    "ssi", "settlement instruction", "standing instruction",
    "account number", "sort code", "bic", "swift code", "nostro account",
    "correspondent", "routing", "iban", "account mismatch",
]

CA_KEYWORDS = [
    "dividend", "split", "ex-date", "ex date", "corporate action",
    "rights issue", "merger", "spin-off", "spinoff", "tender offer",
    "stock dividend", "bonus issue", "capital reduction",
]

TIMING_BREAK_TYPES = [
    "timing", "settlement timing", "t+1", "t+2", "t+3",
    "fail", "pending", "late settlement",
]

# ── Chart colour palette ──────────────────────────────────────────────────────
COLORS = ["#01696F", "#0C4E54", "#20808D", "#4F98A3", "#A84B2F",
          "#1B474D", "#BCE2E7", "#944454", "#FFC553", "#5C2D91"]
PRIMARY   = "#01696F"
ACCENT    = "#A84B2F"
DARK      = "#28251D"
MUTED     = "#7A7974"
BG_LIGHT  = "#F7F7F5"

"""
core/analytics.py
─────────────────
All aggregation and analytics business logic.
  • get_trend_data()          — break count / amount by period (grouped optional)
  • compute_mad_alerts()      — Median+MAD threshold alerting (fully vectorised)
  • compute_factor_analysis() — period-over-period decomposition
  • filter_options_from_df()  — pre-compute sidebar filter choices
  • apply_filters()           — apply multi-select filter dict to df
  • safe_mom_pct()            — MoM % helper
"""
import logging

import numpy as np
import pandas as pd

from core.ageing import period_to_datetime_scalar

log = logging.getLogger(__name__)


# ── Utilities ─────────────────────────────────────────────────────────────────

def safe_mom_pct(current: float, previous: float) -> float | None:
    if previous is None or previous == 0:
        return None
    return round(((current - previous) / abs(previous)) * 100, 1)


def _period_order(labels: pd.Series) -> list[str]:
    return sorted(labels.dropna().unique().tolist())


# ── Filter helpers ─────────────────────────────────────────────────────────────

def filter_options_from_df(df: pd.DataFrame, col_map: dict) -> dict:
    """Pre-compute unique values for all sidebar filter dimensions."""
    options = {}
    period_col = col_map.get("Period")
    if period_col and period_col in df.columns:
        options["Period"] = sorted(df[period_col].dropna().unique().tolist())

    for key in ("Team", "Rec Name (as per Rec Cube)", "Entity", "Asset Class",
                "Type of break", "True/Systemic Breaks", "ISSUE RAG RATING"):
        actual = col_map.get(key)
        if actual and actual in df.columns:
            col = df[actual]
            if hasattr(col, "cat"):
                options[key] = sorted(col.cat.categories.tolist())
            else:
                options[key] = sorted(col.dropna().unique().tolist())
    return options


def apply_filters(df: pd.DataFrame, col_map: dict, filters: dict) -> pd.DataFrame:
    """Apply {expected_col_key: [selected_values]} filter dict. Single mask pass."""
    mask = pd.Series(True, index=df.index)
    for key, selected in filters.items():
        if not selected:
            continue
        actual = col_map.get(key)
        if actual and actual in df.columns:
            mask &= df[actual].isin(selected)
    return df.loc[mask]


# ── Trend data ────────────────────────────────────────────────────────────────

def get_trend_data(
    df: pd.DataFrame,
    col_map: dict,
    amt_col: str | None = None,
    group_by_key: str | None = None,
) -> dict:
    """
    Aggregate break count and optional amount by _Period_label.
    Optionally grouped by a second dimension (e.g. Team, Asset Class).

    Returns dict ready for JSON serialisation.
    """
    if "_Period_label" not in df.columns:
        return {"error": "_Period_label not computed — run compute_ageing first"}

    period_col  = col_map.get("Period")
    period_ord  = _period_order(df["_Period_label"])

    group_col   = col_map.get(group_by_key) if group_by_key else None
    use_group   = group_col and group_col in df.columns

    if use_group:
        grp = df.groupby(["_Period_label", group_col], observed=True)
    else:
        grp = df.groupby("_Period_label", observed=True)

    count_series = grp.size().rename("break_count")

    if amt_col and amt_col in df.columns:
        amt_series = grp[amt_col].sum().rename("abs_gbp")
        trend = pd.concat([count_series, amt_series], axis=1).fillna(0)
    else:
        trend = count_series.to_frame().fillna(0)

    trend = trend.reset_index()

    # Compute MoM on totals
    period_totals = df.groupby("_Period_label", observed=True).size().reindex(period_ord).fillna(0)
    mom_count = safe_mom_pct(
        period_totals.iloc[-1] if len(period_totals) else 0,
        period_totals.iloc[-2] if len(period_totals) > 1 else None,
    )

    return {
        "period_order": period_ord,
        "data":         trend.to_dict(orient="records"),
        "mom_count_pct": mom_count,
    }


# ── MAD threshold alerting ────────────────────────────────────────────────────

def compute_mad_alerts(
    df: pd.DataFrame,
    col_map: dict,
    segment_key: str,
    period_key: str  = "Period",
    amt_key: str | None = None,
    mad_k: float     = 3.0,
    watchlist_k: float = 2.0,
) -> dict:
    """
    Median + MAD threshold alerting per segment across periods.
    Fully vectorised using groupby + agg — no Python loops on segments.

    Returns dict: {segments: [...], summary: {material, watchlist, normal}}
    """
    seg_col    = col_map.get(segment_key)
    period_col = col_map.get(period_key)
    amt_col    = col_map.get(amt_key) if amt_key else None

    if not seg_col or seg_col not in df.columns:
        return {"error": f"Segment column '{segment_key}' not found"}
    if not period_col or period_col not in df.columns:
        return {"error": f"Period column not found"}

    # Break count per segment per period
    sp_count = (
        df.groupby([seg_col, period_col], observed=True)
        .size()
        .reset_index(name="break_count")
    )

    # Amount per segment per period (optional)
    if amt_col and amt_col in df.columns:
        sp_amt = (
            df.groupby([seg_col, period_col], observed=True)[amt_col]
            .sum().abs()
            .reset_index(name="break_amount")
        )
        sp = sp_count.merge(sp_amt, on=[seg_col, period_col], how="left")
    else:
        sp = sp_count.copy()
        sp["break_amount"] = 0.0

    # Compute stats per segment using vectorised groupby
    def _stats(vals):
        med = np.median(vals)
        mad = np.median(np.abs(vals - med))
        if mad == 0:
            mad = max(med * 0.1, 1.0)
        latest = vals.iloc[-1] if hasattr(vals, "iloc") else vals[-1]
        upper_mat   = med + mad_k      * mad
        upper_watch = med + watchlist_k * mad
        cls = ("Material"  if latest > upper_mat else
               "Watchlist" if latest > upper_watch else "Normal")
        dev = round((latest - med) / mad * 100, 1) if mad > 0 else 0.0
        return pd.Series({
            "median": round(med, 1), "mad": round(mad, 2),
            "upper_mat": round(upper_mat, 1),
            "latest": float(latest), "classification": cls, "deviation_pct": dev,
            "n_periods": len(vals),
        })

    count_stats = (
        sp.groupby(seg_col, observed=True)["break_count"]
        .apply(lambda x: x.sort_values().pipe(_stats))
        .add_prefix("count_")
    )
    amt_stats = (
        sp.groupby(seg_col, observed=True)["break_amount"]
        .apply(lambda x: x.sort_values().pipe(_stats))
        .add_prefix("amt_")
    )

    alert_df = count_stats.join(amt_stats).reset_index()
    alert_df.rename(columns={seg_col: "segment"}, inplace=True)

    # Final combined classification
    cls_rank = {"Material": 2, "Watchlist": 1, "Normal": 0}
    alert_df["classification"] = alert_df.apply(
        lambda r: r["count_classification"]
        if cls_rank.get(r["count_classification"], 0) >= cls_rank.get(r["amt_classification"], 0)
        else r["amt_classification"],
        axis=1,
    )

    records = alert_df.to_dict(orient="records")
    summary = {
        "material":  int((alert_df["classification"] == "Material").sum()),
        "watchlist": int((alert_df["classification"] == "Watchlist").sum()),
        "normal":    int((alert_df["classification"] == "Normal").sum()),
    }
    return {"segments": records, "summary": summary}


# ── Factor analysis ───────────────────────────────────────────────────────────

def compute_factor_analysis(
    df: pd.DataFrame,
    col_map: dict,
    dim_key: str,
    prev_period,
    curr_period,
    amt_key: str | None = None,
) -> dict:
    """
    Period-over-period count and amount decomposition by a dimension column.
    Returns waterfall-ready data dict.
    """
    period_col = col_map.get("Period")
    dim_col    = col_map.get(dim_key)
    amt_col    = col_map.get(amt_key) if amt_key else None

    if not period_col or not dim_col:
        return {"error": "Period or dimension column not found"}

    df_prev = df[df[period_col] == prev_period]
    df_curr = df[df[period_col] == curr_period]

    def _agg(frame):
        cnt = frame.groupby(dim_col, observed=True).size().rename("count")
        if amt_col and amt_col in frame.columns:
            amt = frame.groupby(dim_col, observed=True)[amt_col].sum().abs().rename("amount")
            return pd.concat([cnt, amt], axis=1).fillna(0)
        return cnt.to_frame().assign(amount=0.0)

    prev_agg = _agg(df_prev).add_prefix("prev_")
    curr_agg = _agg(df_curr).add_prefix("curr_")
    merged   = prev_agg.join(curr_agg, how="outer").fillna(0).reset_index()

    merged["count_change"]    = merged["curr_count"]  - merged["prev_count"]
    merged["amount_change"]   = merged["curr_amount"] - merged["prev_amount"]
    merged["count_change_pct"] = np.where(
        merged["prev_count"] > 0,
        (merged["count_change"] / merged["prev_count"] * 100).round(1),
        np.where(merged["curr_count"] > 0, 100.0, 0.0),
    )
    merged = merged.sort_values("count_change", ascending=False)

    total_prev = int(len(df_prev))
    total_curr = int(len(df_curr))
    net_change = total_curr - total_prev

    prev_label = _fmt_period(prev_period)
    curr_label = _fmt_period(curr_period)

    return {
        "prev_period":  prev_period,
        "curr_period":  curr_period,
        "prev_label":   prev_label,
        "curr_label":   curr_label,
        "total_prev_count": total_prev,
        "total_curr_count": total_curr,
        "net_count_change": net_change,
        "count_change_pct": safe_mom_pct(total_curr, total_prev),
        "breakdown":    merged.to_dict(orient="records"),
    }


def _fmt_period(period_val) -> str:
    ts = period_to_datetime_scalar(period_val)
    if ts is pd.NaT or ts is None:
        return str(period_val)
    return ts.strftime("%Y-%m")
